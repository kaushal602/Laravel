<?php
$table = 'page_master';
$primaryKey = 'PageId';
$columns = array(
    array( 'db' => '`u`.`PageId`',           'dt'=> 0, 'field' => 'PageId' ),
    array( 'db' => '`u`.`PageName`',         'dt'=> 1, 'field' => 'PageName' ),
    array( 'db' => '`u`.`Description`',         'dt'=> 2, 'field' => 'Description' ),
    array( 'db' => '`u`.`PageId`',         'dt'=> 3, 'field' => 'PageId' ),
);
$sql_details = array(
    'user' => env('DB_USERNAME'),
    'pass' => env('DB_PASSWORD'),
    'db'   => env('DB_DATABASE'),
    'host' => env('DB_HOST')
);
$joinQuery = "FROM `page_master` AS `u`";
//$id = session()->get('subjectdata')['CompanyId'];
//$where = "`u`.`IsActive` =1";
//require( 'ssp.class.php' );
require( 'ssp.customized.class.php' );
echo json_encode(
    SSP::simple( $_GET, $sql_details, $table, $primaryKey, $columns, $joinQuery )
);
?>