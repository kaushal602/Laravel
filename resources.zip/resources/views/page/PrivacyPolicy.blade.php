@include('include.header')
                <div class="page-content-wrapper">
                    <div class="page-content">
                        <div class="page-bar">
                            <ul class="page-breadcrumb">
                                <li><i class="icon-home"></i> <a href="{{url('')}}">Home</a> <i class="fa fa-angle-right"></i></li>
                                <li><span>Privacy Policy</span></li>
                            </ul>
                        </div>
                        <div class="spacer"></div>
                        <div class="row">
                            <div class="col-md-12 ">
                                <div class="portlet light bordered">
                                    <div class="portlet-title">
                                        <div class="caption font-red-sunglo">
                                            <i class="icon-settings font-red-sunglo"></i>
                                            <span class="caption-subject bold uppercase">Privacy Policy</span>
                                        </div>
                                    </div>
                                    <div class="portlet-body form">
                                        <form role="form" method="post" id="addpage" action="{{url('editprivacy-policy')}}" enctype="multipart/form-data">
                                        {{csrf_field()}}
                                            <div class="form-body">
                                                <div class="row">
                                                    <input type="hidden" name="PageId" id="PageId" value="{{$Data->PageId}}">
                                                    <div class="col-md-12">
                                                        <div class="form-group">
                                                            <div class="form-group">
                                                                <textarea id="Description" name="Description" class="form-control ckeditor" placeholder="Write your content.." required>{{$Data->Description}}</textarea>
                                                            </div>
                                                            <span class="font-red-thunderbird">{{$errors->first('Description')}}</span>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12">
                                                        
                                                    </div>
                                                    <div class="form-actions col-md-12 btn-align">
                                                        <button type="submit" class="btn blue">Update</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

        @include('include.footer')
        <script>
            var sucesstitle = '{{$errors->first('sucmsg')}}';
            if(sucesstitle!=''){
                toastr.success(sucesstitle);
            }
        </script>
    </body>
</html>