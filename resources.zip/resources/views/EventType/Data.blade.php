<?php
$table = 'eventtype_master';
$primaryKey = 'EventTypeId';
$columns = array(
    array( 'db' => '`u`.`EventTypeId`',           'dt'=> 0, 'field' => 'EventTypeId' ),
    array( 'db' => '`u`.`EventTypeName`',         'dt'=> 1, 'field' => 'EventTypeName' ),
    array( 'db' => '`u`.`EventTypeId`',         'dt'=> 2, 'field' => 'EventTypeId' ),
);
$sql_details = array(
    'user' => env('DB_USERNAME'),
    'pass' => env('DB_PASSWORD'),
    'db'   => env('DB_DATABASE'),
    'host' => env('DB_HOST')
);
$joinQuery = "FROM `eventtype_master` AS `u`";
//$id = session()->get('subjectdata')['CompanyId'];
$where = "`u`.`IsActive` =1 AND `u`.`ParentEventTypeId` =0";
//require( 'ssp.class.php' );
//$groupBy = '`u`.`EventTypeName`';
require( 'ssp.customized.class.php' );
echo json_encode(
    SSP::simple( $_GET, $sql_details, $table, $primaryKey, $columns, $joinQuery, $where )
);
?>