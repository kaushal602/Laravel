@include('include.header')
                <div class="page-content-wrapper">
                    <div class="page-content">
                        <div class="page-bar">
                            <ul class="page-breadcrumb">
                                <li><i class="icon-home"></i> <a href="{{url('')}}">Home</a> <i class="fa fa-angle-right"></i></li>
                                <li><span>Edit Event Type</span></li>
                            </ul>
                        </div>
                        <div class="spacer"></div>
                        <div class="row">
                            <div class="col-md-12 ">
                                <div class="portlet light bordered">
                                    <div class="portlet-title">
                                        <div class="caption font-red-sunglo">
                                            <i class="icon-settings font-red-sunglo"></i>
                                            <span class="caption-subject bold uppercase">Edit Event Type</span>
                                        </div>
                                        <div class="actions">
                                                <a class="btn btn-sm green " href="{{url('eventtypelist')}}" > Event Type List
                                                </a>
                                        </div>
                                    </div>
                                    <div class="portlet-body form">
                                        <form role="form" method="post" id="addpage" action="{{url('editeventtypedetails')}}" enctype="multipart/form-data">
                                        {{csrf_field()}}
                                            <div class="form-body">
                                                <div class="row">
                                                    <input type="hidden" name="TypeId" id="TypeId" value="{{$Data->EventTypeId}}">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label>Event Type<span class="requierd-box">*</span></label>
                                                            <div class="form-group">
                                                                <input type="text" class="form-control" value="{{$Data->EventTypeName}}" name="EventTypeName" id="EventTypeName" required>
                                                            </div>
                                                            <span class="font-red-thunderbird"></span>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label>Parent Event Type</label>
                                                            <div class="form-group">
                                                                <select name="ParentEventTypeId" id="ParentEventTypeId" class="form-control">
                                                                    <option value="0" selected>Select Parent Event Type</option>
                                                                    <?php foreach ($eventlist as $key => $value) { ?>
                                                                        <option value="<?= $value->EventTypeId; ?>"><?= $value->EventTypeName; ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                            </div>
                                                            <span class="font-red-thunderbird">{{$errors->first('ParentEventTypeId')}}</span>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label>Event Type Icon</label>
                                                            <div class="fileinput fileinput-new" data-provides="fileinput">
                                                                <div class="input-group input-large">
                                                                    <div class="form-control uneditable-input input-fixed input-medium" data-trigger="fileinput">
                                                                        <i class="fa fa-file fileinput-exists"></i>&nbsp;
                                                                        <span class="fileinput-filename"> </span>
                                                                    </div>
                                                                    <span class="input-group-addon btn default btn-file">
                                                                        <span class="fileinput-new"> Select Images </span>
                                                                        <span class="fileinput-exists"> Change </span>
                                                                        <input type="file" name="EventTypeIcon"  onchange="readURL(this);" id="EventTypeIcon"> </span>
                                                                </div>
                                                            </div>
                                                            <span class="font-red-thunderbird">{{$errors->first('EventTypeIcon')}}</span>
                                                        </div>
                                                        <span class="red AdvertiseImage">
                                                            <img id="asimage" src="{{url($Data->EventTypeIcon)}}" alt="" width="150" />
                                                        </span>
                                                    </div>
                                                    <div class="col-md-12">
                                                        <div class="form-group fileupload-buttonbar">
                                                            <label>Event Type Images</label>
                                                            <div class="form-group fileinput fileinput-new">
                                                                <span class="btn green btn-file">
                                                                    <span class="fileinput-new"> Select Images </span>
                                                                    <input name="imagegallery[]" id="imagegallery" type="file" accept="image/*" class="nowidthfile" multiple>
                                                                </span>
                                                            </div>
                                                            <span class="font-red-thunderbird">{{$errors->first('imagegallery')}}</span>
                                                        </div>
                                                        <!-- <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                            <div class="row" id="imgpre">

                                                            </div>
                                                        </div> -->
                                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                            <div class="row" id="imgpre">
                                                                <?php foreach ($ImageData as $key=>$Image) { ?>
                                                                    <div class='col-lg-2 col-md-2 col-sm-2 col-xs-12 imgtc imgtc<?= $Image->EventTypeImageId; ?>'>
                                                                        <div class='img-butt-box'>
                                                                            <img src='<?= url('').'/'.$Image->ImageUrl; ?>' style='width: 150px;'>
                                                                        </div>
                                                                        <div class="rmbtn">
                                                                            <input class='lava-add-item-map-search-find' value='Remove' onclick=dltimg('<?= $Image->EventTypeImageId; ?>') type='button'>
                                                                        </div>
                                                                    </div>
                                                                <?php } ?>
                                                                <input type="hidden" id="deleteimages" name="deleteimages" value="">
                                                                <input type="hidden" id="deletetimages" name="deletetimages" value="">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- <div class="form-actions col-md-12 btn-align">
                                                        <button type="submit" class="btn blue">Submit</button>
                                                    </div> -->
                                                    
                                                    <div class="form-actions col-md-12 btn-align">
                                                        <button type="submit" class="btn blue">Update</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

        @include('include.footer')
        <script>
            var sucesstitle = '{{$errors->first('sucmsg')}}';
            if(sucesstitle!=''){
                toastr.success(sucesstitle);
            }
        </script>
        <script type="text/javascript">
            window.onload = function () {
    //for gallery images
            var imagegallery = document.getElementById("imagegallery");
            imagegallery.onchange = function () {
                if (typeof (FileReader) != "undefined") {
                    var dvPreview = document.getElementById("imgpre");
                    //dvPreview.innerHTML = "";
                    jQuery(".imgtcl").remove();
                    var regex = /^([a-zA-Z0-9\s_\\.\-:])+(.jpg|.jpeg|.gif|.png|.bmp)$/;
                    var tmpvar = 0;
                    for (var i = 0; i < imagegallery.files.length; i++) {
                        var file = imagegallery.files[i];
                        if (regex.test(file.name.toLowerCase())) {
                            var reader = new FileReader();
                            reader.onload = function (e) {
                                jQuery("#imgpre").prepend("<div class='col-lg-2 col-md-2 col-sm-2 col-xs-12 imgtcl imgtcl"+tmpvar+"'><div class='img-butt-box'><img src='"+e.target.result+"' style='width: 150px;'></div><div class='rmbtn'><input class='lava-add-item-map-search-find' value='Remove' onclick=deltimg('"+tmpvar+"') type='button'></div></div>");
                                jQuery("#deleteimages").val('');
                                tmpvar++;
                            }
                            reader.readAsDataURL(file);
                        } else {
                            alert(file.name + " is not a valid image file.");
                            //dvPreview.innerHTML = "";
                            jQuery(".imgtcl").remove();
                            return false;
                        }
                    }
                } else {
                    alert("This browser does not support HTML5 FileReader.");
                }
            }
        }
        function deltimg(imgid){
            jQuery("#deleteimages").val((jQuery("#deleteimages").val())+" "+imgid);
            jQuery(".imgtcl"+imgid).remove();
        }

        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function (e) {
                    $('.red.AdvertiseImage').html('<img id="asimage" src="'+ e.target.result+'" alt="your image" width="150" />');
                }
                reader.readAsDataURL(input.files[0]);
            }
        }
        function dltimg(imgid){
            jQuery("#deletetimages").val((jQuery("#deletetimages").val())+" "+imgid);
            jQuery(".imgtc"+imgid).remove();
            /*var url1 = "{{url('deleteeventimage')}}";
            var r1 = confirm("Are you sure? You want to delete Image.");
            if (r1 == true) {
                jQuery.ajax({
                    url: url1,
                    data: {TypeId:imgid},
                    type: 'POST',
                    beforeSend: function () { },
                    complete: function () {},
                    success: function (result) {
                        toastr.success('Event type deleted successfully');
                        setTimeout(function () {
                            location.reload()
                        }, 100);
                         //resettbl();
                    }
                })
            }*/
        }
        </script>
    </body>
</html>