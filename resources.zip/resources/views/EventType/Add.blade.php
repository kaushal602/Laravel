@include('include.header')
        <div class="page-content-wrapper">
            <div class="page-content">
                <div class="page-bar">
                    <ul class="page-breadcrumb">
                        <li><i class="icon-home"></i> <a href="{{url('')}}">Home</a> <i class="fa fa-angle-right"></i></li>
                        <li><span>Add Event Type</span></li>
                    </ul>
                </div>
                <div class="spacer"></div>
                <div class="row">
                    <div class="col-md-12 ">
                        <div class="portlet light bordered">
                            <div class="portlet-title">
                                <div class="caption font-red-sunglo">
                                    <i class="icon-settings font-red-sunglo"></i>
                                    <span class="caption-subject bold uppercase">Add Event Type</span>
                                </div>
                            </div>
                            <div class="portlet-body form">
                                <div class="table-toolbar">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="btn-group">
                                                 <a class="btn btn-sm green " href="{{url('eventtypelist')}}" >  Event Type List <i class="fa fa-plus"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <form role="form" id="fileupload" method="post" action="{{url('addeventtype')}}" enctype="multipart/form-data">
                                {{csrf_field()}}
                                    <div class="form-body">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Event Type<span class="requierd-box">*</span></label>
                                                    <div class="form-group">
                                                        <input type="text" class="form-control" value="{{old('EventTypeName')}}" name="EventTypeName" id="EventTypeName" required>
                                                    </div>
                                                    <span class="font-red-thunderbird">{{$errors->first('EventName')}}</span>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Parent Event Type</label>
                                                    <div class="form-group">
                                                        <select name="ParentEventTypeId" id="ParentEventTypeId" class="form-control">
                                                            <option value="0" selected>Select Parent Event Type</option>
                                                            <?php foreach ($eventlist as $key => $value) { ?>
                                                                <option value="<?= $value->EventTypeId; ?>"><?= $value->EventTypeName; ?></option>
                                                            <?php } ?>
                                                        </select>
                                                    </div>
                                                    <span class="font-red-thunderbird">{{$errors->first('ParentEventTypeId')}}</span>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Event Type Icon</label>
                                                    <div class="fileinput fileinput-new" data-provides="fileinput">
                                                        <div class="input-group input-large">
                                                            <div class="form-control uneditable-input input-fixed input-medium" data-trigger="fileinput">
                                                                <i class="fa fa-file fileinput-exists"></i>&nbsp;
                                                                <span class="fileinput-filename"> </span>
                                                            </div>
                                                            <span class="input-group-addon btn default btn-file">
                                                                <span class="fileinput-new"> Select Images </span>
                                                                <span class="fileinput-exists"> Change </span>
                                                                <input type="file" name="EventTypeIcon"  onchange="readURL(this);" id="EventTypeIcon" > </span>
                                                        </div>
                                                    </div>
                                                    <span class="font-red-thunderbird">{{$errors->first('EventTypeIcon')}}</span>
                                                </div>
                                                <span class="red AdvertiseImage">
                                                    
                                                </span>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group fileupload-buttonbar">
                                                    <label>Event Type Images</label>
                                                    <div class="form-group fileinput fileinput-new">
                                                        <span class="btn green btn-file">
                                                            <span class="fileinput-new"> Select Images </span>
                                                            <input name="imagegallery[]" id="imagegallery" type="file" accept="image/*" class="nowidthfile" multiple>
                                                            <input type="hidden" id="deleteimages" name="deleteimages" value="">
                                                        </span>
                                                    </div>
                                                    <span class="font-red-thunderbird">{{$errors->first('imagegallery')}}</span>
                                                </div>
                                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                    <div class="row" id="imgpre">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-actions col-md-12 btn-align">
                                                <button type="submit" class="btn blue">Submit</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                                <!-- The table listing the files available for upload/download -->
                                <table role="presentation" class="table table-striped clearfix">
                                    <tbody class="files"> </tbody>
                                </table>
                            </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        @include('include.footer')
        <script>
            var sucesstitle = '{{$errors->first('sucmsg')}}';
            if(sucesstitle!=''){
                toastr.success(sucesstitle);
            }
        </script>
        <script type="text/javascript">
        window.onload = function () {
            var imagegallery = document.getElementById("imagegallery");
            imagegallery.onchange = function () {
                if (typeof (FileReader) != "undefined") {
                    var dvPreview = document.getElementById("imgpre");
                    //dvPreview.innerHTML = "";
                    jQuery(".imgtcl").remove();
                    var regex = /^([a-zA-Z0-9\s_\\.\-:])+(.jpg|.jpeg|.gif|.png|.bmp)$/;
                    var tmpvar = 0;
                    for (var i = 0; i < imagegallery.files.length; i++) {
                        var file = imagegallery.files[i];
                        if (regex.test(file.name.toLowerCase())) {
                            var reader = new FileReader();
                            reader.onload = function (e) {
                                jQuery("#imgpre").prepend("<div class='col-lg-2 col-md-2 col-sm-2 col-xs-12 imgtcl imgtcl"+tmpvar+"'><div class='img-butt-box'><img src='"+e.target.result+"' style='width: 150px;'></div><div class='rmbtn'><input class='lava-add-item-map-search-find' value='Remove' onclick=deltimg('"+tmpvar+"') type='button'></div></div>");
                                jQuery("#deleteimages").val('');
                                tmpvar++;
                            }
                            reader.readAsDataURL(file);
                        } else {
                            alert(file.name + " is not a valid image file.");
                            //dvPreview.innerHTML = "";
                            jQuery(".imgtcl").remove();
                            return false;
                        }
                    }
                } else {
                    alert("This browser does not support HTML5 FileReader.");
                }
            }
        }
        function deltimg(imgid){
            jQuery("#deleteimages").val((jQuery("#deleteimages").val())+" "+imgid);
            jQuery(".imgtcl"+imgid).remove();
        }
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function (e) {
                    $('.red.AdvertiseImage').html('<img id="asimage" src="'+ e.target.result+'" alt="your image" width="150" />');
                }
                reader.readAsDataURL(input.files[0]);
            }
        }
        </script>
            </html>
    </body>
</html>