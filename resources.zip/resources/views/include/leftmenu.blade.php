<?php 
$url = url('');
$fullurl = url()->current();
$newurl = str_replace($url, "", $fullurl);
//echo $newurl; exit;
?>
<div class="page-sidebar-wrapper">
    <div class="page-sidebar navbar-collapse collapse">
        <ul class="page-sidebar-menu  page-header-fixed page-sidebar-menu-hover-submenu " data-keep-expanded="false" data-auto-scroll="true" data-slide-speed="200">
            
            <li class="nav-item start <?php if($newurl == "/dashboard"){ echo "active";} ?>">
                <a href="{{url('dashboard')}}" class="nav-link nav-toggle">
                    <i class="icon-home"></i>
                    <span class="title">Dashboard</span>
                    <span class="arrow"></span>
                </a>
            </li>
            <li class="nav-item start <?php if($newurl == "/userlist"){ echo "active";} ?>">
                <a href="{{url('userlist')}}" class="nav-link nav-toggle">
                    <i class="fa fa-user"></i>
                    <span class="title">User List</span>
                    <span class="arrow"></span>
                </a>
            </li><li class="nav-item start <?php if($newurl == "/eventlist"){ echo "active";} ?>">
                <a href="{{url('eventlist')}}" class="nav-link nav-toggle">
                    <i class="fa fa-calendar"></i>
                    <span class="title">Event List</span>
                    <span class="arrow"></span>
                </a>
            </li>
            <!-- <li class="nav-item start <?php if($newurl == "/pagelist"){ echo "active";} ?>">
                <a href="{{url('pagelist')}}" class="nav-link nav-toggle">
                    <i class="fa fa-file-o" aria-hidden="true"></i>
                    <span class="title">Page List</span>
                    <span class="arrow"></span>
                </a>
            </li> -->
            <!-- <li class="nav-item start <?php if($newurl == "/addpage"){ echo "active";} ?>">
                <a href="javascript:;" class="nav-link nav-toggle">
                    <i class="fa fa-file-o" aria-hidden="true"></i>
                    <span class="title">Page</span>
                    <span class="selected"></span>
                    <span class="arrow open"></span>
                </a>
                <ul class="sub-menu">
                    <li class="nav-item start <?php if($newurl == "/pagelist"){ echo "active";} ?>">
                        <a href="{{url('pagelist')}}" class="nav-link ">
                            <i class="icon-bar-chart"></i>
                            <span class="title">Page List</span>
                            <span class="selected"></span>
                        </a>
                    </li>
                    <li class="nav-item start <?php if($newurl == "/addpage"){ echo "active";} ?>">
                        <a href="{{url('addpage')}}" class="nav-link ">
                            <i class="icon-bar-chart"></i>
                            <span class="title">Add Page</span>
                            <span class="selected"></span>
                        </a>
                    </li>
                </ul>
            </li> -->
            <li class="nav-item start <?php if($newurl == "/addadvertise" || $newurl == "/advertiselist"){ echo "active";} ?>">
                <a href="javascript:;" class="nav-link nav-toggle">
                    <!-- <i class="icon-home"></i> -->
                    <i class="fa fa-newspaper-o" aria-hidden="true"></i>
                    <span class="title">Advertise</span>
                    <span class="selected"></span>
                    <span class="arrow open"></span>
                </a>
                <ul class="sub-menu">
                    <li class="nav-item start <?php if($newurl == "/advertiselist" || $newurl == "/eventtypelist"){ echo "active";} ?>">
                        <a href="{{url('advertiselist')}}" class="nav-link ">
                            <i class="icon-bar-chart"></i>
                            <span class="title">Advertise List</span>
                            <span class="selected"></span>
                        </a>
                    </li>
                    <li class="nav-item start <?php if($newurl == "/addadvertise"){ echo "active";} ?>">
                        <a href="{{url('addadvertise')}}" class="nav-link ">
                            <i class="icon-bar-chart"></i>
                            <span class="title">Add Advertise</span>
                            <span class="selected"></span>
                        </a>
                    </li>
                </ul>
            </li>
            <li class="nav-item start <?php if($newurl == "/addeventtype" || $newurl == "/eventtypelist"){ echo "active";} ?>">
                <a href="javascript:;" class="nav-link nav-toggle">
                    <i class="fa fa-calendar"></i>
                    <span class="title">Event Type</span>
                    <span class="selected"></span>
                    <span class="arrow open"></span>
                </a>
                <ul class="sub-menu">
                    <li class="nav-item start <?php if($newurl == "/eventtypelist"){ echo "active";} ?>">
                        <a href="{{url('eventtypelist')}}" class="nav-link ">
                            <i class="icon-bar-chart"></i>
                            <span class="title">Event Type List</span>
                            <span class="selected"></span>
                        </a>
                    </li>
                    <li class="nav-item start <?php if($newurl == "/addeventtype"){ echo "active";} ?>">
                        <a href="{{url('addeventtype')}}" class="nav-link ">
                            <i class="icon-bar-chart"></i>
                            <span class="title">Add Event Type</span>
                            <span class="selected"></span>
                        </a>
                    </li>
                </ul>
            </li>
            <li class="nav-item start <?php if($newurl == "/addcountry" || $newurl == "/countrylist"){ echo "active";} ?>">
                <a href="javascript:;" class="nav-link nav-toggle">
                    <!-- <i class="icon-home"></i> -->
                    <i class="fa fa-globe" aria-hidden="true"></i>
                    <span class="title">Country</span>
                    <span class="selected"></span>
                    <span class="arrow open"></span>
                </a>
                <ul class="sub-menu">
                    <li class="nav-item start <?php if($newurl == "/countrylist"){ echo "active";} ?>">
                        <a href="{{url('countrylist')}}" class="nav-link ">
                            <i class="icon-bar-chart"></i>
                            <span class="title">Country List</span>
                            <span class="selected"></span>
                        </a>
                    </li>
                    <li class="nav-item start <?php if($newurl == "/addcountry"){ echo "active";} ?>">
                        <a href="{{url('addcountry')}}" class="nav-link ">
                            <i class="icon-bar-chart"></i>
                            <span class="title">Add Country</span>
                            <span class="selected"></span>
                        </a>
                    </li>
                </ul>
            </li>
            <!-- <li class="nav-item start <?php if($newurl == "/addlanguage"){ echo "active";} ?>">
                <a href="javascript:;" class="nav-link nav-toggle">
                    <i class="fa fa-language" aria-hidden="true"></i>
                    <span class="title">Language</span>
                    <span class="selected"></span>
                    <span class="arrow open"></span>
                </a>
                <ul class="sub-menu">
                    <li class="nav-item start <?php if($newurl == "/languagelist"){ echo "active";} ?>">
                        <a href="{{url('languagelist')}}" class="nav-link ">
                            <i class="icon-bar-chart"></i>
                            <span class="title">Language List</span>
                            <span class="selected"></span>
                        </a>
                    </li>
                    <li class="nav-item start <?php if($newurl == "/addlanguage"){ echo "active";} ?>">
                        <a href="{{url('addlanguage')}}" class="nav-link ">
                            <i class="icon-bar-chart"></i>
                            <span class="title">Add Language</span>
                            <span class="selected"></span>
                        </a>
                    </li>
                </ul>
            </li> -->
            <li class="nav-item start <?php if($newurl == "/about-us"){ echo "active";} ?>">
                <a href="{{url('about-us')}}" class="nav-link nav-toggle">
                    <i class="fa fa-file-o" aria-hidden="true"></i>
                    <span class="title">About Us</span>
                    <span class="arrow"></span>
                </a>
            </li>
            <li class="nav-item start <?php if($newurl == "/privacy-policy"){ echo "active";} ?>">
                <a href="{{url('privacy-policy')}}" class="nav-link nav-toggle">
                    <i class="fa fa-file-o" aria-hidden="true"></i>
                    <span class="title">Privacy Policy</span>
                    <span class="arrow"></span>
                </a>
            </li>
        </ul>
    </div>
</div>