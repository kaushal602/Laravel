                <a href="javascript:;" class="page-quick-sidebar-toggler">
                <i class="icon-login"></i>
            </a>
            @include("include.rightbar")
        </div>
        <div class="page-footer">
            <div class="page-footer-inner">
                2018 © iGexSolutions. Admin Template.
            </div>
            <script src="{{url('assets/global/plugins/jquery.min.js')}}" type="text/javascript"></script>
            <script src="{{url('assets/global/plugins/bootstrap/js/bootstrap.min.js')}}" type="text/javascript"></script>
            <script src="{{url('assets/global/scripts/datatable.js')}}" type="text/javascript"></script>
            <script src="{{url('assets/global/plugins/datatables/datatables.min.js')}}" type="text/javascript"></script>
            <script src="{{url('assets/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.js')}}" type="text/javascript"></script>
            <!-- <script src="{{url('assets/global/scripts/app.min.js')}}" type="text/javascript"></script> -->
            <script src="{{url('assets/pages/scripts/table-datatables-managed.min.js')}}" type="text/javascript"></script>
            <script src="{{url('assets/global/plugins/js.cookie.min.js')}}" type="text/javascript"></script>
            <script src="{{url('assets/global/plugins/jquery-slimscroll/jquery.slimscroll.min.js')}}" type="text/javascript"></script>
            <script src="{{url('assets/global/plugins/jquery.blockui.min.js')}}" type="text/javascript"></script>
            <script src="{{url('assets/global/plugins/bootstrap-switch/js/bootstrap-switch.min.js')}}" type="text/javascript"></script>
            <script src="{{url('assets/global/scripts/app.min.js')}}" type="text/javascript"></script>
            <script src="{{url('assets/global/plugins/bootstrap-fileinput/bootstrap-fileinput.js')}}" type="text/javascript"></script>
            <script src="{{url('/assets/global/plugins/bootstrap-toastr/toastr.min.js')}}" type="text/javascript"></script>
            <script src="{{url('/assets/pages/scripts/ui-toastr.min.js')}}" type="text/javascript"></script>
            <script src="{{url('assets/layouts/layout2/scripts/layout.min.js')}}" type="text/javascript"></script>
            <script src="{{url('assets/layouts/layout2/scripts/demo.min.js')}}" type="text/javascript"></script>
            <script src="{{url('assets/layouts/global/scripts/quick-sidebar.min.js')}}" type="text/javascript"></script>
            <script src="{{url('assets/layouts/global/scripts/quick-nav.min.js')}}" type="text/javascript"></script>
            <script src="{{ url('assets/vendors/js/extensions/sweetalert.min.js') }}" type="text/javascript"></script>
            <script src="{{ url('assets/js/scripts/extensions/sweet-alerts.js') }}" type="text/javascript"></script>
            <script src="//cdn.ckeditor.com/4.5.7/standard/ckeditor.js"></script>
            <!-- <script src="{{url('assets/global/plugins/datatables/datatables.min.js')}}" type="text/javascript"></script> -->
            <script>
                $('.alert').delay(3000).fadeOut( "slow" );
                $('.test').delay(3000).fadeOut( "slow" );
                $('.tests').delay(3000).fadeOut( "slow" );
            </script>
        </div>
