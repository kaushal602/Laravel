<head>
    <meta charset="utf-8" />
    <title>Dashboard</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <meta content="#1 selling multi-purpose bootstrap admin theme sold in themeforest marketplace packed with angularjs, material design, rtl support with over thausands of templates and ui elements and plugins to power any type of web applications including saas and admin dashboards. Preview page of Theme #2 for blank page layout"
        name="description" />
    <meta content="" name="author" />
</head>
@include('include.header')
<div class="page-content-wrapper">
    <div class="page-content">
        <h1 class="page-title"> Change Password </h1>
        <div class="row">
            <div class="col-md-12">
                <div class="portlet light">
                    <form role="form" action="{{url('changepassword')}}" method="post">
                        <?php if($errors->first('errmsg')!=NULL){ ?>
                            <div class="alert alert-danger display-hide" style="display: block;">
                                <button class="close" data-close="alert"></button>
                                <span> {{$errors->first('errmsg')}} </span>
                            </div>
                        <?php } ?>
                        <?php if($errors->first('sucmsg')!=NULL){ ?>
                            <div class="alert alert-success display-hide" style="display: block;">
                                <button class="close" data-close="alert"></button>
                                <span> {{$errors->first('sucmsg')}} </span>
                            </div>
                        <?php } ?>
                        <div class="form-body">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Old Password</label>
                                        <div class="input-group">
                                            <span class="input-group-addon">
                                                <i class="fa fa-lock"></i>
                                            </span>
                                            <input type="password" name="oldpassword" class="form-control" placeholder="Old Password" required>
                                        </div>
                                        <span class="red">{{$errors->first('oldpassword')}}</span>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>New Password</label>
                                        <div class="input-group">
                                            <span class="input-group-addon">
                                                <i class="fa fa-lock"></i>
                                            </span>
                                            <input type="password" name="newpassword" class="form-control" placeholder="New Password" required>
                                        </div>
                                        <span class="red">{{$errors->first('newpassword')}}</span>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Confirm Password</label>
                                        <div class="input-group">
                                            <span class="input-group-addon">
                                                <i class="fa fa-lock"></i>
                                            </span>
                                            <input type="password" name="confpassword" class="form-control" placeholder="Confirm Password" required>
                                        </div>
                                        <span class="red">{{$errors->first('confpassword')}}</span>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <button type="submit" class="btn blue pull-right">Submit</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@include('include.footer')