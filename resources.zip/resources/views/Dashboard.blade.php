		@include('include.header')
		<div class="page-content-wrapper">
		    <div class="page-content">
		        <h1 class="page-title"> Dashboard </h1>
		        <div class="row widget-row">
		        	<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                        <a class="dashboard-stat dashboard-stat-v2 blue" href="#">
                            <div class="visual">
                                <i class="fa fa-comments"></i>
                            </div>
                            <div class="details">
                                <div class="number">
                                    <span data-counter="counterup" data-value="<?php echo count($userlist); ?>"><?php echo count($userlist); ?></span>
                                </div>
                                <div class="desc"> Total User </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                        <a class="dashboard-stat dashboard-stat-v2 red" href="#">
                            <div class="visual">
                                <i class="fa fa-bar-chart-o"></i>
                            </div>
                            <div class="details">
                                <div class="number">
                                    <span data-counter="counterup" data-value="<?php echo count($eventlist); ?>"><?php echo count($eventlist); ?></span>
                                </div>
                                <div class="desc"> Total Event </div>
                            </div>
                        </a>
                    </div>       
		        </div>	
		    </div>
		</div>
		@include('include.footer')
    </body>
</html>