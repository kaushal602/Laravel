@include('include.header')
		<div class="page-content-wrapper">
		    <div class="page-content">
                <div class="page-bar">
			        <ul class="page-breadcrumb">
			            <li><i class="icon-home"></i> <a href="{{url('')}}">Dashboard</a> <i class="fa fa-angle-right"></i></li>
			            <li><span class="active">Event List</span></li>
			        </ul>
			    </div>
		        <div class="row">
		            <div class="col-md-12 col-sm-12">
		                <!-- BEGIN EXAMPLE TABLE PORTLET-->
		                <div class="portlet light portlet-fit portlet-datatable bordered">
		                    <div class="portlet-title">
                                <div class="caption font-red-sunglo">
                                    <i class="icon-settings font-red-sunglo"></i>
                                    <span class="caption-subject bold uppercase">Event List</span>
                                </div>
                            </div>
		                    <div class="portlet-body">
		                        <table class="table table-striped table-bordered table-hover order-column" id="sample_2">
		                            <thead>
		                                <tr>
		                                    <th> Event Id </th>
		                                    <th> Name </th>
		                                    <th> Event Type </th>
		                                    <th> Event Date </th>
		                                    <th> StartTime </th>
		                                    <th> EndTime </th>
		                                    <th> Address </th>
		                                    <th> Latitude </th>
		                                    <th> Longitude </th>
		                                    <th> View </th>
		                                </tr>
		                            </thead>
		                        </table>
		                    </div>
		                </div>
		                <!-- END EXAMPLE TABLE PORTLET-->
		            </div>
		        </div>
		    </div>
		</div>
		@include('include.footer')
		<script>
			var sucesstitle = '{{$errors->first('sucmsg')}}';
            if(sucesstitle!=''){
                toastr.success(sucesstitle);
            }
			//var url2 = "{{url('userlist')}}";
		    jQuery(document).ready(function() {
		        jQuery('#sample_2').DataTable( {
		            "processing": true,
		            "serverSide": true,
		            "sPaginationType": "full_numbers",
		            "ajax": "{{('geteventlist')}}",
		            "fnRowCallback": function( nRow, aData, iDisplayIndex ) {
		            	$('td:eq(8)', nRow).html('<a href="{{url('viewevent')}}/' + aData[0] + '" class="tooltipped"><i class="fa fa-eye" aria-hidden="true"></i></a>');
                        return nRow;
		            },
		            "columnDefs": [
		            {
		                "targets": [0],
		                "visible": false,
		            }]
		        } );
		    } );

		    function deleteuser(url1){
                var r = confirm("Are you sure? You want to Delete.");
                if (r == true) {
                    window.location = url1;
                }
            }
		</script>
    </body>
</html>

