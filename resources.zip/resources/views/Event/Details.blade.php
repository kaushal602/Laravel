@include('include.header')
		<div class="page-content-wrapper">
		    <div class="page-content">
                <div class="page-bar">
			        <ul class="page-breadcrumb">
			            <li><i class="icon-home"></i> <a href="{{url('')}}">Dashboard</a> <i class="fa fa-angle-right"></i></li>
			            <li><span class="active">Event Details</span></li>
			        </ul>
			    </div>
                <div class="spacer"></div>
		        <div class="row">
		            <div class="col-md-12 col-sm-12">
		                <!-- BEGIN EXAMPLE TABLE PORTLET-->
		                <div class="portlet light bordered">
		                    <div class="portlet-title">
                                <div class="caption font-red-sunglo">
                                    <i class="icon-settings font-red-sunglo"></i>
                                    <span class="caption-subject bold uppercase">Event Details</span>
                                </div>
                            </div>
		                    <div class="portlet-body form">
		                        <form role="form" class="event-detail-box" action="#">
		                        	<div class="form-body">
                                        <div class="row">
                                        	<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
			                                    <div class="form-group">
			                                        <label class="control-label">Event Name</label>
			                                        <input placeholder="" value="{{$Data->EventName}}" class="form-control" type="text" readonly> 
			                                    </div>
			                                </div>
			                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
			                                    <div class="form-group">
			                                        <label class="control-label">Event Type</label>
			                                        <input placeholder="" value="{{$Data->EventType}}" class="form-control" type="text" readonly> 
			                                    </div>
			                                </div>
			                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
			                                    <div class="form-group">
			                                        <label class="control-label">Event Date</label>
			                                        <input placeholder="" value="<?= date('d-m-Y', strtotime($Data->EventDate));?>" class="form-control" type="text" readonly> 
			                                    </div>
			                                </div>
			                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
			                                    <div class="form-group">
			                                        <label class="control-label">Start Time</label>
			                                        <input placeholder="" value="{{$Data->StartTime}}" class="form-control" type="text" readonly> 
			                                    </div>
			                                </div>
			                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
			                                    <div class="form-group">
			                                        <label class="control-label">End Time</label>
			                                        <input placeholder="" value="{{$Data->EndTime}}" class="form-control" type="text" readonly> 
			                                    </div>
			                                </div>
			                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
			                                    <div class="form-group">
			                                        <label class="control-label">Address</label>
			                                        <textarea class="form-control" rows="3" placeholder="" readonly>{{$Data->Address}}</textarea>
			                                    </div>
			                                </div>
			                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
			                                    <div class="form-group">
			                                        <label class="control-label">Description</label>
			                                        <textarea class="form-control" rows="8" placeholder="" readonly>{{$Data->EventDescription}}</textarea>
			                                    </div>
			                                </div>
		                                </div>
	                                </div>
                                </form>
		                    </div>
		                </div>
		                <!-- END EXAMPLE TABLE PORTLET-->
		            </div>
		        </div>
		    </div>
		</div>
		@include('include.footer')
		
    </body>
</html>

