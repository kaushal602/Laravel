<?php
$table = 'event_master';
$primaryKey = 'EventId';
$columns = array(
    array( 'db' => 'EventId', 'dt' => 0, 'field' => 'EventId' ),
    array( 'db' => 'EventName',  'dt' => 1, 'field' => 'EventName' ),
    array( 'db' => 'EventType',   'dt' => 2, 'field' => 'EventType'  ),
    array( 'db' => 'EventDate',   'dt' => 3, 'field' => 'EventDate' ),
    array( 'db' => 'StartTime',   'dt' => 4, 'field' => 'StartTime'  ),
    array( 'db' => 'EndTime',   'dt' => 5, 'field' => 'EndTime'  ),
    array( 'db' => 'Address',   'dt' => 6, 'field' => 'Address' ),
    array( 'db' => 'Latitude',   'dt' => 7, 'field' => 'Latitude' ),
    array( 'db' => 'Longitude',   'dt' => 8, 'field' => 'Longitude' ),
    array( 'db' => 'EventId', 'dt' => 9, 'field' => 'EventId' ),

    //array( 'db' => "CONCAT('CountryCode','','Mobile')", 'dt'=> 10, 'as' => 'FinInvId1', 'field' => 'FinInvId1' ),
);
$sql_details = array(
    'user' => env('DB_USERNAME'),
    'pass' => env('DB_PASSWORD'),
    'db'   => env('DB_DATABASE'),
    'host' => env('DB_HOST')
);
//$where = "IsActive =1 AND UserId != 1";
require( 'ssp.class.php' );
echo json_encode(
    SSP::simple( $_GET, $sql_details, $table, $primaryKey, $columns )
);
?>