@include('include.header')
		<div class="page-content-wrapper">
		    <div class="page-content">
                <div class="page-bar">
			        <ul class="page-breadcrumb">
			            <li><i class="icon-home"></i> <a href="{{url('')}}">Dashboard</a> <i class="fa fa-angle-right"></i></li>
			            <li><span class="active">User List</span></li>
			        </ul>
			    </div>
		        <div class="row">
		            <div class="col-md-12 col-sm-12">
		                <!-- BEGIN EXAMPLE TABLE PORTLET-->
		                <div class="portlet light portlet-fit portlet-datatable bordered">
		                    <div class="portlet-title">
                                <div class="caption font-red-sunglo">
                                    <i class="icon-settings font-red-sunglo"></i>
                                    <span class="caption-subject bold uppercase">User List</span>
                                </div>
                            </div>
		                    <div class="portlet-body">
		                        <table class="table table-striped table-bordered table-hover order-column" id="sample_2">
		                            <thead>
		                                <tr>
		                                    <th> User Id </th>
		                                    <th> Name </th>
		                                    <th> Email </th>
		                                    <th> CountryName </th>
		                                    <th> PostCode </th>
		                                    <th> Mobile </th>
		                                    <th> Address </th>
		                                    <th> IsActive </th>
		                                    <th style="width: 40px;"> Action </th>
		                                </tr>
		                            </thead>
		                        </table>
		                    </div>
		                </div>
		                <!-- END EXAMPLE TABLE PORTLET-->
		            </div>
		        </div>
		    </div>
		</div>
		@include('include.footer')
		<script>
			var sucesstitle = '{{$errors->first('sucmsg')}}';
            if(sucesstitle!=''){
                toastr.success(sucesstitle);
            }
            var CSRF_TOKEN = jQuery('meta[name="csrf-token"]').attr('content');
			//var url2 = "{{url('userlist')}}";
		    jQuery(document).ready(function() {
		    	resettbl();
		    });
		    function resettbl(){
                jQuery('#sample_2').DataTable().destroy();
		        jQuery('#sample_2').DataTable( {
		            "processing": true,
		            "serverSide": true,
		            "sPaginationType": "full_numbers",
		            "ajax": "{{('getuserlist')}}",
		            "fnRowCallback": function( nRow, aData, iDisplayIndex ) {
		            	var ist =''; if(aData[7]==1){ ist ='checked'; }
          				$('td:eq(6)', nRow).html('<div class="ckbox ckbox-success tooltipped" onchange="abc(IsActive_'+ aData[0] +')"><input id="IsActive_'+ aData[0] +'" class="IsActive" '+ist+' type="checkbox"><label for="IsActive_'+ aData[0] +'"></label></div>');
          				$('td:eq(4)', nRow).html( aData[9] + aData[5] );
		            },
		            "columnDefs": [
		            {
		                "targets": [0,9],
		                "visible": false,
		            }]
		        } );
		    }

		    function deleteuser(url1){
                var r = confirm("Are you sure? You want to Delete.");
                if (r == true) {
                    window.location = url1;
                }
            }

            function abc(ab) {
              var cl = jQuery(ab).attr('class');
              var id = jQuery(ab).attr('id');
              if(cl=='IsActive'){
                var url1 = "{{url('userstatus')}}";
                var r = confirm("Are you sure? You want to changed status.");
                UserId = id.replace('IsActive_','');
                if (r == true) {
                  if(document.getElementById(id).checked) {
                      jQuery.post(url1, {UserId: UserId,status: 'y',_token: CSRF_TOKEN}, function(result){
                          //alert(result);
                          toastr.success('Advertise IsActive successfully');
                             resettbl();
                      });
                  } else {
                      jQuery.post(url1, {UserId: UserId,status: 'n',_token: CSRF_TOKEN}, function(result){
                          //alert(result);
                          toastr.success('Advertise DeActive successfully');
                             resettbl();
                      });
                  }
                }else{
                  if(document.getElementById(id).checked) {
                    jQuery("#"+id).prop('checked', false);
                  } else {
                    jQuery("#"+id).prop('checked', true);
                  }
                }
              }
            }

		</script>
    </body>
</html>

