<?php
$table = 'user_master';
$primaryKey = 'UserId';
$columns = array(
    array( 'db' => 'UserId', 'dt' => 0, 'field' => 'UserId' ),
    array( 'db' => 'Name',  'dt' => 1, 'field' => 'Name' ),
    array( 'db' => 'UserEmail',   'dt' => 2, 'field' => 'UserEmail'  ),
    array( 'db' => 'CountryName',   'dt' => 3, 'field' => 'CountryName'  ),
    array( 'db' => 'PostCode',   'dt' => 4, 'field' => 'PostCode' ),
    array( 'db' => 'Mobile',   'dt' => 5, 'field' => 'Mobile'  ),
    array( 'db' => 'Address',   'dt' => 6, 'field' => 'Address'  ),
    array( 'db' => 'IsActive',   'dt' => 7, 'field' => 'IsActive' ),
    array( 'db' => 'UserId', 'dt' => 8, 'field' => 'UserId', 'formatter' => function( $d) { return '<a href="javascript:void(0);" onclick=deleteuser("'.url('deleteuser/'.$d).'") class="tooltipped"><i class="icon-trash"></i></a>';}),
    array( 'db' => 'CountryCode',   'dt' => 9, 'field' => 'CountryCode'  ),

    //array( 'db' => "CONCAT('CountryCode','','Mobile')", 'dt'=> 10, 'as' => 'FinInvId1', 'field' => 'FinInvId1' ),
);
$sql_details = array(
    'user' => env('DB_USERNAME'),
    'pass' => env('DB_PASSWORD'),
    'db'   => env('DB_DATABASE'),
    'host' => env('DB_HOST')
);
$where = "IsActive =1 AND UserId != 1";
require( 'ssp.class.php' );
echo json_encode(
    SSP::simple( $_GET, $sql_details, $table, $primaryKey, $columns, $where )
);
?>