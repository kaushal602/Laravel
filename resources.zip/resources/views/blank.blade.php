<meta charset="utf-8" />
<title>Investigator</title>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta content="width=device-width, initial-scale=1" name="viewport" />

<meta content="" name="author" />
</head>
@include('include.header')
<div class="page-content-wrapper">
    <div class="page-content">
        <h1 class="page-title"> Blank Page Layout </h1>
        <div class="note note-info">
            <p> A black page template with a minimal dependency assets to use as a base for any custom page you create </p>
        </div>
    </div>
</div>
@include('include.footer')