@include('include.header')
                <div class="page-content-wrapper">
                    <div class="page-content">
                        <div class="page-bar">
                            <ul class="page-breadcrumb">
                                <li><i class="icon-home"></i> <a href="{{url('')}}">Home</a> <i class="fa fa-angle-right"></i></li>
                                <li><span>Edit Country</span></li>
                            </ul>
                        </div>
                        <!-- <h1 class="page-title">Edit Page</h1>
                        <span class="rghtbtn">
                            <a href="{{url('admin/pagelist')}}">Page List</a>
                        </span> -->
                        <div class="spacer"></div>
                        <div class="row">
                            <div class="col-md-12 ">
                                <div class="portlet light bordered">
                                    <div class="portlet-title">
                                        <div class="caption font-red-sunglo">
                                            <i class="icon-settings font-red-sunglo"></i>
                                            <span class="caption-subject bold uppercase">Edit Country</span>
                                        </div>
                                    </div>
                                    <div class="portlet-body form">
                                        <div class="table-toolbar">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="btn-group">
                                                        <a class="btn btn-sm green " href="{{url('countrylist')}}" > Country List <i class="fa fa-plus"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <form role="form" method="post" id="addpage" action="{{url('editcountrydetails')}}" enctype="multipart/form-data">
                                        {{csrf_field()}}
                                            <div class="form-body">
                                                <div class="row">
                                                    <input type="hidden" name="CountryId" id="CountryId" value="{{$Data->CountryId}}">
                                                    <div class="col-md-4">
                                                        <div class="form-group">
                                                            <label>Country Name<span class="requierd-box">*</span></label>
                                                            <div class="form-group">
                                                                <input type="text" class="form-control" value="{{$Data->CountryName}}" name="CountryName" id="CountryName" required>
                                                            </div>
                                                            <span class="font-red-thunderbird"></span>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <div class="form-group">
                                                            <label>Country Iso Code<span class="requierd-box">*</span></label>
                                                            <div class="form-group">
                                                                <input type="text" class="form-control" value="{{$Data->CountriesIsoCode}}" name="CountriesIsoCode" id="CountriesIsoCode" required>
                                                            </div>
                                                            <span class="font-red-thunderbird"></span>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <div class="form-group">
                                                            <label>Country Isd Code<span class="requierd-box">*</span></label>
                                                            <div class="form-group">
                                                                <input type="text" class="form-control" value="{{$Data->CountriesIsdCode}}" name="CountriesIsdCode" id="CountriesIsdCode" required>
                                                            </div>
                                                            <span class="font-red-thunderbird"></span>
                                                        </div>
                                                    </div>
                                                    <div class="form-actions col-md-12">
                                                        <div class="col-md-11 err">
                                                            <p id="error"></p>
                                                        </div>
                                                        <button type="submit" class="btn blue">Update</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

        @include('include.footer')
        <script type="text/javascript">
             var sucesstitle = '{{$errors->first('sucmsg')}}';
                if(sucesstitle!=''){
                    toastr.success(sucesstitle);
                }
            window.onload = function () {
    //for gallery images
            var imagegallery = document.getElementById("imagegallery");
            imagegallery.onchange = function () {
                if (typeof (FileReader) != "undefined") {
                    var dvPreview = document.getElementById("imgpre");
                    //dvPreview.innerHTML = "";
                    jQuery(".imgtcl").remove();
                    var regex = /^([a-zA-Z0-9\s_\\.\-:])+(.jpg|.jpeg|.gif|.png|.bmp)$/;
                    var tmpvar = 0;
                    for (var i = 0; i < imagegallery.files.length; i++) {
                        var file = imagegallery.files[i];
                        if (regex.test(file.name.toLowerCase())) {
                            var reader = new FileReader();
                            reader.onload = function (e) {
                                jQuery("#imgpre").prepend("<div class='col-lg-3 col-md-3 col-sm-3 col-xs-12 imgtcl imgtcl"+tmpvar+"'><div class='img-butt-box'><img src='"+e.target.result+"' style='width: 200px;height: 150px'><input class='lava-add-item-map-search-find' value='Delete' onclick=deltimg('"+tmpvar+"') type='button'></div></div>");
                                tmpvar++;
                            }
                            reader.readAsDataURL(file);
                        } else {
                            alert(file.name + " is not a valid image file.");
                            //dvPreview.innerHTML = "";
                            jQuery(".imgtcl").remove();
                            return false;
                        }
                    }
                } else {
                    alert("This browser does not support HTML5 FileReader.");
                }
            }
        }
        function deltimg(imgid){
            jQuery("#deletetimages").val((jQuery("#deletetimages").val())+" "+imgid);
            jQuery(".imgtcl"+imgid).remove();
        }
        </script>
    </body>
</html>