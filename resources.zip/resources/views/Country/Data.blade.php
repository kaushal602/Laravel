<?php
$table = 'apps_countries';
$primaryKey = 'CountryId';
$columns = array(
    array( 'db' => '`u`.`CountryId`',           'dt'=> 0, 'field' => 'CountryId' ),
    array( 'db' => '`u`.`CountryName`',         'dt'=> 1, 'field' => 'CountryName' ),
    array( 'db' => '`u`.`CountriesIsoCode`',         'dt'=> 2, 'field' => 'CountriesIsoCode' ),
    array( 'db' => '`u`.`CountriesIsdCode`',         'dt'=> 3, 'field' => 'CountriesIsdCode' ),
    array( 'db' => '`u`.`IsActive`',         'dt'=> 4, 'field' => 'IsActive' ),
    array( 'db' => '`u`.`CountryId`',         'dt'=> 5, 'field' => 'CountryId' ),
);
$sql_details = array(
    'user' => env('DB_USERNAME'),
    'pass' => env('DB_PASSWORD'),
    'db'   => env('DB_DATABASE'),
    'host' => env('DB_HOST')
);
$joinQuery = "FROM `apps_countries` AS `u`";
//$id = session()->get('subjectdata')['CompanyId'];
//require( 'ssp.class.php' );
//$groupBy = '`u`.`EventTypeName`';
require( 'ssp.customized.class.php' );
echo json_encode(
    SSP::simple( $_GET, $sql_details, $table, $primaryKey, $columns, $joinQuery )
);
?>