<style>
    .email-error-box{
        display: none;
    }
</style>
@include('include.header')
<div class="page-content-wrapper">
    <div class="page-content">
        <h1 class="page-title"> Edit Profile </h1>
        <div class="row">
            <div class="col-md-12">
                <div class="portlet light">
                    <form role="form" action="{{url('editprofiledetail')}}" method="post" enctype="multipart/form-data" name="register-form"  onsubmit="return validateRegisterForm();">
                        <?php if($errors->first('errmsg')!=NULL){ ?>
                            <div class="alert alert-danger display-hide" style="display: block;">
                                <button class="close" data-close="alert"></button>
                                <span> {{$errors->first('errmsg')}} </span>
                            </div>
                        <?php } ?>
                        <?php if($errors->first('sucmsg')!=NULL){ ?>
                            <div class="alert alert-success display-hide" style="display: block;">
                                <button class="close" data-close="alert"></button>
                                <span> {{$errors->first('sucmsg')}} </span>
                            </div>
                        <?php } foreach ($data as $key) {
                            $mobile = $key->Mobile;
                            $displaynam = $key->DisplayName;
                            $email = $key->Email;
                            $logo = $key->Photo;
                        } ?>
                        <div class="form-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Telephone</label>
                                        <div class="input-group">
                                            <span class="input-group-addon">
                                                <i class="fa fa-lock"></i>
                                            </span>
                                            <input type="text" name="telephone" class="form-control" placeholder="Telephone" value="<?php echo $mobile; ?>" >
                                        </div>
                                        <div class="email-error-box" id="phone-errors" style="color: red;">
                                            <span id="phone-error-message">Please Add Telephone</span>
                                        </div>
                                       
                                    </div>
                                    <div class="form-group">
                                        <label>Display Name</label>
                                        <div class="input-group">
                                            <span class="input-group-addon">
                                                <i class="fa fa-lock"></i>
                                            </span>
                                            <input type="text" name="displayname" class="form-control" value="<?php echo $displaynam; ?>" placeholder="Display Name">
                                        </div>
                                        <div class="email-error-box" id="displaynam-errors" style="color: red;">
                                            <span id="displaynam-error-message">Please Add Display Name</span>
                                        </div>
                                        
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Email</label>
                                        <div class="input-group">
                                            <span class="input-group-addon">
                                                <i class="fa fa-lock"></i>
                                            </span>
                                            <input type="text" name="email" class="form-control" placeholder="Email" value="<?php echo $email; ?>">
                                        </div>
                                        <div class="email-error-box" id="email-errors" style="color: red;">
                                            <span id="email-error-message">Please Add Email Name</span>
                                        </div>
                                        
                                    </div>
                                    <div class="form-group ">
                                        <label class="control-label col-md-2">Photo</label>
                                        <div class="col-md-9">
                                            <div class="fileinput fileinput-new" data-provides="fileinput">
                                                <div class="fileinput-preview thumbnail" data-trigger="fileinput" style="width: 200px; height: 150px;">
                                                    <?php if(!empty($logo)){ ?> <img src="{{url('').('/public/images/'.$logo)}}"> <?php } ?>
                                                 </div>
                                                <div>
                                                    <span class="btn red btn-outline btn-file">
                                                        <span class="fileinput-new"> Select image </span>
                                                        <span class="fileinput-exists"> Change </span>
                                                        <input type="file" name="logo" id="logo"> </span>
                                                    <a href="javascript:;" class="btn red fileinput-exists" data-dismiss="fileinput"> Remove </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <button type="submit" class="btn blue pull-right">Submit</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    function validateRegisterForm(){
    var email = document.forms["register-form"]["email"].value;
    var emailformat = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    var mobile = document.forms["register-form"]["telephone"].value;
    var displayname = document.forms["register-form"]["displayname"].value;
    //alert(displayname);
    var status;
  // alert(userrole);
    
    if(mobile==""){
            $("#phone-errors").show();
            $("#phone-error-message").html("Please Enter Telephone");
            status = false;
            return false;
        }else{
            if($.isNumeric(mobile)){
                var length = mobile.length;
                if(length==10){
                    status = true;
                }else{
                    //alert("String");
                    $("#phone-errors").show();
                    $("#phone-error-message").html("Please Enter 10 Digit Number");
                    status = false;
                    return false; 
                }
            
            }else{
                $("#phone-errors").show();
                $("#phone-error-message").html("Please Enter Number");
                status = false;
                return false;
            }
        }
        if(email== ""){
            $("#email-errors").show();
            $("#email-error-message").html("Please Enter Email");
            status = false;
            return false;
        }else {
            if(!emailformat.test(String(email).toLowerCase())){
                $("#email-errors").show();
                $("#email-error-message").html("Please Enter Valid Email");
                status = false;
                return false;
            }else{
                $("#email-errors").hide();
                status = true;
                
            }
        }
        if(displayname==""){
            $("#displaynam-errors").show();
            $("#displaynam-error-message").html("Please Enter Display Name");
            return false;
            status = false;
        }else{
             $("#displaynam-errors").hide();
                status = true;
        }
            
        return status;
        }
    
    
</script>
@include('include.footer')