@include('include.header')
                <div class="page-content-wrapper">
                    <div class="page-content">
                        <div class="page-bar">
                            <ul class="page-breadcrumb">
                                <li><i class="icon-home"></i> <a href="{{url('')}}">Home</a> <i class="fa fa-angle-right"></i></li>
                                <li><span>Language List</span></li>
                            </ul>
                        </div>
                        <div class="spacer"><?php echo '<p>'.session()->get('pageupdate').'</p>'; ?><?php session()->forget('pageupdate'); ?></div>
                        <div class="row">
                            <div class="col-md-12 ">
                                <div class="portlet light bordered">
                                    <div class="portlet-title">
                                        <div class="caption font-red-sunglo">
                                            <i class="icon-settings font-red-sunglo"></i>
                                            <span class="caption-subject bold uppercase">Language List</span>
                                        </div>
                                    </div>
                                    <div class="portlet-body">
                                        <div class="table-toolbar">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="btn-group">
                                                         <a class="btn btn-sm green " href="{{url('addlanguage')}}" >  Add Language <i class="fa fa-plus"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_1">
                                            <thead>
                                                <tr>
                                                    <th>LanguageId</th>
                                                    <th>Language Name</th>
                                                    <th>Language Code</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>

                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

        @include('include.footer')
        <script>
            var sucesstitle = '{{$errors->first('sucmsg')}}';
            if(sucesstitle!=''){
                toastr.success(sucesstitle);
            }
        </script>
        <script>
            var CSRF_TOKEN = jQuery('meta[name="csrf-token"]').attr('content');
            jQuery(document).ready(function(){;
                resettbl();
            });
            function resettbl(){
                jQuery('#sample_1').DataTable().destroy();
                jQuery('#sample_1').dataTable({
                    "processing": true,
                    "serverSide": true,
                    "sPaginationType": "full_numbers",
                    "aaSorting": [ [0,'desc'] ],
                    "ajax": "{{url('getlanguagelist')}}",
                    "fnRowCallback": function( nRow, aData, iDisplayIndex ) {
                       
                        $('td:eq(2)', nRow).html('<a href="{{url('editlanguage')}}/' + aData[0] + '" class="tooltipped"><i class="fa fa-pencil"></i></a> &nbsp;&nbsp;<a href="javascript:void(0)" onclick="deletepage('+aData[0]+')" class="tooltipped"><i class="fa fa-trash-o"></i></a>');
                        return nRow;
                    },
                    "columnDefs": [
                    {
                        "targets": [ 0 ],
                        "visible": false,
                    }]
                }); 
            }
            

            
            function deletepage(ab){
                var url1 = "{{url('deletelanguage')}}";
                var r1 = confirm("Are you sure? You want to delete Language.");
                if (r1 == true) {
                    jQuery.ajax({
                        url: url1,
                        data: {LanguageId:ab},
                        type: 'POST',
                        beforeSend: function () { },
                        complete: function () {},
                        success: function (result) {
                            toastr.success('Language deleted successfully');
                             resettbl();
                        }
                    })
                }
            }
        </script>
    </body>
</html>