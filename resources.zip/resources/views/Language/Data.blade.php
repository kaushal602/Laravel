<?php
$table = 'language_master';
$primaryKey = 'LanguageId';
$columns = array(
    array( 'db' => '`u`.`LanguageId`',           'dt'=> 0, 'field' => 'LanguageId' ),
    array( 'db' => '`u`.`LanguageName`',         'dt'=> 1, 'field' => 'LanguageName' ),
    array( 'db' => '`u`.`LanguageCode`',         'dt'=> 2, 'field' => 'LanguageCode' ),
    array( 'db' => '`u`.`LanguageId`',         'dt'=> 3, 'field' => 'LanguageId' ),
);
$sql_details = array(
    'user' => env('DB_USERNAME'),
    'pass' => env('DB_PASSWORD'),
    'db'   => env('DB_DATABASE'),
    'host' => env('DB_HOST')
);
$joinQuery = "FROM `language_master` AS `u`";
//$id = session()->get('subjectdata')['CompanyId'];
//$where = "`u`.`IsActive` =1";
//require( 'ssp.class.php' );
//$groupBy = '`u`.`EventTypeName`';
require( 'ssp.customized.class.php' );
echo json_encode(
    SSP::simple( $_GET, $sql_details, $table, $primaryKey, $columns, $joinQuery )
);
?>