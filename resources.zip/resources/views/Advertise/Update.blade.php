@include('include.header')
                <div class="page-content-wrapper">
                    <div class="page-content">
                            <ul class="page-breadcrumb breadcrumb">
                                <li><i class="icon-home"></i> <a href="{{url('')}}">Home</a></li>
                                <li><span>Edit Advertise</span></li>
                            </ul>
                        <!-- <h1 class="page-title">Edit Page</h1>
                        <span class="rghtbtn">
                            <a href="{{url('admin/pagelist')}}">Page List</a>
                        </span> -->
                        <div class="spacer"></div>
                        <div class="row">
                            <div class="col-md-12 ">
                                <div class="portlet light bordered">
                                    <div class="portlet-title">
                                        <div class="caption font-red-sunglo">
                                            <i class="icon-settings font-red-sunglo"></i>
                                            <span class="caption-subject bold uppercase">Edit Advertise</span>
                                        </div>
                                    </div>
                                    <div class="portlet-body form">
                                        <div class="table-toolbar">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="btn-group">
                                                        <a class="btn btn-sm green " href="{{url('advertiselist')}}" > Advertise List <i class="fa fa-plus"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <form role="form" method="post" id="addpage" action="{{url('editadvertisedetails')}}" enctype="multipart/form-data">
                                        {{csrf_field()}}
                                            <div class="form-body">
                                                <div class="row">
                                                    <input type="hidden" name="AdvertiseId" id="AdvertiseId" value="{{$Data->AdvertiseId}}">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label>Advertise Name<span class="requierd-box">*</span></label>
                                                            <div class="form-group">
                                                                <input type="text" class="form-control" value="{{$Data->AdvertiseTitle}}" name="AdvertiseTitle" id="AdvertiseTitle" required>
                                                            </div>
                                                            <span class="font-red-thunderbird"></span>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label>Advertise Url<span class="requierd-box">*</span></label>
                                                            <div class="form-group">
                                                                <input type="text" class="form-control" value="{{$Data->AdvertiseUrl}}" name="AdvertiseUrl" id="AdvertiseUrl" required>
                                                            </div>
                                                            <span class="font-red-thunderbird"></span>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label>Language Code<span class="requierd-box">*</span></label>
                                                            <div class="form-group">
                                                                 <select name="LanguageCode" id="LanguageCode" class="form-control">
                                                                    <?php foreach ($Language as $key => $value) { ?>
                                                                        <option value="<?= $value->LanguageCode; ?>" <?= ($value->LanguageCode=$Data->LanguageCode?'selected':'') ?>><?= $value->LanguageName; ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                            </div>
                                                            <span class="font-red-thunderbird"></span>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label>Advertise Image<span class="requierd-box">*</span></label>
                                                            <div class="fileinput fileinput-new" data-provides="fileinput">
                                                        <div class="input-group input-large">
                                                            <div class="form-control uneditable-input input-fixed input-medium" data-trigger="fileinput">
                                                                <i class="fa fa-file fileinput-exists"></i>&nbsp;
                                                                <span class="fileinput-filename"> </span>
                                                            </div>
                                                            <span class="input-group-addon btn default btn-file">
                                                                <span class="fileinput-new"> Select file </span>
                                                                <span class="fileinput-exists"> Change </span>
                                                                <input type="file" name="AdvertiseImage"  onchange="readURL(this);" id="AdvertiseImage" > </span>
                                                            <a href="javascript:;" class="input-group-addon btn red fileinput-exists" data-dismiss="fileinput"> Remove </a>
                                                        </div>
                                                    </div><!-- 
                                                            <div class="">
                                                                <input type="file" class="" value="{{old('AdvertiseImage')}}" onchange="readURL(this);" name="AdvertiseImage" id="AdvertiseImage">
                                                            </div> -->
                                                            <span class="font-red-thunderbird">{{$errors->first('AdvertiseImage')}}</span>
                                                        </div>
                                                        <span class="red AdvertiseImage">
                                                            <img id="asimage" src="{{url($Data->AdvertiseImage)}}" alt="your image" width="150" />
                                                        </span>
                                                    </div>
                                                    <div class="form-actions col-md-12 btn-align">
                                                        <button type="submit" class="btn blue">Update</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

        @include('include.footer')
        <script>
            var sucesstitle = '{{$errors->first('sucmsg')}}';
            if(sucesstitle!=''){
                toastr.success(sucesstitle);
            }

            function readURL(input) {
                if (input.files && input.files[0]) {
                    var reader = new FileReader();
                    reader.onload = function (e) {
                        $('.red.AdvertiseImage').html('<img id="asimage" src="'+ e.target.result+'" alt="your image" width="150" />');
                    }
                    reader.readAsDataURL(input.files[0]);
                }
            }
        </script>
    </body>
</html>