@include('include.header')
                <div class="page-content-wrapper">
                    <div class="page-content">
                        <div class="page-bar">
                            <ul class="page-breadcrumb">
                                <li><i class="icon-home"></i> <a href="{{url('')}}">Home</a> <i class="fa fa-angle-right"></i></li>
                                <li><span>Advertise List</span></li>
                            </ul>
                        </div>
                        <!-- <h1 class="page-title"> Page List </h1>
                        <span class="rghtbtn">
                            <a href="{{url('admin/addpage')}}">Add Page</a>
                        </span> -->
                        <div class="spacer"><?php echo '<p>'.session()->get('pageupdate').'</p>'; ?><?php session()->forget('pageupdate'); ?></div>
                        <div class="row">
                            <div class="col-md-12 ">
                                <div class="portlet light bordered">
                                    <div class="portlet-title">
                                        <div class="caption font-red-sunglo">
                                            <i class="icon-settings font-red-sunglo"></i>
                                            <span class="caption-subject bold uppercase">Advertise List</span>
                                        </div>
                                    </div>
                                    <div class="portlet-body">
                                        <div class="table-toolbar">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="btn-group">
                                                        <a class="btn btn-sm green " href="{{url('addadvertise')}}" > Add Advertise <i class="fa fa-plus"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_1">
                                            <thead>
                                                <tr>
                                                    <th>AdvertiseId</th>
                                                    <th class="firstth">Title</th>
                                                    <th>Url</th>
                                                    <th>Language Code</th>
                                                    <th>Image</th>
                                                    <th>IsActive</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

        @include('include.footer')
        <script>
            var sucesstitle = '{{$errors->first('sucmsg')}}';
            if(sucesstitle!=''){
                toastr.success(sucesstitle);
            }
            var CSRF_TOKEN = jQuery('meta[name="csrf-token"]').attr('content');
            jQuery(document).ready(function(){;
                    resettbl();
            });
            function resettbl(){
                jQuery('#sample_1').DataTable().destroy();
                jQuery('#sample_1').dataTable({
                    "processing": true,
                    "serverSide": true,
                    "sPaginationType": "full_numbers",
                    "aaSorting": [ [0,'desc'] ],
                    "ajax": "{{url('getadvertiselist')}}",
                    "fnRowCallback": function( nRow, aData, iDisplayIndex ) {
                        $('td:eq(3)', nRow).html('<img id="asimage" src="{{url('')}}/' + aData[4] + '" alt="your image" width="150" />');
                        var ist =''; if(aData[5]==1){ ist ='checked'; }
                        $('td:eq(4)', nRow).html('<div class="ckbox ckbox-success tooltipped" onchange="abc(IsActive_'+ aData[0] +')"><input id="IsActive_'+ aData[0] +'" class="IsActive" '+ist+' type="checkbox"><label for="IsActive_'+ aData[0] +'"></label></div>');
                        $('td:eq(5)', nRow).html('<a href="{{url('editadvertise')}}/' + aData[0] + '" class="tooltipped"><i class="fa fa-pencil"></i></a> &nbsp;&nbsp;<a href="javascript:void(0)" onclick="deletepage('+aData[0]+')" class="tooltipped"><i class="fa fa-trash-o"></i></a>');
                        return nRow;
                    },
                    "columnDefs": [
                    {
                        "targets": [ 0 ],
                        "visible": false,
                    }]
                }); 
            }
            
            function abc(ab) {
              var cl = jQuery(ab).attr('class');
              var id = jQuery(ab).attr('id');
              if(cl=='IsActive'){
                var url1 = "{{url('advertisestatus')}}";
                var r = confirm("Are you sure? You want to changed status.");
                AdvertiseId = id.replace('IsActive_','');
                if (r == true) {
                  if(document.getElementById(id).checked) {
                      jQuery.post(url1, {AdvertiseId: AdvertiseId,status: 'y',_token: CSRF_TOKEN}, function(result){
                          //alert(result);
                          toastr.success('Advertise IsActive successfully');
                             resettbl();
                      });
                  } else {
                      jQuery.post(url1, {AdvertiseId: AdvertiseId,status: 'n',_token: CSRF_TOKEN}, function(result){
                          //alert(result);
                          toastr.success('Advertise DeActive successfully');
                             resettbl();
                      });
                  }
                }else{
                  if(document.getElementById(id).checked) {
                    jQuery("#"+id).prop('checked', false);
                  } else {
                    jQuery("#"+id).prop('checked', true);
                  }
                }
              }
            }
            
            function deletepage(ab){
                var url1 = "{{url('deleteadvertise')}}";
                var r1 = confirm("Are you sure? You want to delete Advertise.");
                if (r1 == true) {
                    jQuery.ajax({
                        url: url1,
                        data: {AdvertiseId:ab},
                        type: 'POST',
                        beforeSend: function () { },
                        complete: function () {},
                        success: function (result) {
                            toastr.success('Advertise deleted successfully');
                             resettbl();
                        }
                    })
                }
            }

            function delete1(url1){
                var r = confirm("Are you sure? You want to Delete.");
                if (r == true) {
                    window.location = url1;
                }
            }
        </script>
    </body>
</html>