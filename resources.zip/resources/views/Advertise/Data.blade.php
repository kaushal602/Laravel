<?php
$table = 'advertise_master';
$primaryKey = 'AdvertiseId';
$columns = array(
    array( 'db' => '`u`.`AdvertiseId`',           'dt'=> 0, 'field' => 'AdvertiseId' ),
    array( 'db' => '`u`.`AdvertiseTitle`',         'dt'=> 1, 'field' => 'AdvertiseTitle' ),
    array( 'db' => '`u`.`AdvertiseUrl`',         'dt'=> 2, 'field' => 'AdvertiseUrl' ),
    array( 'db' => '`u`.`LanguageCode`',         'dt'=> 3, 'field' => 'LanguageCode' ),
    array( 'db' => '`u`.`AdvertiseImage`',         'dt'=> 4, 'field' => 'AdvertiseImage' ),
    array( 'db' => '`u`.`IsActive`',         'dt'=> 5, 'field' => 'IsActive' ),
    array( 'db' => '`u`.`AdvertiseId`',         'dt'=> 6, 'field' => 'AdvertiseId' ),
);
$sql_details = array(
    'user' => env('DB_USERNAME'),
    'pass' => env('DB_PASSWORD'),
    'db'   => env('DB_DATABASE'),
    'host' => env('DB_HOST')
);
$joinQuery = "FROM `advertise_master` AS `u`";
//$id = session()->get('subjectdata')['CompanyId'];
//require( 'ssp.class.php' );
//$groupBy = '`u`.`EventTypeName`';
require( 'ssp.customized.class.php' );
echo json_encode(
    SSP::simple( $_GET, $sql_details, $table, $primaryKey, $columns, $joinQuery )
);
?>