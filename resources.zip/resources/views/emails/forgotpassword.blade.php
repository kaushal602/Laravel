@component('mail::message')

Hello {{ $content['username'] }}

You recently requested a password reset for your Grapevine Party Invitation account. Click on the following link to reset your password now:
@component('mail::button', ['url' => $content['url'].'/changepassword/'.$content['userid'].'/'.$content['token'] ])
Reset Password
@endcomponent

If you did not submit this request, please contact support@SAHM.com, or ignore this request.<br>

@endcomponent
