<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/*Route::get('/', function () {
    return view('welcome');
});*/
Route::get('/dashboard','Dashboard@Index');
Route::get('/','Login@Index');
Route::get('/login','Login@Index');
Route::post('/login','Login@Login');
Route::get('/logout','Login@Logout');
Route::get('/changepassword','Dashboard@ChangePassword');
Route::post('/changepassword','Dashboard@ChangePasswordDetail');

Route::post('/forgorpwd','Profile@ForGotPwd');
Route::get('changepasswords/{id}/{token}','Profile@viewChangePassword');
Route::post('changepassword/{uid}','Profile@ChangePasswordapi');

Route::get('userlist','User@Index');
Route::get('getuserlist', 'User@GetUserList');
Route::get('deleteuser/{id}','User@DeleteUser');
Route::post('userstatus','User@CountryStatus');

Route::get('eventlist','Event@Index');
Route::get('geteventlist', 'Event@GetEventList');
Route::get('viewevent/{id}', 'Event@ViewEvent');

Route::get('addpage','Page@Index');
Route::post('addpage','Page@AddPage');
Route::get('pagelist','Page@PageList');
Route::get('getpagelist','Page@GetPageList');
Route::get('pagelistview','Page@PageListView');
Route::post('pagestatus','Page@PageStatus');
Route::get('editpage/{id}','Page@EditPage');
Route::post('viewpagedata','Page@ViewEditPage');
Route::post('editpagedetails','Page@EditPageDetails');
Route::post('deletepage','Page@DeletePage');

Route::get('about-us','Page@AboutUs');
Route::post('editaboutdetails','Page@EditAbout');
Route::get('privacy-policy','Page@PrivacyPolicy');
Route::post('editprivacy-policy','Page@EditPrivacyPolicy');

Route::get('addeventtype','EventType@Index');
Route::post('addeventtype','EventType@AddEventType');
Route::get('eventtypelist','EventType@EventTypeList');
Route::get('geteventtypelist','EventType@GetEventTypeList');
Route::get('eventtypelistview','EventType@EventTypeListView');
Route::post('eventtypestatus','EventType@EventTypeStatus');
Route::get('editeventtype/{id}','EventType@EditEventType');
Route::post('vieweventtypedata','EventType@ViewEditEventType');
Route::post('editeventtypedetails','EventType@EditEventTypeDetails');
Route::post('deleteeventtype','EventType@DeleteEventType');
Route::post('deleteeventimage','EventType@DeleteEventImage');
/*Route::get('geteventtype','EventType@GetEventType');
Route::post('eventtypeimage','EventType@EventTypeImage');*/

Route::get('addadvertise','Advertise@Index');
Route::post('addadvertise','Advertise@AddAdvertise');
Route::get('advertiselist','Advertise@AdvertiseList');
Route::get('getadvertiselist','Advertise@GetAdvertiseList');
Route::get('advertiselistview','Advertise@AdvertiseListView');
Route::post('advertisestatus','Advertise@AdvertiseStatus');
Route::get('editadvertise/{id}','Advertise@EditAdvertise');
Route::post('viewadvertisedata','Advertise@ViewEditAdvertise');
Route::post('editadvertisedetails','Advertise@EditAdvertiseDetails');
Route::post('deleteadvertise','Advertise@DeleteAdvertise');

Route::get('addcountry','Country@Index');
Route::post('addcountry','Country@AddCountry');
Route::get('countrylist','Country@CountryList');
Route::get('getcountrylist','Country@GetCountryList');
Route::get('countrylistview','Country@CountryListView');
Route::post('countrystatus','Country@CountryStatus');
Route::get('editcountry/{id}','Country@EditCountry');
Route::post('viewcountrydata','Country@ViewEditCountry');
Route::post('editcountrydetails','Country@EditCountryDetails');
Route::post('deletecountry','Country@DeleteCountry');

Route::get('addlanguage','Language@Index');
Route::post('addlanguage','Language@AddLanguage');
Route::get('languagelist','Language@LanguageList');
Route::get('getlanguagelist','Language@GetLanguageList');
Route::get('languagelistview','Language@LanguageListView');
Route::post('languagestatus','Language@LanguageStatus');
Route::get('editlanguage/{id}','Language@EditLanguage');
Route::post('viewlanguagedata','Language@ViewEditLanguage');
Route::post('editlanguagedetails','Language@EditLanguageDetails');
Route::post('deletelanguage','Language@DeleteLanguage');

Route::post('api/login','api\LoginController@Login');
Route::post('api/registration', 'api\RegistrationController@Registration');
Route::post('api/updateprofile', 'api\RegistrationController@UpdateProfile');
Route::post('api/uploadimage', 'api\RegistrationController@UploadImage');
Route::post('api/updatelanguageid', 'api\RegistrationController@UpdateLanguageId');
Route::post('api/updatetimeformate', 'api\RegistrationController@UpdateTimeFormate');
Route::post('api/updatenotificationtoken', 'api\RegistrationController@UpdateNotificationToken');
Route::get('api/getsiteurl', 'api\LoginController@GetSiteUrl');

Route::post('api/forgotpasswordrequest','api\ApiVerifiedController@ChangePasswordReq');
Route::get('changepassword/{id}/{token}','api\ApiVerifiedController@viewChangePassword');
Route::post('changepasswordforapi/{uid}','api\ApiVerifiedController@ChangePasswordapi');

Route::post('api/changepassword','api\ApiVerifiedController@ChangePassword');

Route::post('api/event', 'api\EventController@Event');
Route::post('api/updateevent', 'api\EventController@UpdateEvent');
Route::post('api/eventlist', 'api\EventController@EventList');
Route::post('api/draftevent', 'api\EventController@DraftEventList');
Route::post('api/inviteeventlist', 'api\EventController@InviteEventList');
Route::post('api/eventdetails', 'api\EventController@GetEventDetail');
Route::post('api/adddraftevent','api\EventController@AddDraftEvent');
Route::post('api/deteteinvitenumber','api\EventController@DeteteInviteNumber');
Route::post('api/cancelevent','api\EventController@CancelEvent');
Route::post('api/updateinvitenumber','api\EventController@UpdateInviteNumber');
Route::get('api/geteventtype','api\EventController@GetEventType');
Route::post('api/eventtypeimage','api\EventController@EventTypeImage');
Route::post('api/uploadcoverimage', 'api\EventController@UploadCoverImage');
Route::post('api/updateacceptstatus', 'api\EventController@UpdateAcceptStatus');

Route::post('api/addgrapeviners', 'api\GrapeVinerController@AddGrapeViner');
Route::post('api/grapevinerslist', 'api\GrapeVinerController@GrapeVinerList');

Route::get('api/countrylist', 'api\LoginController@CountryList');
Route::get('api/about-us', 'api\PageController@GetAboutUsPage');
Route::get('api/privacy-policy', 'api\PageController@GetPrivacyPolivyPage');


Route::post('api/sendnotification', 'api\EventController@Sendnotification');


