<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;
use DB;

class AuthenticateLogin
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @param  string|null  $guard
     * @return mixed
     */
    public function handle($request, Closure $next, $guard = null)
    {
        $adlogin = $request->session()->get('userdata');
        if (!isset($adlogin)) {
            if ($request->ajax() || $request->wantsJson()) {
                return response('Unauthorized.', 401);
            } else {
                return redirect()->guest('/logout');
            }
        }else{
            $res = DB::table('user_master')
            ->select('*')
            ->where(function($query) use ($adlogin){
                $query->where('UserId','=',$adlogin->UserId);
            })
            ->first();
            session()->put('userdata' , $res);
        }

        return $next($request);
    }
}
