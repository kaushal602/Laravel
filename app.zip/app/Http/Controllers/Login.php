<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use App\model\LoginModel;

class Login extends Controller
{
	public function Index(){
		$adlogin = session()->get('userdata');
		if (isset($adlogin)) {
            return Redirect::to('dashboard');
        }else{
    		return view('Login');
    	}
	}
	public function Login(Request $request){
		$rules = array(
			'UserEmail' => 'required',
			'Password' =>'required',
		);
		$messages = [
			'UserEmail.required' => 'Username is mendatory field',
			'Password.required' =>'Password is mendatory field',
		];
		$validator = Validator::make(Input::all(), $rules,$messages);
		if ($validator->fails()) {
            return Redirect::to('/')
                ->withErrors($validator)
                ->withInput(); // send back all errors to the login form
        } else {
			$LoginModel = new LoginModel;
			$LoginData = $LoginModel->Login($request);
			//print_r($LoginData);exit;
			if($LoginData){
				session()->put('userdata' , $LoginData);
        		session()->put('iflogin', '1');
        		return Redirect::to('dashboard');
			}else{
				return Redirect::to('login')->withErrors(['errmsg'=>'Username or Password are not match.'])->withInput();
			}
		}
	}
	public function Logout(){
        session()->flush();
        return Redirect::to('');
    }
}
