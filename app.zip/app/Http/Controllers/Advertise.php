<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use App\model\AdvertiseModel;

class Advertise extends Controller
{
    public function __construct(){
        $this->middleware('login');
    }
	public function Index(Request $request){
        $AdvertiseModel = new AdvertiseModel();
        $Language = $AdvertiseModel->GetLanguage();
    	return View('Advertise/Add', compact('Language'));
    }
    public function AddAdvertise(Request $request){
		$AdvertiseModel = new AdvertiseModel();
        $rules = array(
            'AdvertiseTitle'  => 'required',
            'AdvertiseUrl'  => 'required',
            'LanguageCode'  => 'required',
        );
        $messages = [
            'AdvertiseTitle.required' => 'Advertise Title is mendatory field',
            'AdvertiseUrl.required' => 'Advertise Url is mendatory field',
            'LanguageCode.required' => 'LanguageCode is mendatory field',
        ];
        $validator = Validator::make(Input::all(), $rules,$messages);
        if ($validator->fails()) {
            return Redirect::to('Advertise/Add')
                ->withErrors($validator)
                ->withInput();
        } else {
    		$exist = $AdvertiseModel->ExistAdvertise($request);
        	if($exist){
        		//return json_encode(array('status'=> '0','message'=> 'Error.'));
                return Redirect::to('addadvertise')->withErrors(['sucmsg'=>'Advertise Name Already Added.']);
        	}else{
        		$AdvertiseTitle = $request->input('AdvertiseTitle');
                $AdvertiseUrl = $request->input('AdvertiseUrl');
                $LanguageCode = $request->input('LanguageCode');
                $AdvertiseImage = '';
                if ($request->hasFile('AdvertiseImage')) {
                    $destination = 'public/images';
                    $file = $request->file('AdvertiseImage');
                    $tm = time();
                    $file->move($destination, $tm.$file->getClientOriginalName());
                    $AdvertiseImage = $destination. "/" .$tm.$file->getClientOriginalName();
                }
                //echo $AdvertiseImage; exit;
                $Data = [
                    'AdvertiseTitle' => $AdvertiseTitle,
                    'AdvertiseUrl' => $AdvertiseUrl,
                    'LanguageCode' => $LanguageCode,
                    'AdvertiseImage' => $AdvertiseImage,
                    'CreatedDate' => date('Y-m-d h:i:s'),
                ];
                $AdvertiseModel->AddAdvertise($Data);
                return Redirect::to('addadvertise')->withErrors(['sucmsg'=>'Advertise Added successfully.']);
    		}
        }
    }
    public function AdvertiseList(){
    	return View('Advertise/List');
    }
    
    public function GetAdvertiseList(){
    	return View('Advertise/Data');
    }

    public function EditAdvertise($AdvertiseId,Request $request){
    	$AdvertiseModel = new AdvertiseModel();
    	$Data = $AdvertiseModel->GetAdvertiseData($AdvertiseId);
        $Language = $AdvertiseModel->GetLanguage();
        //$ImageData = $AdvertiseModel->GetAdvertiseImage($TypeId);
        //print_r($ImageData);exit;
    	return View('Advertise/Update',compact('Data','Language'));
    }
    public function ViewEditAdvertise(Request $request){
    	$AdvertiseId = $request->input('AdvertiseId');
		$AdvertiseModel = new AdvertiseModel();
		return json_encode( $AdvertiseModel->ViewAdvertiseData($AdvertiseId));
    }
    public function EditAdvertiseDetails(Request $request){
    	$AdvertiseId = $request->input('AdvertiseId');
		$AdvertiseModel = new AdvertiseModel();
    	$exist = $AdvertiseModel->ExistAdvertise($request);
        if($exist){
            //return json_encode(array('status'=> '0','message'=> 'Error.'));
            return Redirect::to('editadvertise/'.$AdvertiseId)->withErrors(['sucmsg'=>'Advertise Already Exist.']);
        }else{
            $AdvertiseTitle = $request->input('AdvertiseTitle');
                $AdvertiseUrl = $request->input('AdvertiseUrl');
                $LanguageCode = $request->input('LanguageCode');
            $Data = [
                'AdvertiseTitle' => $AdvertiseTitle,
                'AdvertiseUrl' => $AdvertiseUrl,
                'LanguageCode' => $LanguageCode,
                'CreatedDate' => date('Y-m-d h:i:s'),
            ];
            $AdvertiseImage = '';
            if ($request->hasFile('AdvertiseImage')) {
                $destination = 'public/images';
                $file = $request->file('AdvertiseImage');
                $tm = time();
                $file->move($destination, $tm.$file->getClientOriginalName());
                $AdvertiseImage = $destination. "/" .$tm.$file->getClientOriginalName();
            }
            if($AdvertiseImage!='') {
                $Data['AdvertiseImage'] = $AdvertiseImage;
            }
            $AdvertiseModel->EditAdvertiseDetail($Data,$AdvertiseId);
            return Redirect::to('advertiselist')->withErrors(['sucmsg'=>'Advertise Updated successfully.']);
        }
    }
    public function AdvertiseStatus(Request $request){
    	$AdvertiseModel = new AdvertiseModel();
    	$AdvertiseId = $request->input('AdvertiseId');
		$status = $request->input('status');
    	$data = $AdvertiseModel->AdvertiseStatus($AdvertiseId,$status);
    	return Redirect::to('advertiselist')->withErrors(['sucmsg'=>'Advertise Updated successfully.']);
    }
    public function DeleteAdvertise(Request $request){
        $AdvertiseModel = new AdvertiseModel();
        $AdvertiseId = $request->input('AdvertiseId');
        $AdvertiseModel->DeleteAdvertise($AdvertiseId);
    }

}