<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use App\model\DashboardModel;

class Dashboard extends Controller
{
	public function __construct(){
        $this->middleware('login');
    }
    public function index(){
    	$model = new DashboardModel();
    	$userlist = $model->UserList();
    	$eventlist = $model->EventList();

    	return view('Dashboard',compact('userlist','eventlist'));
    }
    public function ChangePassword(){
    	return view('ChangePassword');
    }
    public function ChangePasswordDetail(Request $request){
    	$rules = array(
			'oldpassword' => 'required',
			'newpassword' =>'required',
			'confpassword' =>'required',
		);
		$messages = [
			'oldpassword.required' => 'Old Password is mendatory field',
			'newpassword.required' =>'New Password is mendatory field',
			'confpassword.required' =>'Confirm Password is mendatory field',
		];
		$validator = Validator::make(Input::all(), $rules,$messages);
		if ($validator->fails()) {
            return Redirect::to('/')
                ->withErrors($validator)
                ->withInput(); // send back all errors to the login form
        } else {
        	$DashboardModel = new DashboardModel();
        	$oldpassword = $request->input('oldpassword');
        	$newpassword = $request->input('newpassword');
        	$confpassword = $request->input('confpassword');
	    	$userdata = session()->get('userdata');
	    	if($userdata->Password==md5($oldpassword)){
	    		if($newpassword==$confpassword){
	    			$where = ["UserId"=>$userdata->UserId];
	    			$update = ["Password"=>md5($newpassword)];
	    			$DashboardModel->ChangePasswordDetail($where,$update);
	    			return Redirect::to('changepassword')->withErrors(['sucmsg'=>'Your password has been changed successfully.'])->withInput();
	    		}else{
	    			return Redirect::to('changepassword')->withErrors(['errmsg'=>'Password and Confirm Password are not match.'])->withInput();
	    		}
	    	}else{
	    		return Redirect::to('changepassword')->withErrors(['errmsg'=>'Old Password is not match.'])->withInput();
	    	}
	    }
    }
}
