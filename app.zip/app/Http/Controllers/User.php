<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use App\model\UserModel;

class User extends Controller
{
	public function Index(){
		$adlogin = session()->get('userdata');
		if (isset($adlogin)) {
            return view('User/List');
        }else{
    		return view('Login');
    	}
	}
	public function GetUserList(){
    	return view('User/Data');
    }
    public function DeleteUser($id){
    	$UserModel = new UserModel();
    	$data = $UserModel->DeleteUser($id);
    	return Redirect::to('userlist')->withErrors(['sucmsg'=>'User deleted successfully.']);
    }
    public function CountryStatus(Request $request){
        $UserModel = new UserModel();
        $UserId = $request->input('UserId');
        $status = $request->input('status');
        $data = $UserModel->CountryStatus($UserId,$status);
        return json_encode(array('status'=> '1','message'=> 'Success.'));
    }
	
	public function Logout(){
        session()->flush();
        return Redirect::to('');
    }
}
