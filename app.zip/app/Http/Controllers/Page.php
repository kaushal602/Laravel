<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use App\model\PageModel;

class Page extends Controller
{
    public function __construct(){
        $this->middleware('login');
    }
    public function AboutUs(){
        $PageModel = new PageModel();
        $Data = $PageModel->GetAboutUs(1);
        return View('page/AboutUs', compact('Data'));
    }
    public function EditAbout(Request $request){
        $PageId = $request->input('PageId');
        $PageModel = new PageModel();
        $rules = array(
            'Description'  => 'required',
        );
        $messages = [
            'Description.required' => 'Description is mendatory field',
        ];
        $validator = Validator::make(Input::all(), $rules,$messages);
        if ($validator->fails()) {
            return Redirect::to('about-us')
                ->withErrors($validator)
                ->withInput();
        } else {
           
            $Description = $request->input('Description');
            $data = [
                'PageName' => 'About Us',
                'PageSlug' => 'about-us',
                'Description' => $Description,
                'CreatedBy' => '1',
                'ModifiedBy' => '1',
            ];
            $PageModel->EditAbout($data,$PageId);
            session()->put('pageupdate' , 'Page updated successfully.');
            return Redirect::to('about-us')->withErrors(['sucmsg'=>'Page Updated successfully.']);
                //return json_encode(array('status'=> '1','message'=> 'Success.'));
        }
    }
    public function PrivacyPolicy(){
        $PageModel = new PageModel();
        $Data = $PageModel->GetPrivacyPolicy(2);
        return View('page/PrivacyPolicy', compact('Data'));
    }
    public function EditPrivacyPolicy(Request $request){
        $PageId = $request->input('PageId');
        $PageModel = new PageModel();
        $rules = array(
            'Description'  => 'required',
        );
        $messages = [
            'Description.required' => 'Description is mendatory field',
        ];
        $validator = Validator::make(Input::all(), $rules,$messages);
        if ($validator->fails()) {
            return Redirect::to('privacy-policy')
                ->withErrors($validator)
                ->withInput();
        } else {
           
            $Description = $request->input('Description');
            $data = [
                'PageName' => 'About Us',
                'PageSlug' => 'about-us',
                'Description' => $Description,
                'CreatedBy' => '1',
                'ModifiedBy' => '1',
            ];
            $PageModel->EditPrivacyPolicy($data,$PageId);
            session()->put('pageupdate' , 'Page updated successfully.');
            return Redirect::to('privacy-policy')->withErrors(['sucmsg'=>'Page Updated successfully.']);
                //return json_encode(array('status'=> '1','message'=> 'Success.'));
        }
    }
	public function Index(Request $request){
    	return View('page/Add');
    }
    public function AddPage(Request $request){
		$PageModel = new PageModel();

        $rules = array(
            'PageName'  => 'required',
            'Description'  => 'required',
        );
        $messages = [
            'PageName.required' => 'Page Name is mendatory field',
            'Description.required' => 'Description is mendatory field',
        ];
        $validator = Validator::make(Input::all(), $rules,$messages);
        if ($validator->fails()) {
            return Redirect::to('addpage')
                ->withErrors($validator)
                ->withInput();
        } else {

    		$exist = $PageModel->ExistPage($request);
        	if($exist){
        		//return json_encode(array('status'=> '0','message'=> 'Error.'));
                return Redirect::to('addpage')->withErrors(['sucmsg'=>'Page Already Exist']);
        	}else{
                $userdata = session()->get("userdata");
        		$PageName = $request->input('PageName');
        		$Description = $request->input('Description');
    			$CreatedBy = $userdata->UserId;
    			$ModifiedBy = $userdata->UserId;
    			$data = [
    				'PageName' => $PageName,
    				'PageSlug' => trim(preg_replace('/\s+/',' ', $PageName)),
    				'Description' => $Description,
    				'CreatedBy' => $CreatedBy,
    				'ModifiedBy' => $ModifiedBy,
    			];
    			$PageModel->AddPageDetail($data);
               	//return json_encode(array('status'=> '1','message'=> 'Success.'));
                return Redirect::to('addpage')->withErrors(['sucmsg'=>'Page Added successfully.']);
    		}
        }
    }
    public function PageList(){
    	return View('page/List');
    }
    public function TotalRecord(){
        $PageModel = new PageModel();
        return json_encode($PageModel->TotalRecord());
    }
    
    public function GetPageList(){
    	return View('page/Data');
    }

    public function EditPage($PageId,Request $request){
    	$PageModel = new PageModel();
    	$Data = $PageModel->GetPageData($PageId);
    	return View('page/Update',compact('Data'));
    }
    public function ViewEditPage(Request $request){
    	$PageId = $request->input('PageId');
		$PageModel = new PageModel();
		return json_encode( $PageModel->ViewPageData($PageId));
    }
    public function EditPageDetails(Request $request){
    	$PageId = $request->input('PageId');
		$PageModel = new PageModel();
        $rules = array(
            'PageName'  => 'required',
            'Description'  => 'required',
        );
        $messages = [
            'PageName.required' => 'Page Name is mendatory field',
            'Description.required' => 'Description is mendatory field',
        ];
        $validator = Validator::make(Input::all(), $rules,$messages);
        if ($validator->fails()) {
            return Redirect::to('addpage')
                ->withErrors($validator)
                ->withInput();
        } else {
        	$exist = $PageModel->ExistPage($request,$PageId);
        	if($exist){
        		return Redirect::to('editpage/'.$PageId)->withErrors(['sucmsg'=>'Page Already Exist']);
        	}else{
                $userdata = session()->get("userdata");
        		$PageName = $request->input('PageName');
        		$Description = $request->input('Description');
    			$CreatedBy = $userdata->UserId;
    			$ModifiedBy = $userdata->UserId;
    			$data = [
    				'PageName' => $PageName,
    				'PageSlug' => $PageName,
    				'Description' => $Description,
    				'CreatedBy' => $CreatedBy,
    				'ModifiedBy' => $ModifiedBy,
    			];
    			$PageModel->EditPageDetail($data,$PageId);
                session()->put('pageupdate' , 'Page updated successfully.');
                return Redirect::to('pagelist')->withErrors(['sucmsg'=>'Page Updated successfully.']);
               	//return json_encode(array('status'=> '1','message'=> 'Success.'));
    		}
        }
    }
    public function DeletePage(Request $request){
        $PageModel = new PageModel();
        $PageId = $request->input('PageId');
        $PageModel->DeletePage($PageId);
    }

}