<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use App\model\LanguageModel;

class Language extends Controller
{
    public function __construct(){
        $this->middleware('login');
    }
	public function Index(Request $request){
    	return View('Language/Add');
    }
    public function AddLanguage(Request $request){
		$LanguageModel = new LanguageModel();
		$exist = $LanguageModel->ExistLanguage($request);
    	if($exist){
            return Redirect::to('addlanguage')->withErrors(['sucmsg'=>'Language Already Exiest.']);
    	}else{
            $userdata = session()->get("userdata");
    		$LanguageName = $request->input('LanguageName');
            $LanguageCode = $request->input('LanguageCode');
            $LanguageModel->AddLanguage($LanguageName,$LanguageCode);
            return Redirect::to('addlanguage')->withErrors(['sucmsg'=>'Language Added successfully.']);
		}
    }
    public function LanguageList(){
    	return View('Language/List');
    }
    
    public function GetLanguageList(){
    	return View('Language/Data');
    }

    public function EditLanguage($LanguageId,Request $request){
    	$LanguageModel = new LanguageModel();
    	$Data = $LanguageModel->GetLanguageData($LanguageId);
        //$ImageData = $LanguageModel->GetLanguageImage($LanguageId);
        //print_r($ImageData);exit;
    	return View('Language/Update',compact('Data','ImageData'));
    }
    public function ViewEditLanguage(Request $request){
    	$LanguageId = $request->input('LanguageId');
		$LanguageModel = new LanguageModel();
		return json_encode( $LanguageModel->ViewLanguageData($LanguageId));
    }
    public function EditLanguageDetails(Request $request){
    	$LanguageId = $request->input('LanguageId');
		$LanguageModel = new LanguageModel();
    	$exist = $LanguageModel->ExistLanguage($request);
        if($exist){
            //return json_encode(array('status'=> '0','message'=> 'Error.'));
            return Redirect::to('editlanguage/'.$LanguageId)->withErrors(['sucmsg'=>'Language Already Exiest.']);
        }else{
            $userdata = session()->get("userdata");
            $LanguageName = $request->input('LanguageName');
            $LanguageModel->EditLanguageDetail($LanguageName,$LanguageId);
            return Redirect::to('languagelist')->withErrors(['sucmsg'=>'Language Updated successfully.']);
        }
    }
    public function LanguageStatus(Request $request){
    	$LanguageModel = new LanguageModel();
    	$LanguageId = $request->input('LanguageId');
		$status = $request->input('status');
    	$data = $LanguageModel->LanguageStatus($LanguageId,$status);
    	return json_encode(array('status'=> '1','message'=> 'Success.'));
    }
    public function DeleteLanguage(Request $request){
        $LanguageModel = new LanguageModel();
        $LanguageId = $request->input('LanguageId');
        $LanguageModel->DeleteLanguage($LanguageId);
    }

}