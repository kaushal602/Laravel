<?php

namespace App\Http\Controllers\api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\model\api\LoginModel;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\MessageBag;
use Illuminate\Support\Facades\Log;
use Mail;
use Lang;

class LoginController extends Controller
{
	public function GetSiteUrl(){
		return url('');
	}
	public function Login(){
		try {
		  $UserEmail = $_POST['UserEmail'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter Email Address";
			$content = json_encode(array('status'=>0,'message'=>$msg,'userData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		
		try {
		  $Password = $_POST['Password'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter password";
			$content = json_encode(array('status'=>0,'message'=>$msg,'userData'=>json_decode('{}')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		$model = new LoginModel();
		if(!empty($UserEmail) && !empty($Password)){
			$getlogin = $model->Login($UserEmail,$Password);
			//echo "<pre>"; print_r($getlogin); exit;
	        if(!empty($getlogin)){
	        	if($getlogin->ProfileImage==""){
        			$getlogin->ProfileImage=="";
        		}else{
	        		$getlogin->ProfileImage = url('').('/public/profileimage/').$getlogin->ProfileImage;
	        	}
		        $status = 1;
	            $msg = "Login Successfully.";
	            $data = array('UserId'=>(Int)$getlogin->UserId,'Name'=>$getlogin->Name,'UserEmail'=>$getlogin->UserEmail,'CountryName'=>$getlogin->CountryName,'Mobile'=>$getlogin->Mobile,'CountryCode'=>trim($getlogin->CountryCode),'PostCode'=>$getlogin->PostCode,'Address'=>$getlogin->Address,'ProfileImage'=>$getlogin->ProfileImage,'TimeFormate'=>$getlogin->TimeFormate,'LanguageId'=>$getlogin->LanguageId,'NotificationToken'=>$getlogin->NotificationToken);
	        	$content = json_encode(array('status'=>$status,'message'=>$msg,'UserData'=>$data),JSON_UNESCAPED_SLASHES );
	        }else if (empty($getlogin)) {
	            $status = 0;
	            $msg = "Email or password not match";
	            $content = json_encode(array('status'=>$status,'message'=>$msg),JSON_UNESCAPED_SLASHES);
	        }
		}else{
			$status = 0;
            $msg = "Please Fill All Field";
            $content = json_encode(array('status'=>$status,'message'=>$msg),JSON_UNESCAPED_SLASHES| JSON_NUMERIC_CHECK );
		}
		
	    return response($content)
                ->header('Content-Type', 'application/json');
	}
	
	public function CountryList(){
		$model = new LoginModel();
		$getcountry = $model->CountryList();
		$status = 1;
        $msg = "Country List.";
    	$content = json_encode(array('CountryList'=>$getcountry),JSON_UNESCAPED_SLASHES );
    	return response($content)
                ->header('Content-Type', 'application/json');
	}
	
}
