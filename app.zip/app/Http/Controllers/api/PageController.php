<?php

namespace App\Http\Controllers\api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\model\api\LoginModel;
use App\model\api\PageModel;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Redirect;
use App\Mail\ForgotPassword;
use Illuminate\Support\MessageBag;
use Illuminate\Support\Facades\Log;
use Mail;
use Lang;

class PageController extends Controller
{
	
	public function GetAboutUsPage(){
		$model = new PageModel();
		$getaboutpage = $model->GetAboutUsPage();
		//print_r($grapevinerlist);
		$status = 1;
        $msg = "About Us Page";
        $Data = $getaboutpage;
    
    	$content = json_encode(array('status'=>$status,'message'=>$msg,'GetAboutUsPage'=>$Data),JSON_UNESCAPED_SLASHES );
    	return response($content)
	                ->header('Content-Type', 'application/json');
	}

	public function GetPrivacyPolivyPage(){
		$model = new PageModel();
		$getprivacypolivy = $model->GetPrivacyPolivyPage();
		//print_r($grapevinerlist);
		$status = 1;
        $msg = "Privacy Polivy List.";
        $Data = $getprivacypolivy;
    
    	$content = json_encode(array('status'=>$status,'message'=>$msg,'GetPrivacyPolivyPage'=>$Data),JSON_UNESCAPED_SLASHES );
    	return response($content)
	                ->header('Content-Type', 'application/json');
	}
}
