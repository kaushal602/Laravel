<?php

namespace App\Http\Controllers\api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\model\api\LoginModel;
use App\model\api\EventModel;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Redirect;
use App\Mail\ForgotPassword;
use Illuminate\Support\MessageBag;
use Illuminate\Support\Facades\Log;
use Mail;
use Lang;

class EventController extends Controller
{
	public function Event(){
		try {
		  $EventName = $_POST['EventName'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter Event Name";
			$content = json_encode(array('status'=>0,'message'=>$msg,'ErrorData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		try {
		  $EventType = $_POST['EventType'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter EventType";
			$content = json_encode(array('status'=>0,'message'=>$msg,'ErrorData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		try {
		  $SubEventType = $_POST['SubEventType'];
		}
		catch (\Exception $e) {
			$SubEventType = '';
		}
		try {
		  $EventDescription = $_POST['EventDescription'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter Event Description";
			$content = json_encode(array('status'=>0,'message'=>$msg,'ErrorData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		
		try {
		  $EventDate = $_POST['EventDate'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter Event Date";
			$content = json_encode(array('status'=>0,'message'=>$msg,'ErrorData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		try {
		  $StartTime = $_POST['StartTime'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter Start Time";
			$content = json_encode(array('status'=>0,'message'=>$msg,'ErrorData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		try {
		  $EndTime = $_POST['EndTime'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter End Time";
			$content = json_encode(array('status'=>0,'message'=>$msg,'ErrorData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		try {
		  $Address = $_POST['Address'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter Address";
			$content = json_encode(array('status'=>0,'message'=>$msg,'ErrorData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		// try {
		//   $LinkName = $_POST['LinkName'];
		//   $LinkNameArray = explode(',', $LinkName);
		// }
		// catch (\Exception $e) {
		// 	$LinkName = '';
		// }
		// try {
		//   $LinkUrl = $_POST['LinkUrl'];
		//   $LinkUrlArray = explode(',', $LinkUrl);
		// }
		// catch (\Exception $e) {
		// 	$LinkUrl = '';
		// }

		try {
		  $Latitude = $_POST['Latitude'];
		}
		catch (\Exception $e) {
			$Latitude = '';
		}
		try {
		  $Longitude = $_POST['Longitude'];
		}
		catch (\Exception $e) {
			$Longitude = '';
		}

		try {
		  $Number = $_POST['Number'];
		  $myArray = explode(',', $Number);
		}
		catch (\Exception $e) {
			//$Number = '';
			$msg = "Please Select Number";
			$content = json_encode(array('status'=>0,'message'=>$msg,'ErrorData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		try {
		  $InviteName = $_POST['InviteName'];
		  $NameArray = explode(',', $InviteName);
		}
		catch (\Exception $e) {
			
		}
		try {
		  $UserId = $_POST['UserId'];
		}
		catch (\Exception $e) {
			$UserId = 1;
		}
		try {
		  $EventId = $_POST['EventId'];
		}
		catch (\Exception $e) {
			$EventId = '';
		}
		
		$model = new EventModel();
		if(!empty($EventName) && !empty($EventType) && !empty($EventDescription) && !empty($EventDate) && !empty($StartTime) && !empty($EndTime) && !empty($Address)){

				$Data = [
					'UserId'=>$UserId,
                    'EventName'=>$EventName,
                    'EventType'=>$EventType,
                    'EventDescription'=>$EventDescription,
                    'LinkName'=>'LinkName',
                    'LinkUrl'=>'LinkUrl',
                    'EventDate'=>$EventDate,
                    'StartTime'=>$StartTime,
                    'EndTime'=>$EndTime,
                    'Address'=>$Address,
                    'Latitude'=>$Latitude,
                    'Longitude'=>$Longitude,
                    'SendInvitation'=>'Yes',
                ];

                if($EventId != ''){
                	//echo $EventId; exit;
                	$geteventdata = $model->UpdateEvent($Data, $EventId);

					if(!empty($geteventdata)){
						$model->DltTransactionData($EventId);
						$eid = $geteventdata->EventId;
						$uid = $geteventdata->UserId;
						if($Number != ''){
							for($i=0; $i < count($myArray); $i++){
								$transaction = [
			                        'EventId' => $EventId,
			                        'UserId' => $UserId,
			                        'Number' => $myArray[$i],
			                        'InviteName' => $NameArray[$i],
			                        'AcceptStatus' => 0,
			                    ];
			                    $model->UpdateTransactionData($transaction,$EventId);
							}
						}
						$TransectionData = $model->UpGetTransectionData($EventId,$UserId);

						// if($LinkName != '' && $LinkUrl != ''){
						// 	$model->DltLinkData($EventId);
						// 	for($i=0; $i < count($LinkNameArray); $i++){
						// 		$LinkData = [
			   //                      'EventId' => $EventId,
			   //                      'UserId' => $UserId,
			   //                      'LinkName' => $LinkNameArray[$i],
			   //                      'LinkUrl' => $LinkUrlArray[$i],
			   //                      'CreatedDate' => date('Y-m-d h:i:s'),
			   //                  ];
			   //                  $model->UpdateLinkData($LinkData,$EventId);
						// 	}
						// }
						$GetLinkData = $model->UpGetLinkData($EventId,$UserId);

			            $status = 1;
			            $msg = "Event Updated Successfully.";
			            //$data = $geteventdata;
			            $data = array('EventId'=>(Int)$geteventdata->EventId,'UserId'=>$geteventdata->UserId,'EventName'=>$geteventdata->EventName,'EventType'=>$geteventdata->EventType,'EventDescription'=>$geteventdata->EventDescription,'EventDate'=>$geteventdata->EventDate,'StartTime'=>$geteventdata->StartTime,'EndTime'=>$geteventdata->EndTime,'Address'=>$geteventdata->Address,'Latitude'=>$geteventdata->Latitude,'Longitude'=>$geteventdata->Longitude);

			            $content = json_encode(array('status'=>$status,'message'=>$msg,'EventData'=>$data,'InvitationData'=>$TransectionData,'GetLinkData'=>$GetLinkData),JSON_UNESCAPED_SLASHES);
			            return response($content)
	                			->header('Content-Type', 'application/json');

					} else if (empty($geteventdata)) {
				    	$status = 0;
			            $msg = "Detail not inserted";
			            $data = json_decode('{}');
			            $content = json_encode(array('status'=>$status,'message'=>$msg,'EventData'=>$data),JSON_UNESCAPED_SLASHES);
			            return response($content)
	                		->header('Content-Type', 'application/json');
				    }
                } else {

					$geteventdata = $model->Event($Data);

					if(!empty($geteventdata)){
						$eid = $geteventdata->EventId;
						$uid = $geteventdata->UserId;
						if($Number != ''){
							for($i=0; $i < count($myArray); $i++){
								$transaction = [
			                        'EventId' => $geteventdata->EventId,
			                        'UserId' => $geteventdata->UserId,
			                        'Number' => $myArray[$i],
			                        'InviteName' => $NameArray[$i],
			                        'AcceptStatus' => 0,
			                    ];
			                    $model->TransactionData($transaction);
							}
						}
						$TransectionData = $model->GetTransectionData($eid,$uid);

						// if($LinkName != '' && $LinkUrl != ''){
						// 	for($i=0; $i < count($LinkNameArray); $i++){
						// 		$LinkData = [
			   //                      'EventId' => $geteventdata->EventId,
			   //                      'UserId' => $geteventdata->UserId,
			   //                      'LinkName' => $LinkNameArray[$i],
			   //                      'LinkUrl' => $LinkUrlArray[$i],
			   //                      'CreatedDate' => date('Y-m-d h:i:s'),
			   //                  ];
			   //                  $model->LinkData($LinkData);
						// 	}
						// }
						$GetLinkData = $model->GetLinkData($eid,$uid);

			            $status = 1;
			            $msg = "Event Created Successfully.";
			            //$data = $geteventdata;
			            $data = array('EventId'=>(Int)$geteventdata->EventId,'UserId'=>$geteventdata->UserId,'EventName'=>$geteventdata->EventName,'EventType'=>$geteventdata->EventType,'EventDescription'=>$geteventdata->EventDescription,'EventDate'=>$geteventdata->EventDate,'StartTime'=>$geteventdata->StartTime,'EndTime'=>$geteventdata->EndTime,'Address'=>$geteventdata->Address,'Latitude'=>$geteventdata->Latitude,'Longitude'=>$geteventdata->Longitude);

			            $content = json_encode(array('status'=>$status,'message'=>$msg,'EventData'=>$data,'InvitationData'=>$TransectionData,'GetLinkData'=>$GetLinkData),JSON_UNESCAPED_SLASHES);
			            return response($content)
	                			->header('Content-Type', 'application/json');

					} else if (empty($geteventdata)) {
				    	$status = 0;
			            $msg = "Detail not inserted";
			            $data = json_decode('{}');
			            $content = json_encode(array('status'=>$status,'message'=>$msg,'EventData'=>$data),JSON_UNESCAPED_SLASHES);
			            return response($content)
	                		->header('Content-Type', 'application/json');
				    }
				}
		}else{
	    	$status = 0;
            $msg = "Please Fill Required Field";
            $data = json_decode('[]');
            $content = json_encode(array('status'=>$status,'message'=>$msg,'EventData'=>$data),JSON_UNESCAPED_SLASHES);
            return response($content)
                ->header('Content-Type', 'application/json');
	    }
		
	    
	}
	
	public function GetEventDetail(){
		$model = new EventModel();
		try {
		  $EventId = $_POST['EventId'];
		}
		catch (\Exception $e) {
			$EventId = 1;
		}
		$GetEventDetail = $model->GetEventDetail($EventId);
		$GetEventInvitationData = $model->GetEventInvitationData($EventId);
		$status = 1;
		$msg = "Event Created Successfully.";
		//$data = array('EventId'=>(Int)$GetEventDetail->EventId,'UserId'=>$GetEventDetail->UserId,'EventName'=>$GetEventDetail->EventName,'EventType'=>$GetEventDetail->EventType,'EventDescription'=>$GetEventDetail->EventDescription,'LinkName'=>$GetEventDetail->LinkName,'LinkUrl'=>$GetEventDetail->LinkUrl,'EventDate'=>$GetEventDetail->EventDate,'StartTime'=>$GetEventDetail->StartTime,'EndTime'=>$GetEventDetail->EndTime,'Address'=>$GetEventDetail->Address,'Latitude'=>$GetEventDetail->Latitude,'Longitude'=>$GetEventDetail->Longitude);
		 $content = json_encode(array('status'=>$status,'message'=>$msg,'EventData'=>$GetEventDetail,'InvitationData'=>$GetEventInvitationData),JSON_UNESCAPED_SLASHES);
            return response($content)
                ->header('Content-Type', 'application/json');

	}
	public function EventList(){
		try {
		  $UserId = $_POST['UserId'];
		}
		catch (\Exception $e) {
			$msg = "Please UserId";
			$content = json_encode(array('status'=>0,'message'=>$msg,'ErrorData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		$model = new EventModel();
		$EventList = $model->EventList($UserId);
		if(count($EventList)>0){
			$status = 1;
	        $msg = "Event List.";
	        $Data = $EventList;
	    	$content = json_encode(array('status'=>$status,'message'=>$msg,'EventList'=>$Data),JSON_UNESCAPED_SLASHES );
	    	return response($content)
	                ->header('Content-Type', 'application/json');
	    } else {
	    	$status = 0;
	        $msg = "Data not found.";
	        $Data = $EventList;
	    	$content = json_encode(array('status'=>$status,'message'=>$msg,'EventList'=>$Data),JSON_UNESCAPED_SLASHES );
	    	return response($content)
	                ->header('Content-Type', 'application/json');
	    }
	}
	public function DraftEventList(){
		try {
		  $UserId = $_POST['UserId'];
		}
		catch (\Exception $e) {
			$msg = "Please UserId";
			$content = json_encode(array('status'=>0,'message'=>$msg,'ErrorData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		$model = new EventModel();
		$DraftEventList = $model->DraftEventList($UserId);
		if(count($DraftEventList)>0){
			$status = 1;
	        $msg = "Event List.";
	        $Data = $DraftEventList;
	    	$content = json_encode(array('status'=>$status,'message'=>$msg,'DraftEventList'=>$Data),JSON_UNESCAPED_SLASHES );
	    	return response($content)
	                ->header('Content-Type', 'application/json');
	    } else {
	    	$status = 0;
	        $msg = "Data not found.";
	        $Data = $DraftEventList;
	    	$content = json_encode(array('status'=>$status,'message'=>$msg,'DraftEventList'=>$Data),JSON_UNESCAPED_SLASHES );
	    	return response($content)
	                ->header('Content-Type', 'application/json');
	    }
	}
	public function UpdateEvent(){
		try {
		  $EventName = $_POST['EventName'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter Event Name";
			$content = json_encode(array('status'=>0,'message'=>$msg,'ErrorData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		try {
		  $EventType = $_POST['EventType'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter EventType";
			$content = json_encode(array('status'=>0,'message'=>$msg,'ExecutiveData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		try {
		  $EventDescription = $_POST['EventDescription'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter Event Description";
			$content = json_encode(array('status'=>0,'message'=>$msg,'ErrorData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		
		try {
		  $EventDate = $_POST['EventDate'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter Event Date";
			$content = json_encode(array('status'=>0,'message'=>$msg,'ErrorData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		try {
		  $StartTime = $_POST['StartTime'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter Start Time";
			$content = json_encode(array('status'=>0,'message'=>$msg,'ErrorData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		try {
		  $EndTime = $_POST['EndTime'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter End Time";
			$content = json_encode(array('status'=>0,'message'=>$msg,'ErrorData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		try {
		  $Address = $_POST['Address'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter Address";
			$content = json_encode(array('status'=>0,'message'=>$msg,'ErrorData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		try {
		  $Link1 = $_POST['Link1'];
		}
		catch (\Exception $e) {
			$Link1 = '';
		}
		try {
		  $Link2 = $_POST['Link2'];
		}
		catch (\Exception $e) {
			$Link2 = '';
		}
		
		try {
		  $Number = $_POST['Number'];
		  $myArray = explode(',', $Number);
		}
		catch (\Exception $e) {
			$msg = "Please Select Number";
			$content = json_encode(array('status'=>0,'message'=>$msg,'ErrorData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		try {
		  $UserId = $_POST['UserId'];
		}
		catch (\Exception $e) {
			$UserId = 1;
		}

		try {
		  $EventId = $_POST['EventId'];
		}
		catch (\Exception $e) {
			
		}
		
		$model = new EventModel();
		if(!empty($EventName) && !empty($EventType) && !empty($EventDescription) && !empty($EventDate) && !empty($StartTime) && !empty($EndTime) && !empty($Address)){

			
				$Data = [
					'UserId'=>$UserId,
                    'EventName'=>$EventName,
                    'EventType'=>$EventType,
                    'EventDescription'=>$EventDescription,
                    'Link1'=>$Link1,
                    'Link2'=>$Link2,
                    'EventDate'=>$EventDate,
                    'StartTime'=>$StartTime,
                    'EndTime'=>$EndTime,
                    'Address'=>$Address,
                    'Latitude'=>$Latitude,
                    'Longitude'=>$Longitude,
                    'SendInvitation'=>'Yes',
                ];

				

				$geteventdata = $model->UpdateEvent($Data,$EventId);
		            $status = 1;
		            $msg = "Event Created Successfully.";
		            //$data = $geteventdata;
		            $data = array('EventId'=>(Int)$geteventdata->EventId,'UserId'=>$geteventdata->UserId,'EventName'=>$geteventdata->EventName,'EventType'=>$geteventdata->EventType,'EventDescription'=>$geteventdata->EventDescription,'EventDate'=>$geteventdata->EventDate,'StartTime'=>$geteventdata->StartTime,'EndTime'=>$geteventdata->EndTime,'Address'=>$geteventdata->Address,'Latitude'=>$geteventdata->Latitude,'Longitude'=>$geteventdata->Longitude);
		            if($Number != ''){
						for($i=0; $i < count($myArray); $i++){
							$transaction = [
		                        'EventId' => $geteventdata->EventId,
		                        'UserId' => $geteventdata->UserId,
		                        'Number' => $myArray[$i],
		                        'AcceptStatus' => 0,
		                    ];
		                    $model->TransactionData($transaction);
						}
					}
		}else{
	    	$status = 0;
            $msg = "Please Fill Required Field";
            $data = json_decode('[]');
	    }
		$content = json_encode(array('status'=>$status,'message'=>$msg,'EventData'=>$data),JSON_UNESCAPED_SLASHES);
	    return response($content)
                ->header('Content-Type', 'application/json');
	}
	
	public function AddDraftEvent(){
		try {
		  $EventName = $_POST['EventName'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter Event Name";
			$content = json_encode(array('status'=>0,'message'=>$msg,'ErrorData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		try {
		  $EventType = $_POST['EventType'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter EventType";
			$content = json_encode(array('status'=>0,'message'=>$msg,'ExecutiveData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		try {
		  $SubEventType = $_POST['SubEventType'];
		}
		catch (\Exception $e) {
			$SubEventType = '';
		}
		try {
		  $EventDescription = $_POST['EventDescription'];
		}
		catch (\Exception $e) {
			$EventDescription = '';
		}
		
		try {
		  $EventDate = $_POST['EventDate'];
		}
		catch (\Exception $e) {
			$EventDate = null;
		}
		try {
		  $StartTime = $_POST['StartTime'];
		}
		catch (\Exception $e) {
			$StartTime = '';
		}
		try {
		  $EndTime = $_POST['EndTime'];
		}
		catch (\Exception $e) {
			$EndTime = '';
		}
		try {
		  $Address = $_POST['Address'];
		}
		catch (\Exception $e) {
			$Address = '';
		}
		// try {
		//   $LinkName = $_POST['LinkName'];
		//   $LinkNameArray = explode(',', $LinkName);
		// }
		// catch (\Exception $e) {
		// 	$LinkName = '';
		// }
		// try {
		//   $LinkUrl = $_POST['LinkUrl'];
		//   $LinkUrlArray = explode(',', $LinkUrl);
		// }
		// catch (\Exception $e) {
		// 	$LinkUrl = '';
		// }

		try {
		  $Latitude = $_POST['Latitude'];
		}
		catch (\Exception $e) {
			$Latitude = '';
		}
		try {
		  $Longitude = $_POST['Longitude'];
		}
		catch (\Exception $e) {
			$Longitude = '';
		}

		
		try {
		  $UserId = $_POST['UserId'];
		}
		catch (\Exception $e) {
			$UserId = '';
		}
		try {
		  $EventId = $_POST['EventId'];
		}
		catch (\Exception $e) {
			$EventId = '';
		}
		
		$model = new EventModel();
		$Data = [
			'UserId'=>$UserId,
            'EventName'=>$EventName,
            'EventType'=>$EventType,
            'EventDescription'=>$EventDescription,
           // 'LinkName'=>$LinkName,
           // 'LinkUrl'=>$LinkUrl,
            //'EventDate'=>$EventDate,
            'StartTime'=>$StartTime,
            'EndTime'=>$EndTime,
            'Address'=>$Address,
            'Latitude'=>$Latitude,
            'Longitude'=>$Longitude,
            'SendInvitation'=>'No',
        ];
        if($EventDate!='') {
            $Data['EventDate'] = $EventDate;
        }
        if($EventId != ''){
        	$geteventdata = $model->UpdateDraftEvent($Data,$EventId);
        	//$eid = $geteventdata->EventId;
			//$uid = $geteventdata->UserId;
			// if($LinkName != '' && $LinkUrl != ''){
			// 	$model->DeleteDraftEvent($EventId);
			// 	for($i=0; $i < count($LinkNameArray); $i++){
			// 		$LinkData = [
   //                      'EventId' => $EventId,
   //                      'UserId' => $UserId,
   //                     'LinkName' => $LinkNameArray[$i],
   //                      'LinkUrl' => $LinkUrlArray[$i],
   //                      'CreatedDate' => date('Y-m-d h:i:s'),
   //                  ];
   //                  $model->UpdateDraftLinkData($LinkData,$EventId);
			// 	}
			// }
			$GetLinkData = $model->GetDraftLinkData($EventId,$UserId);

	        $status = 1;
	        $msg = "Event Updated Successfully.";
	        //$data = $geteventdata;
	        $data = array('EventId'=>(Int)$geteventdata->EventId,'UserId'=>$geteventdata->UserId,'EventName'=>$geteventdata->EventName,'EventType'=>$geteventdata->EventType,'EventDescription'=>$geteventdata->EventDescription,'EventDate'=>$geteventdata->EventDate,'StartTime'=>$geteventdata->StartTime,'EndTime'=>$geteventdata->EndTime,'Address'=>$geteventdata->Address,'Latitude'=>$geteventdata->Latitude,'Longitude'=>$geteventdata->Longitude);
			
    	} else {
    		$geteventdata = $model->AddDraftEvent($Data);
    		$eid = $geteventdata->EventId;
			$uid = $geteventdata->UserId;
			// if($LinkName != '' && $LinkUrl != ''){
			// 	for($i=0; $i < count($LinkNameArray); $i++){
			// 		$LinkData = [
   //                      'EventId' => $geteventdata->EventId,
   //                      'UserId' => $geteventdata->UserId,
   //                      'LinkName' => $LinkNameArray[$i],
   //                     'LinkUrl' => $LinkUrlArray[$i],
   //                      'CreatedDate' => date('Y-m-d h:i:s'),
   //                  ];
   //                  $model->LinkData($LinkData);
			// 	}
			// }
			$GetLinkData = $model->GetLinkData($eid,$uid);

	        $status = 1;
	        $msg = "Event Created Successfully.";
	        //$data = $geteventdata;
	        $data = array('EventId'=>(Int)$geteventdata->EventId,'UserId'=>$geteventdata->UserId,'EventName'=>$geteventdata->EventName,'EventType'=>$geteventdata->EventType,'EventDescription'=>$geteventdata->EventDescription,'EventDate'=>$geteventdata->EventDate,'StartTime'=>$geteventdata->StartTime,'EndTime'=>$geteventdata->EndTime,'Address'=>$geteventdata->Address,'Latitude'=>$geteventdata->Latitude,'Longitude'=>$geteventdata->Longitude);
    	}
    	$content = json_encode(array('status'=>$status,'message'=>$msg,'EventData'=>$data),JSON_UNESCAPED_SLASHES);
	        return response($content)
    			->header('Content-Type', 'application/json');
	}	
	
}
