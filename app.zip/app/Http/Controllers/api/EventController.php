<?php

namespace App\Http\Controllers\api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\model\api\LoginModel;
use App\model\api\EventModel;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Redirect;
use App\Mail\ForgotPassword;
use Illuminate\Support\MessageBag;
use Illuminate\Support\Facades\Log;
use Mail;
use Lang;

class EventController extends Controller
{
	public function Event(){
		try {
		  $EventName = $_POST['EventName'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter Event Name";
			$content = json_encode(array('status'=>0,'message'=>$msg,'ErrorData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		try {
		  $EventType = $_POST['EventType'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter EventType";
			$content = json_encode(array('status'=>0,'message'=>$msg,'ErrorData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		try {
		  $SubEventType = $_POST['SubEventType'];
		}
		catch (\Exception $e) {
			$SubEventType = 0;
		}
		try {
		  $EventDescription = $_POST['EventDescription'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter Event Description";
			$content = json_encode(array('status'=>0,'message'=>$msg,'ErrorData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		
		try {
		  $EventDate = $_POST['EventDate'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter Event Date";
			$content = json_encode(array('status'=>0,'message'=>$msg,'ErrorData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		try {
		  $StartTime = $_POST['StartTime'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter Start Time";
			$content = json_encode(array('status'=>0,'message'=>$msg,'ErrorData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		try {
		  $EndTime = $_POST['EndTime'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter End Time";
			$content = json_encode(array('status'=>0,'message'=>$msg,'ErrorData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		try {
		  $Address = $_POST['Address'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter Address";
			$content = json_encode(array('status'=>0,'message'=>$msg,'ErrorData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		try {
		  $LinkName = $_POST['LinkName'];
		  $LinkNameArray = explode(',', $LinkName);
		}
		catch (\Exception $e) {
			$LinkName = '';
		}
		try {
		  $LinkUrl = $_POST['LinkUrl'];
		  $LinkUrlArray = explode(',', $LinkUrl);
		}
		catch (\Exception $e) {
			$LinkUrl = '';
		}

		try {
		  $Latitude = $_POST['Latitude'];
		}
		catch (\Exception $e) {
			$Latitude = '';
		}
		try {
		  $Longitude = $_POST['Longitude'];
		}
		catch (\Exception $e) {
			$Longitude = '';
		}

		try {
		  $Number = $_POST['Number'];
		  $myArray = explode(',', $Number);
		}
		catch (\Exception $e) {
			//$Number = '';
			$msg = "Please Select Number";
			$content = json_encode(array('status'=>0,'message'=>$msg,'ErrorData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		try {
		  $InviteName = $_POST['InviteName'];
		  $NameArray = explode(',', $InviteName);
		}
		catch (\Exception $e) {
			
		}
		try {
		  $UserId = $_POST['UserId'];
		}
		catch (\Exception $e) {
			$UserId = 1;
		}
		try {
		  $EventId = $_POST['EventId'];
		}
		catch (\Exception $e) {
			$EventId = '';
		}
		try {
		  $CoverImage = $_POST['CoverImage'];
		}
		catch (\Exception $e) {
			$CoverImage = '';
		}
		
		$model = new EventModel();
		if(!empty($EventName) && !empty($EventType) && !empty($EventDescription) && !empty($EventDate) && !empty($StartTime) && !empty($EndTime) && !empty($Address)){

				$Data = [
					'UserId'=>$UserId,
                    'EventName'=>$EventName,
                    'EventType'=>$EventType,
                    'SubEventType'=>$SubEventType,
                    'EventDescription'=>$EventDescription,
                    'CoverImage'=>$CoverImage,
                    'LinkName'=>'LinkName',
                    'LinkUrl'=>'LinkUrl',
                    'EventDate'=>$EventDate,
                    'StartTime'=>$StartTime,
                    'EndTime'=>$EndTime,
                    'Address'=>$Address,
                    'Latitude'=>$Latitude,
                    'Longitude'=>$Longitude,
                    'SendInvitation'=>'Yes',
                ];

                if($EventId != ''){
                	//echo $EventId; exit;
                	$geteventdata = $model->UpdateEvent($Data, $EventId);

					if(!empty($geteventdata)){
						$model->DltTransactionData($EventId);
						$eid = $geteventdata->EventId;
						$uid = $geteventdata->UserId;
						if($Number != ''){
							for($i=0; $i < count($myArray); $i++){
								$transaction = [
			                        'EventId' => $EventId,
			                        'SenderId' => $UserId,
			                        'Number' => $myArray[$i],
			                        'InviteName' => $NameArray[$i],
			                        'AcceptStatus' => 'PENDING',
			                    ];
			                    $model->UpdateTransactionData($transaction,$EventId);
			                    $mob = $myArray[$i];
								$model->AddInviteRecivId($mob,$uid);
							}
						}
						$TransectionData = $model->UpGetTransectionData($EventId,$UserId);

						if($LinkName != '' && $LinkUrl != ''){
							$model->DltLinkData($EventId);
							for($i=0; $i < count($LinkNameArray); $i++){
								$LinkData = [
			                        'EventId' => $EventId,
			                        'UserId' => $UserId,
			                        'LinkName' => $LinkNameArray[$i],
			                        'LinkUrl' => $LinkUrlArray[$i],
			                        'CreatedDate' => date('Y-m-d h:i:s'),
			                    ];
			                    $model->UpdateLinkData($LinkData,$EventId);
							}
						}
						$GetLinkData = $model->UpGetLinkData($EventId,$UserId);
						//$EnTyId = $geteventdata->EventType;
						$EventTypeName = $model->GetEventTypeName($EventType);
						//$EnSubTyId = $geteventdata->SubEventType;
						if($SubEventType !='' && $SubEventType != 0){
							$SubEventTypeName = $model->GetEventSubTypeName($SubEventType);
							$SubEventTypeId =$SubEventTypeName->EventTypeId;
							$SubEventType =$SubEventTypeName->EventTypeName;
						} else {
							$SubEventTypeName = "";
							$SubEventTypeId ='';
							$SubEventType ='';
						}
			            $status = 1;
			            $msg = "Event Updated Successfully.";
			            //$data = $geteventdata;
			            $data = array('EventId'=>(Int)$geteventdata->EventId,'UserId'=>$geteventdata->UserId,'EventName'=>$geteventdata->EventName,'EventTypeId'=>$EventTypeName->EventTypeId,'EventType'=>$EventTypeName->EventTypeName,'SubEventTypeId'=>$SubEventTypeId,'SubEventType'=>$SubEventType,'EventDescription'=>$geteventdata->EventDescription,'EventDate'=>$geteventdata->EventDate,'StartTime'=>$geteventdata->StartTime,'EndTime'=>$geteventdata->EndTime,'Address'=>$geteventdata->Address,'Latitude'=>$geteventdata->Latitude,'Longitude'=>$geteventdata->Longitude,'CoverImage'=>$geteventdata->CoverImage);

			            $content = json_encode(array('status'=>$status,'message'=>$msg,'EventData'=>$data,'InvitationData'=>$TransectionData),JSON_UNESCAPED_SLASHES);
			            return response($content)
	                			->header('Content-Type', 'application/json');

					} else if (empty($geteventdata)) {
				    	$status = 0;
			            $msg = "Detail not inserted";
			            $data = json_decode('{}');
			            $content = json_encode(array('status'=>$status,'message'=>$msg,'EventData'=>$data),JSON_UNESCAPED_SLASHES);
			            return response($content)
	                		->header('Content-Type', 'application/json');
				    }
                } else {

					$geteventdata = $model->Event($Data);

					if(!empty($geteventdata)){
						$eid = $geteventdata->EventId;
						$uid = $geteventdata->UserId;
						if($Number != ''){
							for($i=0; $i < count($myArray); $i++){
								$transaction = [
			                        'EventId' => $geteventdata->EventId,
			                        'SenderId' => $geteventdata->UserId,
			                        'Number' => $myArray[$i],
			                        'InviteName' => $NameArray[$i],
			                        'AcceptStatus' => 'PENDING',
			                    ];
			                    $model->TransactionData($transaction);
			                    $mob = $myArray[$i];
								$model->AddInviteRecivId($mob,$uid);
							}
						}
						$TransectionData = $model->GetTransectionData($eid,$uid);

						if($LinkName != '' && $LinkUrl != ''){
							for($i=0; $i < count($LinkNameArray); $i++){
								$LinkData = [
			                        'EventId' => $geteventdata->EventId,
			                        'UserId' => $geteventdata->UserId,
			                        'LinkName' => $LinkNameArray[$i],
			                        'LinkUrl' => $LinkUrlArray[$i],
			                        'CreatedDate' => date('Y-m-d h:i:s'),
			                    ];
			                    $model->LinkData($LinkData);
							}
						}
						$GetLinkData = $model->GetLinkData($eid,$uid);
						$EventTypeName = $model->GetEventTypeName($EventType);
						if($SubEventType !='' && $SubEventType != 0){
							$SubEventTypeName = $model->GetEventSubTypeName($SubEventType);
							$SubEventTypeId =$SubEventTypeName->EventTypeId;
							$SubEventType =$SubEventTypeName->EventTypeName;
						} else {
							$SubEventTypeName = "";
							$SubEventTypeId = '';
							$SubEventType ='';
						}
			            $status = 1;
			            $msg = "Event Created Successfully.";
			            //$data = $geteventdata;
			            $data = array('EventId'=>(Int)$geteventdata->EventId,'UserId'=>$geteventdata->UserId,'EventName'=>$geteventdata->EventName,'EventTypeId'=>$EventTypeName->EventTypeId,'EventType'=>$EventTypeName->EventTypeName,'SubEventTypeId'=>$SubEventTypeId,'SubEventType'=>$SubEventType,'EventDescription'=>$geteventdata->EventDescription,'EventDate'=>$geteventdata->EventDate,'StartTime'=>$geteventdata->StartTime,'EndTime'=>$geteventdata->EndTime,'Address'=>$geteventdata->Address,'Latitude'=>$geteventdata->Latitude,'Longitude'=>$geteventdata->Longitude,'CoverImage'=>$geteventdata->CoverImage);

			            $content = json_encode(array('status'=>$status,'message'=>$msg,'EventData'=>$data,'InvitationData'=>$TransectionData),JSON_UNESCAPED_SLASHES);
			            return response($content)
	                			->header('Content-Type', 'application/json');

					} else if (empty($geteventdata)) {
				    	$status = 0;
			            $msg = "Detail not inserted";
			            $data = json_decode('{}');
			            $content = json_encode(array('status'=>$status,'message'=>$msg,'EventData'=>$data),JSON_UNESCAPED_SLASHES);
			            return response($content)
	                		->header('Content-Type', 'application/json');
				    }
				}
		}else{
	    	$status = 0;
            $msg = "Please Fill Required Field";
            $data = json_decode('[]');
            $content = json_encode(array('status'=>$status,'message'=>$msg,'EventData'=>$data),JSON_UNESCAPED_SLASHES);
            return response($content)
                ->header('Content-Type', 'application/json');
	    }
		
	    
	}
	
	public function GetEventDetail(){
		$model = new EventModel();
		try {
		  $EventId = $_POST['EventId'];
		}
		catch (\Exception $e) {
			$EventId = 1;
		}
		$GetEventDetail = $model->GetEventDetail($EventId);
		$GetEventInvitationData = $model->GetEventInvitationData($EventId);
		$status = 1;
		$msg = "Event Created Successfully.";
		//$data = array('EventId'=>(Int)$GetEventDetail->EventId,'UserId'=>$GetEventDetail->UserId,'EventName'=>$GetEventDetail->EventName,'EventType'=>$GetEventDetail->EventType,'EventDescription'=>$GetEventDetail->EventDescription,'LinkName'=>$GetEventDetail->LinkName,'LinkUrl'=>$GetEventDetail->LinkUrl,'EventDate'=>$GetEventDetail->EventDate,'StartTime'=>$GetEventDetail->StartTime,'EndTime'=>$GetEventDetail->EndTime,'Address'=>$GetEventDetail->Address,'Latitude'=>$GetEventDetail->Latitude,'Longitude'=>$GetEventDetail->Longitude);
		 $content = json_encode(array('status'=>$status,'message'=>$msg,'EventData'=>$GetEventDetail,'InvitationData'=>$GetEventInvitationData),JSON_UNESCAPED_SLASHES);
            return response($content)
                ->header('Content-Type', 'application/json');

	}
	public function EventList(){
		try {
		  $UserId = $_POST['UserId'];
		}
		catch (\Exception $e) {
			$msg = "Please UserId";
			$content = json_encode(array('status'=>0,'message'=>$msg,'ErrorData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		$model = new EventModel();
		$EventList = $model->EventList($UserId);
		if(count($EventList)>0){
			$status = 1;
	        $msg = "Event List.";
	        $Data = $EventList;
	    	$content = json_encode(array('status'=>$status,'message'=>$msg,'EventList'=>$Data),JSON_UNESCAPED_SLASHES );
	    	return response($content)
	                ->header('Content-Type', 'application/json');
	    } else {
	    	$status = 0;
	        $msg = "Data not found.";
	        $Data = $EventList;
	    	$content = json_encode(array('status'=>$status,'message'=>$msg,'EventList'=>$Data),JSON_UNESCAPED_SLASHES );
	    	return response($content)
	                ->header('Content-Type', 'application/json');
	    }
	}
	public function DraftEventList(){
		try {
		  $UserId = $_POST['UserId'];
		}
		catch (\Exception $e) {
			$msg = "Please UserId";
			$content = json_encode(array('status'=>0,'message'=>$msg,'ErrorData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		$model = new EventModel();
		$DraftEventList = $model->DraftEventList($UserId);
		if(count($DraftEventList)>0){
			$status = 1;
	        $msg = "Event List.";
	        $Data = $DraftEventList;
	    	$content = json_encode(array('status'=>$status,'message'=>$msg,'EventList'=>$Data),JSON_UNESCAPED_SLASHES );
	    	return response($content)
	                ->header('Content-Type', 'application/json');
	    } else {
	    	$status = 0;
	        $msg = "Data not found.";
	        $Data = $DraftEventList;
	    	$content = json_encode(array('status'=>$status,'message'=>$msg,'EventList'=>$Data),JSON_UNESCAPED_SLASHES );
	    	return response($content)
	                ->header('Content-Type', 'application/json');
	    }
	}
	public function UpdateEvent(){
		try {
		  $EventName = $_POST['EventName'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter Event Name";
			$content = json_encode(array('status'=>0,'message'=>$msg,'ErrorData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		try {
		  $EventType = $_POST['EventType'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter EventType";
			$content = json_encode(array('status'=>0,'message'=>$msg,'ExecutiveData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		try {
		  $SubEventType = $_POST['SubEventType'];
		}
		catch (\Exception $e) {
			$SubEventType = 0;
		}
		try {
		  $EventDescription = $_POST['EventDescription'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter Event Description";
			$content = json_encode(array('status'=>0,'message'=>$msg,'ErrorData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		
		try {
		  $EventDate = $_POST['EventDate'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter Event Date";
			$content = json_encode(array('status'=>0,'message'=>$msg,'ErrorData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		try {
		  $StartTime = $_POST['StartTime'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter Start Time";
			$content = json_encode(array('status'=>0,'message'=>$msg,'ErrorData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		try {
		  $EndTime = $_POST['EndTime'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter End Time";
			$content = json_encode(array('status'=>0,'message'=>$msg,'ErrorData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		try {
		  $Address = $_POST['Address'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter Address";
			$content = json_encode(array('status'=>0,'message'=>$msg,'ErrorData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}

		try {
		  $Latitude = $_POST['Latitude'];
		}
		catch (\Exception $e) {
			$Latitude = '';
		}
		try {
		  $Longitude = $_POST['Longitude'];
		}
		catch (\Exception $e) {
			$Longitude = '';
		}
		
		/*try {
		  $Number = $_POST['Number'];
		  $myArray = explode(',', $Number);
		}
		catch (\Exception $e) {
			$msg = "Please Select Number";
			$content = json_encode(array('status'=>0,'message'=>$msg,'ErrorData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		try {
		  $InviteName = $_POST['InviteName'];
		  $NameArray = explode(',', $InviteName);
		}
		catch (\Exception $e) {
			
		}*/
		try {
		  $UserId = $_POST['UserId'];
		}
		catch (\Exception $e) {
			$UserId = 1;
		}

		try {
		  $EventId = $_POST['EventId'];
		}
		catch (\Exception $e) {
			
		}
		
		$model = new EventModel();
		if(!empty($EventName) && !empty($EventType) && !empty($EventDescription) && !empty($EventDate) && !empty($StartTime) && !empty($EndTime) && !empty($Address)){

			
				$Data = [
					'UserId'=>$UserId,
                    'EventName'=>$EventName,
                    'EventType'=>$EventType,
                    'SubEventType'=>$SubEventType,
                    'EventDescription'=>$EventDescription,
                    'LinkName'=>'LinkName',
                    'LinkUrl'=>'LinkUrl',
                    'EventDate'=>$EventDate,
                    'StartTime'=>$StartTime,
                    'EndTime'=>$EndTime,
                    'Address'=>$Address,
                    'Latitude'=>$Latitude,
                    'Longitude'=>$Longitude,
                ];

				

				$geteventdata = $model->UpdateEvent($Data,$EventId);
				$model->DltTransactionData($EventId);
				$eid = $geteventdata->EventId;
				$uid = $geteventdata->UserId;

				$EventTypeName = $model->GetEventTypeName($EventType);
				if($SubEventType !='' && $SubEventType != 0){
					$SubEventTypeName = $model->GetEventSubTypeName($SubEventType);
					$SubEventTypeId =$SubEventTypeName->EventTypeId;
					$SubEventType =$SubEventTypeName->EventTypeName;
				} else {
					$SubEventTypeName = "";
					$SubEventTypeId ='';
					$SubEventType ='';
				}

		            $status = 1;
		            $msg = "Event Updated Successfully.";
		            //$data = $geteventdata;
		            $data = array('EventId'=>(Int)$geteventdata->EventId,'UserId'=>$geteventdata->UserId,'EventName'=>$geteventdata->EventName,'EventTypeId'=>$EventTypeName->EventTypeId,'EventType'=>$EventTypeName->EventTypeName,'SubEventTypeId'=>$SubEventTypeId,'SubEventType'=>$SubEventType,'EventDescription'=>$geteventdata->EventDescription,'EventDate'=>$geteventdata->EventDate,'StartTime'=>$geteventdata->StartTime,'EndTime'=>$geteventdata->EndTime,'Address'=>$geteventdata->Address,'Latitude'=>$geteventdata->Latitude,'Longitude'=>$geteventdata->Longitude,'CoverImage'=>$geteventdata->CoverImage);
		        $content = json_encode(array('status'=>$status,'message'=>$msg,'EventData'=>$data),JSON_UNESCAPED_SLASHES);
			    return response($content)
		                ->header('Content-Type', 'application/json');
		            
		}else{
	    	$status = 0;
            $msg = "Please Fill Required Field";
            $data = json_decode('[]');
			$content = json_encode(array('status'=>$status,'message'=>$msg,'EventData'=>$data),JSON_UNESCAPED_SLASHES);
	    	return response($content)
                ->header('Content-Type', 'application/json');
        }
	}
	
	public function AddDraftEvent(){
		try {
		  $EventName = $_POST['EventName'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter Event Name";
			$content = json_encode(array('status'=>0,'message'=>$msg,'ErrorData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		try {
		  $EventType = $_POST['EventType'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter EventType";
			$content = json_encode(array('status'=>0,'message'=>$msg,'ExecutiveData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		try {
		  $SubEventType = $_POST['SubEventType'];
		}
		catch (\Exception $e) {
			$SubEventType = 0;
		}
		try {
		  $EventDescription = $_POST['EventDescription'];
		}
		catch (\Exception $e) {
			$EventDescription = '';
		}
		
		try {
		  $EventDate = $_POST['EventDate'];
		}
		catch (\Exception $e) {
			$EventDate = null;
		}
		try {
		  $StartTime = $_POST['StartTime'];
		}
		catch (\Exception $e) {
			$StartTime = '';
		}
		try {
		  $EndTime = $_POST['EndTime'];
		}
		catch (\Exception $e) {
			$EndTime = '';
		}
		try {
		  $Address = $_POST['Address'];
		}
		catch (\Exception $e) {
			$Address = '';
		}
		try {
		  $LinkName = $_POST['LinkName'];
		  $LinkNameArray = explode(',', $LinkName);
		}
		catch (\Exception $e) {
			$LinkName = '';
		}
		try {
		  $LinkUrl = $_POST['LinkUrl'];
		  $LinkUrlArray = explode(',', $LinkUrl);
		}
		catch (\Exception $e) {
			$LinkUrl = '';
		}

		try {
		  $Latitude = $_POST['Latitude'];
		}
		catch (\Exception $e) {
			$Latitude = '';
		}
		try {
		  $Longitude = $_POST['Longitude'];
		}
		catch (\Exception $e) {
			$Longitude = '';
		}

		try {
		  $Number = $_POST['Number'];
		  $myArray = explode(',', $Number);
		}
		catch (\Exception $e) {
			$Number = '';
		}
		try {
		  $InviteName = $_POST['InviteName'];
		  $NameArray = explode(',', $InviteName);
		}
		catch (\Exception $e) {
			$InviteName = '';
		}
		
		try {
		  $UserId = $_POST['UserId'];
		}
		catch (\Exception $e) {
			$UserId = '';
		}
		try {
		  $EventId = $_POST['EventId'];
		}
		catch (\Exception $e) {
			$EventId = '';
		}
		try {
		  $CoverImage = $_POST['CoverImage'];
		}
		catch (\Exception $e) {
			$CoverImage = '';
		}
		
		$model = new EventModel();
		$Data = [
			'UserId'=>$UserId,
            'EventName'=>$EventName,
            'EventType'=>$EventType,
            'SubEventType'=>$SubEventType,
            'EventDescription'=>$EventDescription,
            'CoverImage'=>$CoverImage,
            'LinkName'=>$LinkName,
            'LinkUrl'=>$LinkUrl,
            //'EventDate'=>$EventDate,
            'StartTime'=>$StartTime,
            'EndTime'=>$EndTime,
            'Address'=>$Address,
            'Latitude'=>$Latitude,
            'Longitude'=>$Longitude,
            'SendInvitation'=>'No',
        ];
        if($EventDate!='') {
            $Data['EventDate'] = $EventDate;
        }
        if($EventId != ''){
        	$geteventdata = $model->UpdateDraftEvent($Data,$EventId);
        	//$eid = $geteventdata->EventId;
			//$uid = $geteventdata->UserId;
			if($Number != ''){
				$model->DltTransactionData($EventId);
				for($i=0; $i < count($myArray); $i++){
					$transaction = [
                        'EventId' => $EventId,
                        'SenderId' => $UserId,
                        'Number' => $myArray[$i],
                        'InviteName' => $NameArray[$i],
                        'AcceptStatus' => 'PENDING',
                    ];
                    $model->UpdateTransactionData($transaction,$EventId);
                    $mob = $myArray[$i];
                    $uid =  $UserId;
					$model->AddInviteRecivId($mob,$uid);
				}
			}
			$TransectionData = $model->UpGetTransectionData($EventId,$UserId);
			if($LinkName != '' && $LinkUrl != ''){
				$model->DeleteDraftEvent($EventId);
				for($i=0; $i < count($LinkNameArray); $i++){
					$LinkData = [
                        'EventId' => $EventId,
                        'UserId' => $UserId,
                        'LinkName' => $LinkNameArray[$i],
                        'LinkUrl' => $LinkUrlArray[$i],
                        'CreatedDate' => date('Y-m-d h:i:s'),
                    ];
                    $model->UpdateDraftLinkData($LinkData,$EventId);
				}
			}
			$GetLinkData = $model->GetDraftLinkData($EventId,$UserId);

			$EventTypeName = $model->GetEventTypeName($EventType);
			if($SubEventType !='' && $SubEventType != 0){
				$SubEventTypeName = $model->GetEventSubTypeName($SubEventType);
				$SubEventTypeId =$SubEventTypeName->EventTypeId;
				$SubEventType =$SubEventTypeName->EventTypeName;
			} else {
				$SubEventTypeName = "";
				$SubEventTypeId ='';
				$SubEventType ='';
			}

	        $status = 1;
	        $msg = "Event Updated Successfully.";
	        //$data = $geteventdata;
	        $data = array('EventId'=>(Int)$geteventdata->EventId,'UserId'=>$geteventdata->UserId,'EventName'=>$geteventdata->EventName,'EventTypeId'=>$EventTypeName->EventTypeId,'EventType'=>$EventTypeName->EventTypeName,'SubEventTypeId'=>$SubEventTypeId,'SubEventType'=>$SubEventType,'EventDescription'=>$geteventdata->EventDescription,'EventDate'=>$geteventdata->EventDate,'StartTime'=>$geteventdata->StartTime,'EndTime'=>$geteventdata->EndTime,'Address'=>$geteventdata->Address,'Latitude'=>$geteventdata->Latitude,'Longitude'=>$geteventdata->Longitude,'CoverImage'=>$geteventdata->CoverImage);
			
    	} else {
    		$geteventdata = $model->AddDraftEvent($Data);
    		$eid = $geteventdata->EventId;
			$uid = $geteventdata->UserId;
			if($Number != ''){
				for($i=0; $i < count($myArray); $i++){
					$transaction = [
                        'EventId' => $geteventdata->EventId,
                        'SenderId' => $geteventdata->UserId,
                        'Number' => $myArray[$i],
                        'InviteName' => $NameArray[$i],
                        'AcceptStatus' => 'PENDING',
                    ];
                    $model->TransactionData($transaction);
                    $mob = $myArray[$i];
                    $uid =  $geteventdata->UserId;
					$model->AddInviteRecivId($mob,$uid);
				}
			}
			$TransectionData = $model->GetTransectionData($eid,$uid);
			if($LinkName != '' && $LinkUrl != ''){
				for($i=0; $i < count($LinkNameArray); $i++){
					$LinkData = [
                        'EventId' => $geteventdata->EventId,
                        'UserId' => $geteventdata->UserId,
                        'LinkName' => $LinkNameArray[$i],
                        'LinkUrl' => $LinkUrlArray[$i],
                        'CreatedDate' => date('Y-m-d h:i:s'),
                    ];
                    $model->LinkData($LinkData);
				}
			}
			$GetLinkData = $model->GetLinkData($eid,$uid);
			$EventTypeName = $model->GetEventTypeName($EventType);
			if($SubEventType !='' && $SubEventType != 0){
				$SubEventTypeName = $model->GetEventSubTypeName($SubEventType);
				$SubEventTypeId =$SubEventTypeName->EventTypeId;
				$SubEventType =$SubEventTypeName->EventTypeName;
			} else {
				$SubEventTypeName = "";
				$SubEventTypeId ='';
				$SubEventType ='';
			}
	        $status = 1;
	        $msg = "Event Created Successfully.";
	        //$data = $geteventdata;
	        $data = array('EventId'=>(Int)$geteventdata->EventId,'UserId'=>$geteventdata->UserId,'EventName'=>$geteventdata->EventName,'EventTypeId'=>$EventTypeName->EventTypeId,'EventType'=>$EventTypeName->EventTypeName,'SubEventTypeId'=>$SubEventTypeId,'SubEventType'=>$SubEventType,'EventDescription'=>$geteventdata->EventDescription,'EventDate'=>$geteventdata->EventDate,'StartTime'=>$geteventdata->StartTime,'EndTime'=>$geteventdata->EndTime,'Address'=>$geteventdata->Address,'Latitude'=>$geteventdata->Latitude,'Longitude'=>$geteventdata->Longitude,'CoverImage'=>$geteventdata->CoverImage);
    	}
    	$content = json_encode(array('status'=>$status,'message'=>$msg,'EventData'=>$data,'InvitationData'=>$TransectionData),JSON_UNESCAPED_SLASHES);
	        return response($content)
    			->header('Content-Type', 'application/json');
	}	
	
	public function DeteteInviteNumber(){
		try {
		  $TransactionId = $_POST['TransactionId'];
		}
		catch (\Exception $e) {
			$InvitationId = '';
		}
		//echo $InvitationId; exit;
		$model = new EventModel();
		$model->DeteteInviteNumber($TransactionId);
		$status = 1;
        $msg = "Invite Number Deleted Successfully.";
        $Data = json_decode('[]');
    	$content = json_encode(array('status'=>$status,'message'=>$msg),JSON_UNESCAPED_SLASHES );
    	return response($content)
	                ->header('Content-Type', 'application/json');
	}

	public function CancelEvent(){
		try {
		  $EventId = $_POST['EventId'];
		}
		catch (\Exception $e) {
			$EventId = '';
		}
		//echo $InvitationId; exit;
		$model = new EventModel();
		$model->CancelEvent($EventId);
		$status = 1;
        $msg = "Event Cancelled Successfully.";
        $Data = json_decode('[]');
    	$content = json_encode(array('status'=>$status,'message'=>$msg),JSON_UNESCAPED_SLASHES );
    	return response($content)
	                ->header('Content-Type', 'application/json');
	}

	public function UpdateInviteNumber(){
		try {
		  $EventId = $_POST['EventId'];
		}
		catch (\Exception $e) {
			$EventId = '';
		}

		try {
		  $UserId = $_POST['UserId'];
		}
		catch (\Exception $e) {
			$UserId = '';
		}
		try {
		  $Number = $_POST['Number'];
		  $myArray = explode(',', $Number);
		}
		catch (\Exception $e) {
			$Number = '';
		}
		try {
		  $InviteName = $_POST['InviteName'];
		  $NameArray = explode(',', $InviteName);
		}
		catch (\Exception $e) {
			$InviteName = '';
		}
		$model = new EventModel();
		if($Number != ''){
			for($i=0; $i < count($myArray); $i++){
				$transaction = [
	                'EventId' => $EventId,
	                'SenderId' => $UserId,
	                'Number' => $myArray[$i],
	                'InviteName' => $NameArray[$i],
	                'AcceptStatus' => 'PENDING',
	            ];
	            $model->UpdateTransactionData($transaction,$EventId);
	             $mob = $myArray[$i];
                $uid =  $UserId;
				$model->AddInviteRecivId($mob,$uid);
			}
		}
		$status = 1;
        $msg = "Invitation Sent  Successfully.";
        $Data = json_decode('[]');
    	$content = json_encode(array('status'=>$status,'message'=>$msg),JSON_UNESCAPED_SLASHES );
    	return response($content)
	                ->header('Content-Type', 'application/json');
	}
	public function GetEventType(){
        //echo "123"; exit;
        $EventtypeModel = new EventModel();
        $EventTypeList = $EventtypeModel->GetEventType();
        $status = 1;
        $msg = "Event Type List.";
        $Data = $EventTypeList;
        $content = json_encode(array('status'=>$status,'message'=>$msg,'EventTypeList'=>$Data),JSON_UNESCAPED_SLASHES );
        return response($content)
                    ->header('Content-Type', 'application/json');
    }
    public function EventTypeImage(){
        try {
          $EventTypeId = $_POST['EventTypeId'];
        }
        catch (\Exception $e) {
           $EventTypeId = '';
        }

        try {
          $ChildEventTypeId = $_POST['ChildEventTypeId'];
        }
        catch (\Exception $e) {
            $ChildEventTypeId = 0;
        }
        try {
          $UserId = $_POST['UserId'];
        }
        catch (\Exception $e) {
            $UserId = 1;
        }
        $EventtypeModel = new EventModel();
        $EventTypeImage = $EventtypeModel->EventTypeImage($EventTypeId,$ChildEventTypeId,$UserId);
        $status = 1;
        $msg = "Event Type Images.";
        $Data = $EventTypeImage;
        $content = json_encode(array('status'=>$status,'message'=>$msg,'EventTypeImage'=>$Data),JSON_UNESCAPED_SLASHES );
        return response($content)
                    ->header('Content-Type', 'application/json');
    }

    public function InviteEventList(){
		try {
		  $UserId = $_POST['UserId'];
		}
		catch (\Exception $e) {
			$msg = "Please UserId";
			$content = json_encode(array('status'=>0,'message'=>$msg,'ErrorData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		$model = new EventModel();
		$InviteEventList = $model->InviteEventList($UserId);
		if(count($InviteEventList)>0){
			$status = 1;
	        $msg = "Invite Event List.";
	        $Data = $InviteEventList;
	    	$content = json_encode(array('status'=>$status,'message'=>$msg,'InviteEventList'=>$Data),JSON_UNESCAPED_SLASHES );
	    	return response($content)
	                ->header('Content-Type', 'application/json');
	    } else {
	    	$status = 0;
	        $msg = "Data not found.";
	        $Data = $InviteEventList;
	    	$content = json_encode(array('status'=>$status,'message'=>$msg,'InviteEventList'=>$Data),JSON_UNESCAPED_SLASHES );
	    	return response($content)
	                ->header('Content-Type', 'application/json');
	    }
	}

	public function UploadCoverImage(){
		try {
		  $File = $_POST['File'];
		}
		catch (\Exception $e) {
			$File = 'NO';
		}
		if($File == 'YES'){
			try {
				$info = getimagesize($_FILES['CoverImage']['tmp_name']);
	        	if ($info === FALSE) {
				   $msg = "Please Upload Image";
					$content = json_encode(array('status'=>0,'message'=>$msg,'CoverImageData'=>json_decode('{}')));
					return response($content)
		                ->header('Content-Type', 'application/json');
				}
				if (($info[2] !== IMAGETYPE_GIF) && ($info[2] !== IMAGETYPE_JPEG) && ($info[2] !== IMAGETYPE_PNG)) {
				   $msg = "Please Upload Image Of gif,jpeg or png";
					$content = json_encode(array('status'=>0,'message'=>$msg,'CoverImageData'=>json_decode('{}')));
					return response($content)
		                ->header('Content-Type', 'application/json');
				}else{
					if(!empty($_FILES)){
						$filepath = public_path().('/coverimage/').time();
			            move_uploaded_file($_FILES["CoverImage"]["tmp_name"], $filepath.$_FILES["CoverImage"]["name"]);
			            $Coverpath = 'public/coverimage/'.time().$_FILES["CoverImage"]["name"];
					}
					else{
			        	$Coverpath ="";
			        }
		        }
			}
			catch (\Exception $e) {
				$msg = "Please Select Image";
				$content = json_encode(array('status'=>0,'message'=>$msg,'CoverImageData'=>json_decode('[]')));
				return response($content)
	                ->header('Content-Type', 'application/json');
			}
		} else {
			$Coverpath = $_POST['CoverImage'];
		}
		

		try {
		  $UserId = $_POST['UserId'];
		}
		catch (\Exception $e) {
			$UserId = $_POST['UserId'];
		}

		try {
		  $EventId = $_POST['EventId'];
		}
		catch (\Exception $e) {
			$EventId = $_POST['EventId'];
		}
		try {
		  $File = $_POST['File'];
		}
		catch (\Exception $e) {
			$File = 'No';
		}

		$Data = [
          	'CoverImage'=>$Coverpath,
        ];
        $model = new EventModel();
			$ImageUrl = $model->UploadImage($Data,$UserId,$EventId);

            $status = 1;
            $msg = "Cover Image Updated Successfully.";
            //$data = $ImageUrl;
           /*if($ImageUrl->CoverImage==""){
    			$ImageUrl->CoverImage=="";
    		}else{
        		$ImageUrl->CoverImage = '/public/profileimage/'.$ImageUrl->CoverImage;
        	}*/
            $data = array('CoverImage'=>$ImageUrl->CoverImage);
            $content = json_encode(array('status'=>$status,'message'=>$msg,'CoverImageData'=>$data),JSON_UNESCAPED_SLASHES);
	    	return response($content)
                ->header('Content-Type', 'application/json');
	}

	public function UpdateAcceptStatus(){
		try {
		  $UserId = $_POST['UserId'];
		}
		catch (\Exception $e) {
			$UserId = $_POST['UserId'];
		}

		try {
		  $EventId = $_POST['EventId'];
		}
		catch (\Exception $e) {
			$EventId = $_POST['EventId'];
		}
		try {
		  $AcceptStatus = $_POST['AcceptStatus'];
		}
		catch (\Exception $e) {
			$AcceptStatus = 'PENDING';
		}
		try {
		  $CancelReason = $_POST['CancelReason'];
		}
		catch (\Exception $e) {
			$CancelReason = '';
		}
		$Data = [
          	'AcceptStatus'=>$AcceptStatus,
          	'CancelReason'=>$CancelReason,
        ];
		$model = new EventModel();
		$status = $model->UpdateAcceptStatus($EventId,$UserId,$Data);
		$status = 1;
        $msg = "Event Status Updated Successfully.";
        $Data = json_decode('[]');
    	$content = json_encode(array('status'=>$status,'message'=>$msg),JSON_UNESCAPED_SLASHES );
    	return response($content)
	                ->header('Content-Type', 'application/json');
	}

	public function Sendnotification(){
		define( 'API_ACCESS_KEY', 'AAAAJyVE884:APA91bFrTEeqAWXil4S3cAn3bTdSxsTYxVa6diHDFL7VX5uHZGi-UdR-VOVQTwonQvKhv5i4YsLOAtI7AsOt7ymHWm3rGtJPI1mDvIV89BBZ0lzgsgaR4HqOiJCU2tmDo7FxDiVcNeeM' );

		$data = array("to" => "dk3JAuFHO7U:APA91bFyWbwayGvABMpyGWpkW91g4I_0Xa53y4ZHPMA8k05TkgacGISCf2t0iT3WMj_d_zB3nvfK8KIfJfs-8-3blqKbl8rzRngWJmuGrcgz10sbEJZehzH7AAU72DnG4Nep8oZjpYIT",
		              "notification" => array( "title" => "http://grapevinepartyinvitation.developmentunit.com/", "body" => "Hello, You Have New Invitation...!!!","icon" => "icon.png", "click_action" => "http://grapevinepartyinvitation.developmentunit.com/"));                                                                    
		$data_string = json_encode($data); 
		echo "The Json Data : ".$data_string; 
		$headers = array
		(
		     'Authorization: key=' . API_ACCESS_KEY, 
		     'Content-Type: application/json'
		);                                                                              
		$ch = curl_init();  
		curl_setopt( $ch,CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send' );                                                                  
		curl_setopt( $ch,CURLOPT_POST, true );  
		curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
		curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true );
		curl_setopt( $ch,CURLOPT_POSTFIELDS, $data_string);                                                                  
		                                                                                                                     
		$result = curl_exec($ch);
		curl_close ($ch);
		echo "<p>&nbsp;</p>";
		echo "The Result : ".$result;
		
	}
}
