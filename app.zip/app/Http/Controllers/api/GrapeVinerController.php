<?php

namespace App\Http\Controllers\api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\model\api\LoginModel;
use App\model\api\GrapeVinerModel;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Redirect;
use App\Mail\ForgotPassword;
use Illuminate\Support\MessageBag;
use Illuminate\Support\Facades\Log;
use Mail;
use Lang;

class GrapeVinerController extends Controller
{
	public function AddGrapeViner(){
		try {
		  $Name = $_POST['Name'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter Name";
			$content = json_encode(array('status'=>0,'message'=>$msg,'agentData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		try {
		  $Email = $_POST['Email'];
		}
		catch (\Exception $e) {
			$Email = "";
		}
		
		try {
		  $Mobile = $_POST['Mobile'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter Mobile";
			$content = json_encode(array('status'=>0,'message'=>$msg,'agentData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		try {
		  $UserId = $_POST['UserId'];
		}
		catch (\Exception $e) {
			$UserId = $_POST['UserId'];
		}
		
		
		$model = new GrapeVinerModel();
		if(!empty($Name) && !empty($Mobile)){
			
			$grapevinerdata = $model->GrapeVinerData($Mobile,$UserId);
			if(!empty($grapevinerdata)){
				$status = 0;
	            $msg = "Mobile Already Exist";
	            $data = json_decode('{}');
			}else{
				$Data = [
					'UserId' => $UserId,
					'Name'=>$Name,
                    'Email'=>$Email,
                    'Mobile'=>$Mobile,
                    'CreatedDate' => date('Y-m-d h:i:s'),
                ];
				$grapeviner = $model->GrapeViner($Data);
				
	            $status = 1;
	            $msg = "GrapeViner Added Successfully.";
	            $data = json_decode('{}');
		    }
		}else{
	    	$status = 0;
            $msg = "Please Fill Required Field";
            $data = json_decode('[]');
	    }
		$content = json_encode(array('status'=>$status,'message'=>$msg,'UserData'=>$data),JSON_UNESCAPED_SLASHES);
	    return response($content)
                ->header('Content-Type', 'application/json');
	}

	public function GrapeVinerList(){
		try {
		  $UserId = $_POST['UserId'];
		}
		catch (\Exception $e) {
			$UserId = $_POST['UserId'];
		}
		$model = new GrapeVinerModel();
		$grapevinerlist = $model->GrapeVinerList($UserId);
		//print_r($grapevinerlist);
		if(!empty($grapevinerlist)) {
			$status = 1;
	        $msg = "GrapeViner List.";
	        //$Data = array('GrapeVinerId'=>(Int)$grapevinerlist->GrapeVinerId,'UserId'=>$grapevinerlist->UserId,'Name'=>$grapevinerlist->Name,'Email'=>$grapevinerlist->Email,'Mobile'=>$grapevinerlist->Mobile,'IsChecked'=>(Int)$grapevinerlist->IsChecked);
	        $Data = $grapevinerlist;
	    } else {
	    	$status = 0;
	        $msg = " No GrapeViner.";
	        $Data = json_decode('[]');
	    }
	    	$content = json_encode(array('status'=>$status,'message'=>$msg,'GrapeVinerList'=>$Data),JSON_UNESCAPED_SLASHES );
	    	return response($content)
	                ->header('Content-Type', 'application/json');
	}
}
