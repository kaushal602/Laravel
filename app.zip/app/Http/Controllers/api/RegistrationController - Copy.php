<?php

namespace App\Http\Controllers\api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\model\api\LoginModel;
use App\model\api\RegistrationModel;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Redirect;
use App\Mail\ForgotPassword;
use Illuminate\Support\MessageBag;
use Illuminate\Support\Facades\Log;
use Mail;
use Lang;

class RegistrationController extends Controller
{
	public function Registration(){
		try {
		  $Name = $_POST['Name'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter Name";
			$content = json_encode(array('status'=>0,'message'=>$msg,'agentData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		try {
		  $UserEmail = $_POST['UserEmail'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter Email";
			$content = json_encode(array('status'=>0,'message'=>$msg,'ExecutiveData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		if(isset($UserEmail)){
			if (!filter_var($UserEmail, FILTER_VALIDATE_EMAIL)) {
				$msg = "Please Enter Valid Email";
				$content = json_encode(array('status'=>0,'message'=>$msg,'agentData'=>json_decode('[]')));
				return response($content)
	                ->header('Content-Type', 'application/json');
			}
		}
		try {
		  $Password = $_POST['Password'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter Password";
			$content = json_encode(array('status'=>0,'message'=>$msg,'agentData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		
		try {
		  $CountryName = $_POST['CountryName'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter Country Name";
			$content = json_encode(array('status'=>0,'message'=>$msg,'agentData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		try {
		  $CountryCode = $_POST['CountryCode'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter CountryCode";
			$content = json_encode(array('status'=>0,'message'=>$msg,'agentData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		try {
		  $Mobile = $_POST['Mobile'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter Mobile";
			$content = json_encode(array('status'=>0,'message'=>$msg,'agentData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		try {
		  $PostCode = $_POST['PostCode'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter PostCode";
			$content = json_encode(array('status'=>0,'message'=>$msg,'agentData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		try {
		  $Address = $_POST['Address'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter Address";
			$content = json_encode(array('status'=>0,'message'=>$msg,'agentData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		
		$model = new RegistrationModel();
		if(!empty($Name) && !empty($UserEmail) && !empty($Password) && !empty($CountryName) && !empty($CountryCode) && !empty($Mobile) && !empty($PostCode)  && !empty($Address)){
			
			$registredata = $model->RegisterData($UserEmail);
			if(!empty($registredata)){
				$status = 0;
	            $msg = "Email Already Exist";
	            $data = array('UserId'=>$registredata->UserId);
			}else{
				if (strpos($CountryCode, '+') === false) {
				    $CountryCode ='+'.trim($CountryCode);
				    //echo $CountryCode;exit;
				}
				$Data = [
					'Name'=>$Name,
                    'UserEmail'=>$UserEmail,
                    'Password'=>md5($Password),
                    'CountryName'=>$CountryName,
                    'UserRole'=>"User",
                    'CountryCode'=>$CountryCode,
                    'Mobile'=>$Mobile,
                    'PostCode'=>$PostCode,
                    'Address'=>$Address,
                    'ProfileImage'=>'',
                    'CoverImage'=>'',
                    'TimeFormate'=>1,
                    'LanguageId'=>0,
                    'IsActive'=>1,
                    'FBToken'=>''
                ];
				$getregister = $model->Register($Data);
		            $status = 1;
		            $msg = "Register Successfully.";
		            $data = $getregister;
		    }
		}else{
	    	$status = 0;
            $msg = "Please Fill Required Field";
            $data = json_decode('[]');
	    }
		$content = json_encode(array('status'=>$status,'message'=>$msg,'UserData'=>$data),JSON_UNESCAPED_SLASHES);
	    return response($content)
                ->header('Content-Type', 'application/json');
	}
	public function AgentList(){
		//echo "string";exit;
		$model = new AgentModel();
		$getagent = $model->GetAgent('Agent');
		//echo "<pre>"; print_r($getcase);exit;
		if(!empty($getagent)){
            $status = 1;
            foreach ($getagent as $value) {
            	$type = $value->UserId;
            	$typenam = $value->Name;
            	$token = $value->NotificationToken;
            	$data[] = array('UserId'=>$type,'Name'=>$typenam,'NotificationToken'=>$token);
            }
            
        }else if (empty($getagent)) {
            $status = 0;
            $data = json_decode('{}');
        }
		$content = json_encode(array('status'=>$status,'AgentList'=>$data),JSON_UNESCAPED_SLASHES | JSON_NUMERIC_CHECK);
	    return response($content)
                ->header('Content-Type', 'application/json');
	}
	
}
