<?php

namespace App\Http\Controllers\api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\model\api\LoginModel;
use App\model\api\RegistrationModel;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Redirect;
use App\Mail\ForgotPassword;
use Illuminate\Support\MessageBag;
use Illuminate\Support\Facades\Log;
use Mail;
use Lang;

class RegistrationController extends Controller
{
	public function Registration(){
		try {
		  $Name = $_POST['Name'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter Name";
			$content = json_encode(array('status'=>0,'message'=>$msg,'agentData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		try {
		  $UserEmail = $_POST['UserEmail'];
		}
		catch (\Exception $e) {
			$UserEmail = '';
		}
		/*if(isset($UserEmail)){
			if (!filter_var($UserEmail, FILTER_VALIDATE_EMAIL)) {
				$msg = "Please Enter Valid Email";
				$content = json_encode(array('status'=>0,'message'=>$msg,'agentData'=>json_decode('[]')));
				return response($content)
	                ->header('Content-Type', 'application/json');
			}
		}*/
		try {
		  $Password = $_POST['Password'];
		}
		catch (\Exception $e) {
			$Password = '';
		}
		
		try {
		  $CountryName = $_POST['CountryName'];
		}
		catch (\Exception $e) {
			$CountryName = '';
		}
		try {
		  $CountryCode = $_POST['CountryCode'];
		}
		catch (\Exception $e) {
			$CountryCode = '';
		}
		try {
		  $Mobile = $_POST['Mobile'];
		}
		catch (\Exception $e) {
			$Mobile = '';
		}
		
		try {
		  $FBToken = $_POST['FBToken'];
		}
		catch (\Exception $e) {
			$FBToken = '';
		}
		
		$model = new RegistrationModel();
		if($FBToken == ''){
			if(!empty($Name) && !empty($UserEmail) && !empty($Password) && !empty($CountryName) && !empty($CountryCode) && !empty($Mobile)){
				
				$registredata = $model->RegisterData($UserEmail);
				if(!empty($registredata)){
					$status = 0;
		            $msg = "Email Already Exist";
		            $data = json_decode('{}');
				}else{
					if (strpos($CountryCode, '+') === false) {
					    $CountryCode ='+'.trim($CountryCode);
					    //echo $CountryCode;exit;
					}
					$Data = [
						'Name'=>$Name,
	                    'UserEmail'=>$UserEmail,
	                    'Password'=>md5($Password),
	                    'CountryName'=>$CountryName,
	                    'UserRole'=>"User",
	                    'CountryCode'=>$CountryCode,
	                    'Mobile'=>$Mobile,
	                    'PostCode'=>'',
	                    'Address'=>'',
	                    'ProfileImage'=>'',
	                    'CoverImage'=>'Coverpath',
	                    'TimeFormate'=>'1',
	                    'LanguageId'=>'en',
	                    'IsActive'=>1,
	                    'FBToken'=>'',
	                    'CreatedDate' => date('Y-m-d h:i:s'),
	                ];
					$getregister = $model->Register($Data);
					if(!empty($getregister)){
						if($getregister->ProfileImage==""){
		        			$getregister->ProfileImage=="";
		        		}else{
			        		$getregister->ProfileImage = url('').('/public/profileimage/').$getregister->ProfileImage;
			        	}
				            $status = 1;
				            $msg = "Register Successfully.";
				            $data = array('UserId'=>(Int)$getregister->UserId,'Name'=>$getregister->Name,'UserEmail'=>$getregister->UserEmail,'CountryName'=>$getregister->CountryName,'Mobile'=>$getregister->Mobile,'CountryCode'=>trim($getregister->CountryCode),'PostCode'=>$getregister->PostCode,'Address'=>$getregister->Address,'ProfileImage'=>$getregister->ProfileImage,'TimeFormate'=>$getregister->TimeFormate,'LanguageId'=>$getregister->LanguageId);
				            //$data = $getregister;
				    } else if (empty($getregister)) {
				    	$status = 0;
			            $msg = "Detail not inserted";
			            $data = json_decode('{}');
				    }
			    }
			}else{
		    	$status = 0;
	            $msg = "Please Fill Required Field";
	            $data = json_decode('[]');
		    }
		} else {
			$FBToken = $model->CheckFbRegister($FBToken);
			if(!empty($FBToken)){
				$status = 1;
	            $msg = "Login Successfully";
	            $data = array('UserId'=>(Int)$FBToken->UserId,'Name'=>$FBToken->Name,'UserEmail'=>$FBToken->UserEmail,'CountryName'=>$FBToken->CountryName,'Mobile'=>$FBToken->Mobile,'CountryCode'=>trim($FBToken->CountryCode),'PostCode'=>$FBToken->PostCode,'Address'=>$FBToken->Address,'ProfileImage'=>$FBToken->ProfileImage,'TimeFormate'=>$FBToken->TimeFormate,'LanguageId'=>$FBToken->LanguageId);
	            //$data = json_decode('{}');
			} else {
				$Data = [
					'Name'=>$Name,
	                'UserEmail'=>$UserEmail,
	                'Password'=>'',
	                'CountryName'=>'',
	                'UserRole'=>"User",
	                'CountryCode'=>'',
	                'Mobile'=>'',
	                'PostCode'=>'',
	                'Address'=>'',
	                'ProfileImage'=>'',
	                'CoverImage'=>'Coverpath',
	                'TimeFormate'=>'1',
	                'LanguageId'=>'en',
	                'IsActive'=>1,
	                'FBToken'=>$FBToken,
	                'CreatedDate' => date('Y-m-d h:i:s'),
	            ];
				$getregister = $model->Register($Data);
				if(!empty($getregister)){
					if($getregister->ProfileImage==""){
	        			$getregister->ProfileImage=="";
	        		}else{
		        		$getregister->ProfileImage = url('').('/public/profileimage/').$getregister->ProfileImage;
		        	}
			            $status = 1;
			            $msg = "Register Successfully.";
			            $data = array('UserId'=>(Int)$getregister->UserId,'Name'=>$getregister->Name,'UserEmail'=>$getregister->UserEmail,'CountryName'=>$getregister->CountryName,'Mobile'=>$getregister->Mobile,'CountryCode'=>trim($getregister->CountryCode),'PostCode'=>$getregister->PostCode,'Address'=>$getregister->Address,'ProfileImage'=>$getregister->ProfileImage,'TimeFormate'=>$getregister->TimeFormate,'LanguageId'=>$getregister->LanguageId);
			            //$data = $getregister;
			    } else if (empty($getregister)) {
			    	$status = 0;
		            $msg = "Detail not inserted";
		            $data = json_decode('{}');
			    }
			}
		}
		$content = json_encode(array('status'=>$status,'message'=>$msg,'UserData'=>$data),JSON_UNESCAPED_SLASHES);
	    return response($content)
                ->header('Content-Type', 'application/json');
	}
	
	public function UploadImage(){
		try {
			/*$ProfileImage = $_FILES['ProfileImage'];
			$tmp_name = $ProfileImage['tmp_name'];
			$files = $ProfileImage['name'];
			$tm = time();
			move_uploaded_file($tmp_name, public_path()."/profileimage/".$tm."-".$files);
			$Profilepath = "public/profileimage/".$tm."-".$files;*/
			$info = getimagesize($_FILES['ProfileImage']['tmp_name']);
        	if ($info === FALSE) {
			   $msg = "Please Upload Image";
				$content = json_encode(array('status'=>0,'message'=>$msg,'ExecutiveData'=>json_decode('{}')));
				return response($content)
	                ->header('Content-Type', 'application/json');
			}
			if (($info[2] !== IMAGETYPE_GIF) && ($info[2] !== IMAGETYPE_JPEG) && ($info[2] !== IMAGETYPE_PNG)) {
			   $msg = "Please Upload Image Of gif,jpeg or png";
				$content = json_encode(array('status'=>0,'message'=>$msg,'ExecutiveData'=>json_decode('{}')));
				return response($content)
	                ->header('Content-Type', 'application/json');
			}else{
				if(!empty($_FILES)){
					$filepath = public_path().('/profileimage/').time();
		            move_uploaded_file($_FILES["ProfileImage"]["tmp_name"], $filepath.$_FILES["ProfileImage"]["name"]);
		            $Profilepath = time().$_FILES["ProfileImage"]["name"];
				}
				else{
		        	$Profilepath ="";
		        }
	        }
		}
		catch (\Exception $e) {
			$msg = "Please Select Image";
			$content = json_encode(array('status'=>0,'message'=>$msg,'agentData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}

		try {
		  $UserId = $_POST['UserId'];
		}
		catch (\Exception $e) {
			$UserId = $_POST['UserId'];
		}

		$Data = [
          	'ProfileImage'=>$Profilepath,
        ];
        $model = new RegistrationModel();
			$ImageUrl = $model->UploadImage($Data,$UserId);

            $status = 1;
            $msg = "Profile Image Update Successfully.";
            //$data = $ImageUrl;
            if($ImageUrl->ProfileImage==""){
    			$ImageUrl->ProfileImage=="";
    		}else{
        		$ImageUrl->ProfileImage = url('').('/public/profileimage/').$ImageUrl->ProfileImage;
        	}
            $data = array('ImagePath'=>$ImageUrl->ProfileImage);
            $content = json_encode(array('status'=>$status,'message'=>$msg,'ProfileImage'=>$data),JSON_UNESCAPED_SLASHES);
	    	return response($content)
                ->header('Content-Type', 'application/json');
	}

	public function UpdateProfile(){
		try {
		  $Name = $_POST['Name'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter Name";
			$content = json_encode(array('status'=>0,'message'=>$msg,'agentData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		try {
		  $UserId = $_POST['UserId'];
		}
		catch (\Exception $e) {
			
		}
		try {
		  $UserEmail = $_POST['UserEmail'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter Email";
			$content = json_encode(array('status'=>0,'message'=>$msg,'ExecutiveData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		if(isset($UserEmail)){
			if (!filter_var($UserEmail, FILTER_VALIDATE_EMAIL)) {
				$msg = "Please Enter Valid Email";
				$content = json_encode(array('status'=>0,'message'=>$msg,'agentData'=>json_decode('[]')));
				return response($content)
	                ->header('Content-Type', 'application/json');
			}
		}
		
		try {
		  $CountryName = $_POST['CountryName'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter Country Name";
			$content = json_encode(array('status'=>0,'message'=>$msg,'agentData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		try {
		  $CountryCode = $_POST['CountryCode'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter CountryCode";
			$content = json_encode(array('status'=>0,'message'=>$msg,'agentData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		try {
		  $Mobile = $_POST['Mobile'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter Mobile";
			$content = json_encode(array('status'=>0,'message'=>$msg,'agentData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		
		try {
		  $PostCode = $_POST['PostCode'];
		}
		catch (\Exception $e) {
			$PostCode = '';
		}

		try {
		  $Address = $_POST['Address'];
		}
		catch (\Exception $e) {
			$Address = '';
		}


		try {
			$ProfileImage = $_FILES['ProfileImage'];
			$tmp_name = $ProfileImage['tmp_name'];
			$files = $ProfileImage['name'];
			$tm = time();
			move_uploaded_file($tmp_name, public_path()."/profileimage/".$tm."-".$files);
			$Profilepath = "public/profileimage/".$tm."-".$files;
		}
		catch (\Exception $e) {
			$Profilepath = "";
		}
		
		$model = new RegistrationModel();
		if(!empty($Name) && !empty($UserEmail) && !empty($CountryName) && !empty($CountryCode) && !empty($Mobile)){
			
			$registredata = $model->ExistUser($UserEmail,$UserId);
			if(!empty($registredata)){
				$status = 0;
	            $msg = "Email Already Exist";
	            $data = json_decode('{}');
			}else{
				if (strpos($CountryCode, '+') === false) {
				    $CountryCode ='+'.trim($CountryCode);
				    //echo $CountryCode;exit;
				}
				$Data = [
					'Name'=>$Name,
                    'UserEmail'=>$UserEmail,
                    'CountryName'=>$CountryName,
                    'CountryCode'=>$CountryCode,
                    'Mobile'=>$Mobile,
                    'PostCode'=>$PostCode,
                    'Address'=>$Address,
                ];
				$getregister = $model->UpdateProfile($Data,$UserId);
				if($getregister->ProfileImage==""){
        			$getregister->ProfileImage=="";
        		}else{
	        		$getregister->ProfileImage = url('').('/public/profileimage/').$getregister->ProfileImage;
	        	}

		            $status = 1;
		            $msg = "Profile Update Successfully.";
		            //$data = $getregister;
		            $data = array('UserId'=>(Int)$getregister->UserId,'Name'=>$getregister->Name,'UserEmail'=>$getregister->UserEmail,'CountryName'=>$getregister->CountryName,'Mobile'=>$getregister->Mobile,'CountryCode'=>trim($getregister->CountryCode),'PostCode'=>$getregister->PostCode,'Address'=>$getregister->Address,'ProfileImage'=>$getregister->ProfileImage,'TimeFormate'=>$getregister->TimeFormate,'LanguageId'=>$getregister->LanguageId);
		    }
		}else{
	    	$status = 0;
            $msg = "Please Fill Required Field";
            $data = json_decode('[]');
	    }
		$content = json_encode(array('status'=>$status,'message'=>$msg,'UserData'=>$data),JSON_UNESCAPED_SLASHES);
	    return response($content)
                ->header('Content-Type', 'application/json');
	}
	
	public function UpdateLanguageId(){
		try {
		  $UserId = $_POST['UserId'];
		}
		catch (\Exception $e) {
			
		}

		try {
		  $LanguageId = $_POST['LanguageId'];
		}
		catch (\Exception $e) {
			$msg = "Please Select LanguageId";
			$content = json_encode(array('status'=>0,'message'=>$msg,'Data'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}

		$model = new RegistrationModel();
		$LanguageId = $model->UpdateLanguageId($LanguageId,$UserId);
		$status = 1;
        $msg = "Language Updated Successfully.";
        //$data = $LanguageId;

        $data = array('UserId'=>(Int)$LanguageId->UserId,'LanguageId'=>$LanguageId->LanguageId);
        $content = json_encode(array('status'=>$status,'message'=>$msg,'LanguageData'=>$data),JSON_UNESCAPED_SLASHES);
	    return response($content)
                ->header('Content-Type', 'application/json');
    }

    public function UpdateTimeFormate(){
		try {
		  $UserId = $_POST['UserId'];
		}
		catch (\Exception $e) {
			
		}

		try {
		  $TimeFormate = $_POST['TimeFormate'];
		}
		catch (\Exception $e) {
			$msg = "Please Select Time Formate";
			$content = json_encode(array('status'=>0,'message'=>$msg,'Data'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}

		$model = new RegistrationModel();
		$TimeFormate = $model->UpdateTimeFormate($TimeFormate,$UserId);
		$status = 1;
        $msg = "TimeFormate Updated Successfully.";
        //$data = $LanguageId;

        $data = array('UserId'=>(Int)$TimeFormate->UserId,'TimeFormate'=>$TimeFormate->TimeFormate);
        $content = json_encode(array('status'=>$status,'message'=>$msg,'TimeFormate'=>$data),JSON_UNESCAPED_SLASHES);
	    return response($content)
                ->header('Content-Type', 'application/json');
    }
}
