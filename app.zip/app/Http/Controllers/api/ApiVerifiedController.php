<?php

namespace App\Http\Controllers\api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\model\api\LoginModel;
use App\model\api\GenerateOtpModel;
use App\Mail\ForgotPassword;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\MessageBag;
use Illuminate\Support\Facades\Log;
use Mail;
use Lang;

class ApiVerifiedController extends Controller
{
	
	public function ChangePasswordReq(){
		try {
		  $UserEmail = $_POST['UserEmail'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter Email";
			$content = json_encode(array('status'=>0,'message'=>$msg,'userData'=>json_decode('{}')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}

		$model = new GenerateOtpModel();
		if(!empty($UserEmail)){
				$checkemail = $model->CheckEmail($UserEmail);

				if(!empty($checkemail)){
					$alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
		            $pass = array(); //remember to declare $pass as an array
		            $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
		            for ($i = 0; $i < 11; $i++) {
		                $n = rand(0, $alphaLength);
		                $pass[] = $alphabet[$n];
		            }
		            $token = implode($pass);
		             //echo ($password);exit;
		            //$cdate = strtotime(date('Y-m-d H:i:s'));
		            $content=['userid'=>$checkemail->UserId,'token'=>$token,'username'=>$checkemail->Name,'url'=>url('/')];
		             //print_r($content); exit;
		            $receiverAddress = $checkemail->UserEmail;
		            Mail::to($receiverAddress)->send(new ForgotPassword($content));
		            //$model->setToken($Email, $token);
				$changereq = $model->ChangePasswordReq($checkemail->Password,$token,$checkemail->UserId);
				//echo "<pre>"; print_r($changereq); exit;
				if($changereq==1){
					$status = 1;
		            $msg = "Password reset email has been sent to your email address, Please check your mail";
		        }else{
		        	$msg = "Email Address does Not match";
					$status = 0;
		        }
			}else{
				$msg = "Email Address does Not match";
				$status = 0;
			}
		}else{
			$msg = "Please Fill All Field";
			$status = 0;
		}
		$content = json_encode(array('status'=>$status,'message'=>$msg),JSON_UNESCAPED_SLASHES | JSON_NUMERIC_CHECK);
	    return response($content)
                ->header('Content-Type', 'application/json');
	}
	public function viewChangePassword($id,$token){
        $model = new GenerateOtpModel();
        ////////0 = user not found//1 = true// 2 = token used // 3 = token expired
        $checktokentime = $model->CheckTokenExpired($id,$token);
        //return view('changepasswordapi',compact('id','token','starttime'));
        if($checktokentime == 1){
            return view('changepasswordapi',compact('id','token','starttime'));
        }else if($checktokentime == 2){
            return redirect::to('login')->withErrors(['errmsg'=>'Your token is used']);
        }else if($checktokentime == 3){
            return redirect::to('login')->withErrors(['errmsg'=>'Forgot password link has been expired']);
        }else if($checktokentime == 0){
            return redirect::to('login')->withErrors(['errmsg'=>'User not found']);
        }
    }
    public function ChangePasswordapi($uid, Request $request){
    	$rules = array(
			'newpassword' =>'required',
			'confpassword' =>'required',
		);
		$messages = [
			'newpassword.required' =>'New Password is mendatory field',
			'confpassword.required' =>'Confirm Password is mendatory field',
		];
		$validator = Validator::make(Input::all(), $rules,$messages);
		if ($validator->fails()) {
            return Redirect::to('/')
                ->withErrors($validator)
                ->withInput(); // send back all errors to the login form
        } else {
        	$newpassword = $request->input('newpassword');
        	$confpassword = $request->input('confpassword');
        	if($newpassword == $confpassword){
	        	$model = new GenerateOtpModel();
	        	$changpwd = $model->ChangePasswordapi($uid,$newpassword,$confpassword);
	        	if($changpwd==1){
	        		return Redirect::to('login')->withErrors(['sucmsg'=>'Your password has been changed successfully.'])->withInput();
	        	}else{
	        		return Redirect::back()->withErrors(['errmsg'=>'Password and Confirm Password are not match.'])->withInput();
	        	}
	        }else{
	        	return Redirect::back()->withErrors(['errmsg'=>'Password and Confirm Password are not match.'])->withInput();
	        }
	    	
	    }
    }

    public function ChangePassword(){

    	try {
		  $UserId = $_POST['UserId'];
		}
		catch (\Exception $e) {
			$UserId = $_POST['UserId'];
		}
    	try {
		  $OldPassword = $_POST['OldPassword'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter Old Password";
			$content = json_encode(array('status'=>0,'message'=>$msg,'agentData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		try {
		  $NewPassword = $_POST['NewPassword'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter New Password ";
			$content = json_encode(array('status'=>0,'message'=>$msg,'agentData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}
		try {
		  $ConfPassword = $_POST['ConfPassword'];
		}
		catch (\Exception $e) {
			$msg = "Please Enter Confirm Password";
			$content = json_encode(array('status'=>0,'message'=>$msg,'agentData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
		}

		$model = new GenerateOtpModel();
		$CheckOldPass = $model->CheckOldPass($OldPassword,$UserId);
		if($CheckOldPass){
			if($NewPassword == $ConfPassword){
				$model->ChangePassword($UserId,$NewPassword);
				$status = 1;
		        $msg = "Password updated successfully";
		        $Data = json_decode('[]');
			} else {
				$status = 0;
		        $msg = "New Password and Confirm Password Does not match";
		        $Data = json_decode('[]');
			}
		} else {
			$status = 0;
	        $msg = "Old Password Does not match";
	        $Data = json_decode('[]');
		}
		$content = json_encode(array('status'=>$status,'message'=>$msg,'agentData'=>json_decode('[]')));
			return response($content)
                ->header('Content-Type', 'application/json');
    }
}
