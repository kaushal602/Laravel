<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use App\model\EventModel;

class Event extends Controller
{
	public function Index(){
		$adlogin = session()->get('userdata');
		if (isset($adlogin)) {
            return view('Event/List');
        }else{
    		return view('Login');
    	}
	}
	public function GetEventList(){
    	return view('Event/Data');
    }
    public function DeleteEvent($id){
    	$EventModel = new EventModel();
    	$data = $EventModel->DeleteEvent($id);
    	return Redirect::to('userlist')->withErrors(['sucmsg'=>'Event deleted successfully.']);
    }
	
	public function ViewEvent($id){
        $EventModel = new EventModel();
        $Data = $EventModel->ViewEvent($id);
        return view('Event/Details', compact('Data'));
    }
}
