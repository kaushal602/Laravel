<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;

use App\Mail\ForgotPasswordSite;
use Illuminate\Support\Facades\Redirect;
use App\model\ProfileModel;
use Mail;

class Profile extends Controller
{
    public function EditProfile(){
    	$ProfileModel = new ProfileModel();
    	$data = $ProfileModel->EditProfile();
        return view('EditProfile',compact('data'));
    }
    public function UpdateProfile(Request $request){
    	$ProfileModel = new ProfileModel();
        if(!isset($_FILES["logo"])){
            $imagnam = "";
        }else{
            $logo = $_FILES['logo'];
            //print_r($logo); exit;
            if(!empty($_FILES) && !empty($_FILES['logo']['name'])){
                $filepath = public_path().('/images').'/'.time();
                //echo $filepath.$_FILES["logo"]["name"]; exit;
                move_uploaded_file($_FILES["logo"]["tmp_name"], $filepath.$_FILES["logo"]["name"]);
                //echo "hi"; exit;
                $imagnam = time().$_FILES["logo"]["name"]; 
            }
            else{
                $imagnam ="";
            }
    
        }
    	$data = $ProfileModel->UpdateProfile($request,$imagnam);
    	return Redirect::to('editprofile')->WithErrors(['sucmsg'=>'Profile Updated Successfully']);
    }

    public function ForGotPwd(Request $request){
       // echo "string";exit;
        $model = new ProfileModel();
        $UserEmail = $request->input('email');
        if(!empty($UserEmail)){
            $checkemail = $model->CheckEmail($UserEmail);
            //echo $checkemail;exit;
            if(!empty($checkemail)){
                $alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
                $pass = array(); //remember to declare $pass as an array
                $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
                for ($i = 0; $i < 11; $i++) {
                    $n = rand(0, $alphaLength);
                    $pass[] = $alphabet[$n];
                }
                $token = implode($pass);
                 //echo ($password);exit;
                //$cdate = strtotime(date('Y-m-d H:i:s'));
                $content=['userid'=>$checkemail->UserId,'token'=>$token,'username'=>$checkemail->Name,'url'=>url('/')];
                 //print_r($content); exit;
                $receiverAddress = $checkemail->UserEmail;
                //echo $receiverAddress;exit;
                Mail::to($receiverAddress)->send(new ForgotPasswordSite($content));
                //$model->setToken($Email, $token);
            $changereq = $model->ChangePasswordReq($checkemail->Password,$token);
            //echo "<pre>"; print_r($changereq); exit;
                if($changereq==1){
                    $status = 1;
                    $msg = "Password reset email has been sent to your email address, Please check your mail";
                    return Redirect::to('/login')->WithErrors(['sucmsg'=>'Password reset email has been sent to your email address, Please check your mail']);
                }
                return Redirect::to('/login')->WithErrors(['sucmsg'=>'Password reset email has been sent to your email address, Please check your mail']);
        }else{
            return redirect('/login')->withErrors(['errmsg'=>'Email is not registerd']);
        }
    }
}

public function viewChangePassword($id,$token){
        $model = new ProfileModel();
        ////////0 = user not found//1 = true// 2 = token used // 3 = token expired
        $checktokentime = $model->CheckTokenExpired($id,$token);
        //echo "<pre>";print_r($checktokentime); exit;
        //return view('changepasswordapi',compact('id','token','starttime'));
        if($checktokentime == 1){
            return view('changepasswords',compact('id','token','starttime'));
        }else if($checktokentime == 2){
            return redirect::to('login')->withErrors(['errmsg'=>'Your token is used']);
        }else if($checktokentime == 3){
            return redirect::to('login')->withErrors(['errmsg'=>'Forgot password link has been expired']);
        }else if($checktokentime == 0){
            return redirect::to('login')->withErrors(['errmsg'=>'User not found']);
        }
    }
    public function ChangePasswordapi($uid, Request $request){
        $rules = array(
            'newpassword' =>'required',
            'confpassword' =>'required',
        );
        $messages = [
            'newpassword.required' =>'New Password is mendatory field',
            'confpassword.required' =>'Confirm Password is mendatory field',
        ];
        $validator = Validator::make(Input::all(), $rules,$messages);
        if ($validator->fails()) {
            return Redirect::to('/')
                ->withErrors($validator)
                ->withInput(); // send back all errors to the login form
        } else {
            $newpassword = $request->input('newpassword');
            $confpassword = $request->input('confpassword');
            if($newpassword == $confpassword){
                $model = new ProfileModel();
                $changpwd = $model->ChangePasswordapi($uid,$newpassword,$confpassword);
                if($changpwd==1){
                    return Redirect::to('login')->withErrors(['sucmsg'=>'Your password has been changed successfully.'])->withInput();
                }else{
                    return Redirect::back()->withErrors(['errmsg'=>'Password and Confirm Password are not match.'])->withInput();
                }
            }else{
                return Redirect::back()->withErrors(['errmsg'=>'Password and Confirm Password are not match.'])->withInput();
            }
            
        }
    }
}
