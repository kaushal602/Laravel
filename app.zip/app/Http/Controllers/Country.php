<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use App\model\CountryModel;

class Country extends Controller
{
    public function __construct(){
        $this->middleware('login');
    }
	public function Index(Request $request){
    	return View('Country/Add');
    }
    public function AddCountry(Request $request){
		$CountryModel = new CountryModel();
		$exist = $CountryModel->ExistCountry($request);
    	if($exist){
    		//return json_encode(array('status'=> '0','message'=> 'Error.'));
            return Redirect::to('addcountry')->withErrors(['sucmsg'=>'Country Already Exiest.']);
    	}else{
            $userdata = session()->get("userdata");
    		$CountryName = $request->input('CountryName');
            $CountriesIsoCode = $request->input('CountriesIsoCode');
            $CountriesIsdCode = $request->input('CountriesIsdCode');
            $Data = [
                'CountryName' => $CountryName,
                'CountriesIsoCode' => strtoupper($CountriesIsoCode),
                'CountriesIsdCode' => $CountriesIsdCode,
            ];
            $CountryModel->AddCountry($Data);
            return Redirect::to('addcountry')->withErrors(['sucmsg'=>'Country Added successfully.']);
		}
    }
    public function CountryList(){
    	return View('Country/List');
    }
    
    public function GetCountryList(){
    	return View('Country/Data');
    }

    public function EditCountry($TypeId,Request $request){
    	$CountryModel = new CountryModel();
    	$Data = $CountryModel->GetCountryData($TypeId);
        //$ImageData = $CountryModel->GetCountryImage($TypeId);
        //print_r($ImageData);exit;
    	return View('Country/Update',compact('Data','ImageData'));
    }
    public function ViewEditCountry(Request $request){
    	$TypeId = $request->input('TypeId');
		$CountryModel = new CountryModel();
		return json_encode( $CountryModel->ViewCountryData($TypeId));
    }
    public function EditCountryDetails(Request $request){
    	$TypeId = $request->input('TypeId');
		$CountryModel = new CountryModel();
    	$exist = $CountryModel->ExistCountry($request);
        if($exist){
            //return json_encode(array('status'=> '0','message'=> 'Error.'));
            return Redirect::to('editcountry/'.$PageId)->withErrors(['sucmsg'=>'Country Already Exist.']);
        }else{
            $userdata = session()->get("userdata");
            $CountryId = $request->input('CountryId');
            $CountryName = $request->input('CountryName');
            $CountriesIsoCode = $request->input('CountriesIsoCode');
            $CountriesIsdCode = $request->input('CountriesIsdCode');
            $Data = [
                'CountryName' => $CountryName,
                'CountriesIsoCode' => strtoupper($CountriesIsoCode),
                'CountriesIsdCode' => $CountriesIsdCode,
            ];
            $CountryModel->EditCountryDetail($Data,$CountryId);
            return Redirect::to('countrylist')->withErrors(['sucmsg'=>'Country Updated successfully.']);
        }
    }
    public function CountryStatus(Request $request){
    	$CountryModel = new CountryModel();
    	$CountryId = $request->input('CountryId');
		$status = $request->input('status');
    	$data = $CountryModel->CountryStatus($CountryId,$status);
    	return json_encode(array('status'=> '1','message'=> 'Success.'));
    }
    public function DeleteCountry(Request $request){
        $CountryModel = new CountryModel();
        $TypeId = $request->input('TypeId');
        $CountryModel->DeleteCountry($TypeId);
    }

}