<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use App\model\EventtypeModel;

class EventType extends Controller
{
    public function __construct(){
        //$this->middleware('login');
    }
	public function Index(Request $request){
        $EventtypeModel = new EventtypeModel();
        $eventlist = $EventtypeModel->GetEventList();   
    	return View('EventType/Add', compact('eventlist'));
    }
    public function AddEventType(Request $request){
		$EventtypeModel = new EventtypeModel();
		$exist = $EventtypeModel->ExistEventType($request);
    	if($exist){
    		//return json_encode(array('status'=> '0','message'=> 'Error.'));
            return Redirect::to('addeventtype')->withErrors(['sucmsg'=>'EventType Already Exiest.']);
    	}else{
            $userdata = session()->get("userdata");
    		$EventTypeName = $request->input('EventTypeName');
            $ParentEventTypeId = $request->input('ParentEventTypeId');
            $EventTypeIcon = '';
            if ($request->hasFile('EventTypeIcon')) {
                $destination = 'public/images';
                $file = $request->file('EventTypeIcon');
                $tm = time();
                $file->move($destination, $tm.$file->getClientOriginalName());
                $EventTypeIcon = $destination. "/" .$tm.$file->getClientOriginalName();
            }
            $deleteimages = $request->input('deleteimages');
            if(trim($deleteimages)!=''){
                $deltimg = explode(" ", trim($deleteimages));
            }else{
                $deltimg = array();
            }
            $data = array();
            if($request->hasfile('imagegallery')) {
                foreach($request->file('imagegallery') as $key =>$image) {
                    if(count($deltimg)>0){
                        if((!(in_array($key, $deltimg)))){
                            $name=$image->getClientOriginalName();
                            $destination = 'public/images';
                            $tm = time();
                            $image->move($destination, $tm.$name);  
                            $data[] = $destination.'/'.$tm.$name;
                        }
                    } else {
                        $name=$image->getClientOriginalName();
                        $destination = 'public/images';
                        $tm = time();
                        $image->move($destination, $tm.$name);  
                        $data[] = $destination.'/'.$tm.$name;
                    }
                }
            }
            //print_r($data); exit;
            $EventtypeModel->AddEventType($EventTypeName,$ParentEventTypeId,$EventTypeIcon,$data);
            return Redirect::to('addeventtype')->withErrors(['sucmsg'=>'EventType Added successfully.']);
		}
    }
    public function EventTypeList(){
    	return View('EventType/List');
    }
    
    public function GetEventTypeList(){
    	return View('EventType/Data');
    }

    public function EditEventType($TypeId,Request $request){
    	$EventtypeModel = new EventtypeModel();
    	$Data = $EventtypeModel->GetEventTypeData($TypeId);
        $eventlist = $EventtypeModel->GetEventList(); 
        $ImageData = $EventtypeModel->GetEventTypeImage($TypeId);
        //print_r($ImageData);exit;
    	return View('EventType/Update',compact('Data','ImageData','eventlist'));
    }
    public function ViewEditEventType(Request $request){
    	$TypeId = $request->input('TypeId');
		$EventtypeModel = new EventtypeModel();
		return json_encode( $EventtypeModel->ViewEventTypeData($TypeId));
    }
    public function EditEventTypeDetails(Request $request){
    	$TypeId = $request->input('TypeId');
        //print_r($TypeId);exit;
		$EventtypeModel = new EventtypeModel();
    	$exist = $EventtypeModel->ExistEventType($request);
        if($exist){
            //return json_encode(array('status'=> '0','message'=> 'Error.'));
            return Redirect::to('editeventtype/'.$TypeId)->withErrors(['sucmsg'=>'EventType Already Exiest.']);
        }else{
            $userdata = session()->get("userdata");
            $EventTypeName = $request->input('EventTypeName');
            $ParentEventTypeId = $request->input('ParentEventTypeId');
            $deletetimages = $request->input('deletetimages');
            if(trim($deletetimages)!=''){
                $deloldtimg = explode(" ", trim($deletetimages));
            }else{
                $deloldtimg = array();
            }
            if(count($deloldtimg)){
                $EventtypeModel->DeleteOldImages($deloldtimg);
            }
            //print_r(count($deltimg));exit;
           $EventTypeIcon = '';
            if ($request->hasFile('EventTypeIcon')) {
                $destination = 'public/images';
                $file = $request->file('EventTypeIcon');
                $tm = time();
                $file->move($destination, $tm.$file->getClientOriginalName());
                $EventTypeIcon = $destination. "/" .$tm.$file->getClientOriginalName();
            }
            $deleteimages = $request->input('deleteimages');
            if(trim($deleteimages)!=''){
                $deltimg = explode(" ", trim($deleteimages));
            }else{
                $deltimg = array();
            }
            $data = array();
            if($request->hasfile('imagegallery')) {
                foreach($request->file('imagegallery') as $key =>$image) {
                    if(count($deltimg)>0){
                        if((!(in_array($key, $deltimg)))){
                            $name=$image->getClientOriginalName();
                            $destination = 'public/images';
                            $tm = time();
                            $image->move($destination, $tm.$name);  
                            $data[] = $destination.'/'.$tm.$name;
                        }
                    } else {
                        $name=$image->getClientOriginalName();
                        $destination = 'public/images';
                        $tm = time();
                        $image->move($destination, $tm.$name);  
                        $data[] = $destination.'/'.$tm.$name;
                    }
                }
            }

        //echo $TypeId;exit;
            $EventtypeModel->EditEventTypeDetail($EventTypeName,$ParentEventTypeId,$EventTypeIcon,$TypeId,$data);
            return Redirect::to('eventtypelist')->withErrors(['sucmsg'=>'EventType Updated successfully.']);
        }
    }
    public function EventTypeStatus(Request $request){
    	$EventtypeModel = new EventtypeModel();
    	$TypeId = $request->input('TypeId');
		$status = $request->input('status');
    	$data = $EventtypeModel->EventTypeStatus($TypeId,$status);
    	return json_encode(array('status'=> '1','message'=> 'Success.'));
    }
    public function DeleteEventType(Request $request){
        $EventtypeModel = new EventtypeModel();
        $TypeId = $request->input('TypeId');
        $EventtypeModel->DeleteEventType($TypeId);
    }
    public function DeleteEventImage(Request $request){
        $EventtypeModel = new EventtypeModel();
        $TypeId = $request->input('TypeId');
        $EventtypeModel->DeleteEventImage($TypeId);
    }

    public function GetEventType(){
        //echo "123"; exit;
        $EventtypeModel = new EventtypeModel();
        $EventTypeList = $EventtypeModel->GetEventType();
        $status = 1;
        $msg = "Event List.";
        $Data = $EventTypeList;
        $content = json_encode(array('status'=>$status,'message'=>$msg,'EventTypeList'=>$Data),JSON_UNESCAPED_SLASHES );
        return response($content)
                    ->header('Content-Type', 'application/json');
    }
    public function EventTypeImage(){
        try {
          $EventTypeId = $_POST['EventTypeId'];
        }
        catch (\Exception $e) {
           $EventTypeId = '';
        }

        try {
          $ChildEventTypeId = $_POST['ChildEventTypeId'];
        }
        catch (\Exception $e) {
            $ChildEventTypeId = 0;
        }
        try {
          $UserId = $_POST['UserId'];
        }
        catch (\Exception $e) {
            $UserId = 1;
        }
        $EventtypeModel = new EventtypeModel();
        $EventTypeImage = $EventtypeModel->EventTypeImage($EventTypeId,$ChildEventTypeId,$UserId);
        $status = 1;
        $msg = "Event List.";
        $Data = $EventTypeImage;
        $content = json_encode(array('status'=>$status,'message'=>$msg,'EventTypeImage'=>$Data),JSON_UNESCAPED_SLASHES );
        return response($content)
                    ->header('Content-Type', 'application/json');
    }

}