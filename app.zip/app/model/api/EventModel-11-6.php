<?php

namespace App\model\api;

use Illuminate\Database\Eloquent\Model;
use DB;

class EventModel extends Model
{
	public function GetAgent($Agent){
		return DB::table('user_master')
			->where('Role','LIKE','%'.$Agent.'%')
			->orderBy('Name','ASC')
			->get()->toArray();
	}
	public function RegisterData($UserEmail){
        return DB::table('user_master')
                ->where('UserEmail',$UserEmail)
                ->first();
    }
    public function ExistUser($UserEmail,$UserId){
        return DB::table('user_master')
                ->where('UserEmail', '=' ,$UserEmail)
                ->where('UserId' , '!=' , $UserId)
                ->first();
    }
    public function Event($Data){
        $data = DB::table('event_master')
            ->insertGetId($Data);
        if(!empty($data)){
            return DB::table('event_master')
                ->where('EventId',$data)
                ->first();
        }
    }
    public function TransactionData($transaction){
        $data = DB::table('invitation_master')
            ->insert($transaction);
    }
    public function LinkData($LinkData){
        $data = DB::table('eventlink_master')
            ->insert($LinkData);
    }
    public function DltTransactionData($EventId){
        $data = DB::table('invitation_master')
            ->where('EventId' , '=' , $EventId)
            ->delete();
    }
    public function UpdateTransactionData($transaction,$EventId){
        $data = DB::table('invitation_master')
            //->where('EventId',$EventId)
            ->insert($transaction);
    }
    public function DltLinkData($EventId){
        $data = DB::table('eventlink_master')
            ->where('EventId' , '=' , $EventId)
            ->delete();
    }
    public function UpdateLinkData($LinkData,$EventId){
        $data = DB::table('eventlink_master')
            //->where('EventId',$EventId)
            ->insert($LinkData);
    }
    public function UpGetTransectionData($EventId,$UserId){
         return DB::table('invitation_master')
            ->select('invitation_master.InviteName','invitation_master.Number','invitation_master.TransactionId')
            ->where('EventId', '=', $EventId)
            ->where('UserId', '=', $UserId)
            ->get();
    }
    public function UpGetLinkData($EventId,$UserId){
        //print_r($EventId);print_r($UserId); exit;
         return DB::table('eventlink_master')
            ->select('eventlink_master.LinkName','eventlink_master.LinkUrl')
            ->where('EventId', '=', $EventId)
            ->where('UserId', '=', $UserId)
            ->get();
    }
    public function GetTransectionData($eid,$uid){
         return DB::table('invitation_master')
            ->select('invitation_master.InviteName','invitation_master.Number','invitation_master.TransactionId')
            ->where('EventId', '=', $eid)
            ->where('UserId', '=', $uid)
            ->get();
    }
    public function GetLinkData($eid,$uid){
         return DB::table('eventlink_master')
            ->select('eventlink_master.LinkName','eventlink_master.LinkUrl')
            ->where('EventId', '=', $eid)
            ->where('UserId', '=', $uid)
            ->get();
    }
    public function GetEventDetail($EventId){
        return DB::table('event_master')
            ->select('event_master.EventId','event_master.UserId','event_master.EventName','event_master.EventType','event_master.EventDescription','event_master.LinkName','event_master.LinkUrl','event_master.EventDate','event_master.StartTime','event_master.EndTime','event_master.Address','event_master.Latitude','event_master.Longitude')
            ->where('EventId', '=', $EventId)
            ->get();
    }
    public function GetEventInvitationData($EventId){
         return DB::table('invitation_master')
            ->select('invitation_master.Number','invitation_master.InviteName','invitation_master.TransactionId')
            ->where('EventId', '=', $EventId)
            ->get();
    }

    public function EventList($UserId){
        $data = DB::table('event_master')
            ->select('event_master.EventId','event_master.UserId','event_master.EventName','event_master.EventType','event_master.EventDescription','event_master.EventDate','event_master.StartTime','event_master.EndTime','event_master.Address','event_master.Latitude','event_master.Longitude')
            ->where('SendInvitation', '=', 'Yes')
            ->where('UserId', '=', $UserId)
            ->where('IsActive', '=', 1)
            ->get()->toArray();
        
        //print_r($alldata); exit;
        $alldata = array();
        foreach ($data as $key => $value) {
            $eid = intval($value->EventId);
            $uid = intval($value->UserId);
            $res1 = DB::table('invitation_master')
                ->select('invitation_master.Number','invitation_master.InviteName','invitation_master.TransactionId')
                ->where('EventId', '=', $eid)
                ->where('UserId', '=', $uid)
                ->get();
                $value->TotalInvite = count($res1);
                $alldata[]= $value;
                $value->InvitationData = $res1;
            $alldata[]= $value;
            /*$res2 = DB::table('eventlink_master')
                ->select('eventlink_master.LinkName','eventlink_master.LinkUrl')
                ->where('EventId', '=', $eid)
                ->where('UserId', '=', $uid)
                ->get()->toArray();
                $value->GetLinkData =  $res2;
                $alldata[]= $value;*/
                //echo "123";
        }
        //exit;
        $alldata = $data;
        //print_r($alldata); exit;
        return $alldata;
    }
    public function DraftEventList($UserId){
       $data = DB::table('event_master')
            ->select('event_master.EventId','event_master.UserId','event_master.EventName','event_master.EventType','event_master.EventDescription','event_master.EventDate','event_master.StartTime','event_master.EndTime','event_master.Address','event_master.Latitude','event_master.Longitude')
            ->where('SendInvitation', '=', 'No')
            ->where('UserId', '=', $UserId)
            ->where('IsActive', '=', 1)
            ->get()->toArray();
        $alldata = $data;
        $alldata = array();
         foreach ($data as $key => $value) {
            $eid = intval($value->EventId);
            $uid = intval($value->UserId);
            $res1 = DB::table('invitation_master')
                ->select('invitation_master.Number','invitation_master.InviteName','invitation_master.TransactionId')
                ->where('EventId', '=', $eid)
                ->where('UserId', '=', $uid)
                ->get();
                $value->InvitationData = $res1;
            $alldata= $value;
        }
       /* foreach ($data as $key => $value) {
            $eid = intval($value->EventId);
            $uid = intval($value->UserId);
            $res1 = DB::table('eventlink_master')
                ->select('eventlink_master.LinkName','eventlink_master.LinkUrl')
                ->where('EventId', '=', $eid)
                ->where('UserId', '=', $uid)
                ->get();
                $value->GetLinkData = $res1;
            $alldata= $value;
        }*/
        return $data;
    }

    function UpdateEvent($Data,$EventId){
        DB::table('event_master')
            ->where('EventId' , '=' , $EventId)
            ->update($Data);
        return DB::table('event_master')
                ->where('EventId',$EventId)
                ->first();
    }

    public function AddDraftEvent($Data){
        $data = DB::table('event_master')
            ->insertGetId($Data);
        if(!empty($data)){
            return DB::table('event_master')
                ->where('EventId',$data)
                ->first();
        }
    }
    function UpdateDraftEvent($Data,$EventId){
        DB::table('event_master')
            ->where('EventId' , '=' , $EventId)
            ->update($Data);
        return DB::table('event_master')
                ->where('EventId',$EventId)
                ->first();
    }
    function DeleteDraftEvent($EventId){
        DB::table('eventlink_master')
            ->where('EventId' , '=' , $EventId)
            ->delete();
    }
    function UpdateDraftLinkData($LinkData,$EventId){
        
        $data = DB::table('eventlink_master')
            ->insert($LinkData);
         /*return DB::table('eventlink_master')
            ->select('eventlink_master.LinkName','eventlink_master.LinkUrl')
            ->where('EventId', '=', $EventId)
            ->where('UserId', '=', $uid)
            ->get();*/
    }

    function GetDraftLinkData($EventId,$UserId){
        return DB::table('eventlink_master')
            ->select('eventlink_master.LinkName','eventlink_master.LinkUrl')
            ->where('EventId', '=', $EventId)
            ->where('UserId', '=', $UserId)
            ->get();
    }

    function DeteteInviteNumber($TransactionId){
        $data = DB::table('invitation_master')
            ->where('TransactionId' , '=' , $TransactionId)
            ->delete();
    }

    function CancelEvent($EventId){
        DB::table('event_master')
            ->where('EventId' , '=' , $EventId)
            ->update(['IsActive' => 0]);
    }

    function GetEventType(){
        $data = DB::table('eventtype_master')
            ->select('eventtype_master.EventTypeId','eventtype_master.EventTypeName','eventtype_master.EventTypeIcon')
            ->where('ParentEventTypeId','=',0)
            ->where('IsActive','=',1)
            ->get()->toArray();
         $alldata = $data;
        $alldata = array();
        foreach ($data as $key => $value) {
            $EventTypeId = intval($value->EventTypeId);
            $res1 = DB::table('eventtype_master')
                ->select('eventtype_master.EventTypeId','eventtype_master.EventTypeName','eventtype_master.EventTypeIcon')
                ->where('ParentEventTypeId', '=', $EventTypeId)
                ->get()->toArray();
                $value->ChildEventType =$res1;
                $alldata[]= $value;
        }
        return $alldata;
    }

    function EventTypeImage($EventTypeId,$ChildEventTypeId,$UserId){
        if($ChildEventTypeId == 0){
            $data = DB::table('eventtypeimage_master')
                ->select('eventtypeimage_master.EventTypeId','eventtypeimage_master.ImageUrl')
                ->where('EventTypeId','=',$EventTypeId)
                ->whereIn('UserId','=',array(1, $UserId))
                ->where('IsActive','=',1)
                ->get()->toArray();
        } else {
            $data = DB::table('eventtypeimage_master')
                ->select('eventtypeimage_master.EventTypeId','eventtypeimage_master.ImageUrl')
                ->where('EventTypeId','=',$ChildEventTypeId)
                ->where('IsActive','=',1)
                ->whereIn('UserId',array(1, $UserId))
                ->get()->toArray();
        }
        return $data;
    }
}