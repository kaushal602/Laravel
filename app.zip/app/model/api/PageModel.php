<?php

namespace App\model\api;

use Illuminate\Database\Eloquent\Model;
use DB;

class PageModel extends Model
{
	
    public function GetAboutUsPage(){
        return DB::table('page_master')
            ->select('page_master.Description')
            ->where('PageId', '=', 1)
            ->first();
    }
    public function GetPrivacyPolivyPage(){
        return DB::table('page_master')
            ->select('page_master.Description')
            ->where('PageId', '=', 2)
            ->first();
    }

}