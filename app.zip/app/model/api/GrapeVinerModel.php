<?php

namespace App\model\api;

use Illuminate\Database\Eloquent\Model;
use DB;

class GrapeVinerModel extends Model
{
	
	public function GrapeVinerData($Mobile,$UserId){
        return DB::table('grapeviner_master')
                ->where('Mobile',$Mobile)
                ->where('UserId',$UserId)
                ->first();
    }
    public function GrapeViner($Data){
        DB::table('grapeviner_master')
            ->insert($Data);
    }

    public function GrapeVinerList($UserId){
        return DB::table('grapeviner_master')
            ->select('grapeviner_master.GrapeVinerId','grapeviner_master.UserId','grapeviner_master.Name','grapeviner_master.Email','grapeviner_master.Mobile',DB::raw('CAST(grapeviner_master.IsChecked as unsigned integer) as IsChecked'))
            ->where('UserId', '=', $UserId)
            ->get()->toArray();
    }
}