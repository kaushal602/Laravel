<?php

namespace App\model\api;

use Illuminate\Database\Eloquent\Model;
use DB;

class EventModel extends Model
{
	public function GetAgent($Agent){
		return DB::table('user_master')
			->where('Role','LIKE','%'.$Agent.'%')
			->orderBy('Name','ASC')
			->get()->toArray();
	}
	public function RegisterData($UserEmail){
        return DB::table('user_master')
                ->where('UserEmail',$UserEmail)
                ->first();
    }
    public function ExistUser($UserEmail,$UserId){
        return DB::table('user_master')
                ->where('UserEmail', '=' ,$UserEmail)
                ->where('UserId' , '!=' , $UserId)
                ->first();
    }
    public function Event($Data){
        $data = DB::table('event_master')
            ->insertGetId($Data);
        if(!empty($data)){
            return DB::table('event_master')
                ->where('EventId',$data)
                ->first();
        }
    }
    public function GetEventTypeName($EventType){
        return DB::table('eventtype_master')
            ->select('*')
            ->where('EventTypeId', '=', $EventType)
            ->first();
    }
    public function GetEventSubTypeName($SubEventType){
        return DB::table('eventtype_master')
            ->select('*')
            ->where('EventTypeId', '=', $SubEventType)
            ->first();
    }
    public function TransactionData($transaction){
        $data = DB::table('invitation_master')
            ->insert($transaction);
    }
    public function AddInviteRecivId($mob,$uid){
    	$data = DB::table('user_master')
            ->where('Mobile' , 'LIKE' ,  '%'.$mob)
            ->first();
            //print_r($data); exit;
        if(!empty($data)){  
	        DB::table('invitation_master')
	            ->where('Number' , 'LIKE' ,  '%'.$mob)
	            ->update(['ReceiverId' => $data->UserId]);
	    }
    }
    public function LinkData($LinkData){
        $data = DB::table('eventlink_master')
            ->insert($LinkData);
    }
    public function DltTransactionData($EventId){
        $data = DB::table('invitation_master')
            ->where('EventId' , '=' , $EventId)
            ->delete();
    }
    public function UpdateTransactionData($transaction,$EventId){
        $data = DB::table('invitation_master')
            //->where('EventId',$EventId)
            ->insert($transaction);
    }
    public function DltLinkData($EventId){
        $data = DB::table('eventlink_master')
            ->where('EventId' , '=' , $EventId)
            ->delete();
    }
    public function UpdateLinkData($LinkData,$EventId){
        $data = DB::table('eventlink_master')
            //->where('EventId',$EventId)
            ->insert($LinkData);
    }
    public function UpGetTransectionData($EventId,$UserId){
         return DB::table('invitation_master')
            ->select('invitation_master.InviteName','invitation_master.Number','invitation_master.TransactionId')
            ->where('EventId', '=', $EventId)
            ->where('SenderId', '=', $UserId)
            ->get();
    }
    public function UpGetLinkData($EventId,$UserId){
        //print_r($EventId);print_r($UserId); exit;
         return DB::table('eventlink_master')
            ->select('eventlink_master.LinkName','eventlink_master.LinkUrl')
            ->where('EventId', '=', $EventId)
            ->where('UserId', '=', $UserId)
            ->get();
    }
    public function GetTransectionData($eid,$uid){
         return DB::table('invitation_master')
            ->select('invitation_master.InviteName','invitation_master.Number','invitation_master.TransactionId')
            ->where('EventId', '=', $eid)
            ->where('SenderId', '=', $uid)
            ->get();
    }
    public function GetLinkData($eid,$uid){
         return DB::table('eventlink_master')
            ->select('eventlink_master.LinkName','eventlink_master.LinkUrl')
            ->where('EventId', '=', $eid)
            ->where('UserId', '=', $uid)
            ->get();
    }
    public function GetEventDetail($EventId){
        return DB::table('event_master')
            ->select('event_master.EventId','event_master.UserId','event_master.EventName','event_master.EventType','event_master.EventDescription','event_master.LinkName','event_master.LinkUrl','event_master.EventDate','event_master.StartTime','event_master.EndTime','event_master.Address','event_master.Latitude','event_master.Longitude','event_master.CoverImage')
            ->where('EventId', '=', $EventId)
            ->get();
    }
    public function GetEventInvitationData($EventId){
         return DB::table('invitation_master')
            ->select('invitation_master.Number','invitation_master.InviteName','invitation_master.TransactionId')
            ->where('EventId', '=', $EventId)
            ->get();
    }

    public function EventList($UserId){
        $data = DB::table('event_master')
            ->select('event_master.EventId','event_master.UserId','event_master.EventName','event_master.EventType','event_master.EventDescription','event_master.EventDate','event_master.StartTime','event_master.EndTime','event_master.Address','event_master.Latitude','event_master.Longitude','event_master.CoverImage','event_master.EventType','event_master.SubEventType')
            ->where('SendInvitation', '=', 'Yes')
            ->where('UserId', '=', $UserId)
            ->where('IsActive', '=', 1)
            ->get()->toArray();
        
        //print_r($data); exit;
        $alldata = array();
        foreach ($data as $key => $value) {
            $etypId = intval($value->EventType);
            $eid = intval($value->EventId);
            $uid = intval($value->UserId);
            $res1 = DB::table('invitation_master')
                ->select('invitation_master.Number','invitation_master.InviteName','invitation_master.TransactionId')
                ->where('EventId', '=', $eid)
                ->where('SenderId', '=', $uid)
                ->get();
                $value->TotalInvite = count($res1);
                $alldata[]= $value;
                $value->InvitationData = $res1;
                $alldata[]= $value;
            $Acceptres = DB::table('invitation_master')
                ->select('invitation_master.AcceptStatus','invitation_master.TransactionId')
                ->where('EventId', '=', $eid)
                ->where('AcceptStatus', '=', 'ACCEPT')
                ->get();
                $value->TotalAccept = count($Acceptres);
                $alldata[]= $value;
            $Declineres = DB::table('invitation_master')
                ->select('invitation_master.AcceptStatus','invitation_master.TransactionId')
                ->where('EventId', '=', $eid)
                ->where('AcceptStatus', '=', 'DECLINE')
                ->get();
                $value->TotalDecline = count($Declineres);
                $alldata[]= $value;
            $res2 = DB::table('eventtype_master')
                ->select('*')
                ->where('EventTypeId', '=',$etypId)
                ->first();
                $value->EventTypeId =  $res2->EventTypeId;
                $value->EventType =  $res2->EventTypeName;
                $value->EventTypeIcon =  $res2->EventTypeIcon;
                $alldata[]= $value;
            if($value->SubEventType != '' && $value->SubEventType != 0){
                $res3 = DB::table('eventtype_master')
                    ->select('*')
                    ->where('EventTypeId', '=', $value->SubEventType)
                    ->first();

                    $value->SubEventTypeId =  $res3->EventTypeId;
                    $value->SubEventType =  $res3->EventTypeName;
                } else {
                    $value->SubEventTypeId =  '';
                    $value->SubEventType =  '';
                }
                $alldata[]= $value;
                //echo "123";
        }
        //exit;
        $alldata = $data;
        //print_r($alldata); exit;
        return $alldata;
    }
    public function DraftEventList($UserId){
       $data = DB::table('event_master')
            ->select('event_master.EventId','event_master.UserId','event_master.EventName','event_master.EventType','event_master.EventDescription','event_master.EventDate','event_master.StartTime','event_master.EndTime','event_master.Address','event_master.Latitude','event_master.Longitude','event_master.CoverImage','event_master.EventType','event_master.SubEventType')
            ->where('SendInvitation', '=', 'No')
            ->where('UserId', '=', $UserId)
            ->where('IsActive', '=', 1)
            ->get()->toArray();
            //print_r($data); exit;
        $alldata = array();
         foreach ($data as $key => $value) {
            $eid = intval($value->EventId);
            $uid = intval($value->UserId);
            $res1 = DB::table('invitation_master')
                ->select('invitation_master.Number','invitation_master.InviteName','invitation_master.TransactionId')
                ->where('EventId', '=', $eid)
                ->where('SenderId', '=', $uid)
                ->get();
                $value->InvitationData = $res1;
                $alldata= $value;
            /*$Acceptres = DB::table('invitation_master')
                ->select('invitation_master.AcceptStatus','invitation_master.TransactionId')
                ->where('EventId', '=', $eid)
                ->where('AcceptStatus', '=', 'Accept')
                ->get();
                $value->TotalAccept = count($Acceptres);
                $alldata= $value;
            $Declineres = DB::table('invitation_master')
                ->select('invitation_master.AcceptStatus','invitation_master.TransactionId')
                ->where('EventId', '=', $eid)
                ->where('AcceptStatus', '=', 'Decline')
                ->get();
                $value->TotalDecline = count($Declineres);
                $alldata= $value;*/
            $res2 = DB::table('eventtype_master')
                ->select('*')
                ->where('EventTypeId', '=',$value->EventType)
                ->first();
                //print_r($res2); exit;
                $value->EventTypeId =  $res2->EventTypeId;
                $value->EventType =  $res2->EventTypeName;
                $value->EventTypeIcon =  $res2->EventTypeIcon;
                $alldata= $value;

            if($value->SubEventType != '' && $value->SubEventType != 0){
            $res3 = DB::table('eventtype_master')
                ->select('*')
                ->where('EventTypeId', '=', $value->SubEventType)
                ->first();

                $value->SubEventTypeId =  $res3->EventTypeId;
                $value->SubEventType =  $res3->EventTypeName;
            } else {
                $value->SubEventTypeId =  '';
                $value->SubEventType =  '';
            }
            $alldata= $value;
        }
       /* foreach ($data as $key => $value) {
            $eid = intval($value->EventId);
            $uid = intval($value->UserId);
            $res1 = DB::table('eventlink_master')
                ->select('eventlink_master.LinkName','eventlink_master.LinkUrl')
                ->where('EventId', '=', $eid)
                ->where('UserId', '=', $uid)
                ->get();
                $value->GetLinkData = $res1;
            $alldata= $value;
        }*/

        $alldata = $data;
        return $alldata;
    }

    public function InviteEventList($UserId){
    	//echo $UserId; exit;
       $data = DB::table('invitation_master')
            ->join('event_master','invitation_master.EventId','=','event_master.EventId')
            ->join('user_master','event_master.UserId','=','user_master.UserId')
            ->where('invitation_master.ReceiverId',$UserId)
            ->select('event_master.EventId','event_master.UserId','event_master.EventName','event_master.EventType','event_master.EventDescription','event_master.EventDate','event_master.StartTime','event_master.EndTime','event_master.Address','event_master.Latitude','event_master.Longitude','event_master.CoverImage','event_master.EventType','event_master.SubEventType','invitation_master.EventId','invitation_master.ReceiverId', 'user_master.Name as UserName','invitation_master.AcceptStatus')
            ->get()->toArray();
            $alldata = array();
         foreach ($data as $key => $value) {
            $eid = intval($value->EventId);
            $uid = intval($value->UserId);
            $res2 = DB::table('eventtype_master')
                ->select('*')
                ->where('EventTypeId', '=',$value->EventType)
                ->first();
                //print_r($res2); exit;
                $value->EventTypeId =  $res2->EventTypeId;
                $value->EventType =  $res2->EventTypeName;
                $value->EventTypeIcon =  $res2->EventTypeIcon;
                $alldata= $value;

            if($value->SubEventType != '' && $value->SubEventType != 0){
            $res3 = DB::table('eventtype_master')
                ->select('*')
                ->where('EventTypeId', '=', $value->SubEventType)
                ->first();

                $value->SubEventTypeId =  $res3->EventTypeId;
                $value->SubEventType =  $res3->EventTypeName;
            } else {
                $value->SubEventTypeId =  '';
                $value->SubEventType =  '';
            }
            $alldata= $value;
        }
        $alldata = $data;
        return $data;
        //echo "<pre>"; print_r($data); exit;
    }

    function UpdateEvent($Data,$EventId){
        DB::table('event_master')
            ->where('EventId' , '=' , $EventId)
            ->update($Data);
        return DB::table('event_master')
                ->where('EventId',$EventId)
                ->first();
    }

    public function AddDraftEvent($Data){
        $data = DB::table('event_master')
            ->insertGetId($Data);
        if(!empty($data)){
            return DB::table('event_master')
                ->where('EventId',$data)
                ->first();
        }
    }
    function UpdateDraftEvent($Data,$EventId){
        DB::table('event_master')
            ->where('EventId' , '=' , $EventId)
            ->update($Data);
        return DB::table('event_master')
                ->where('EventId',$EventId)
                ->first();
    }
    function DeleteDraftEvent($EventId){
        DB::table('eventlink_master')
            ->where('EventId' , '=' , $EventId)
            ->delete();
    }
    function UpdateDraftLinkData($LinkData,$EventId){
        
        $data = DB::table('eventlink_master')
            ->insert($LinkData);
         /*return DB::table('eventlink_master')
            ->select('eventlink_master.LinkName','eventlink_master.LinkUrl')
            ->where('EventId', '=', $EventId)
            ->where('UserId', '=', $uid)
            ->get();*/
    }

    function GetDraftLinkData($EventId,$UserId){
        return DB::table('eventlink_master')
            ->select('eventlink_master.LinkName','eventlink_master.LinkUrl')
            ->where('EventId', '=', $EventId)
            ->where('UserId', '=', $UserId)
            ->get();
    }

    function DeteteInviteNumber($TransactionId){
        $data = DB::table('invitation_master')
            ->where('TransactionId' , '=' , $TransactionId)
            ->delete();
    }

    function CancelEvent($EventId){
        DB::table('event_master')
            ->where('EventId' , '=' , $EventId)
            ->update(['IsActive' => 0]);
    }

    function GetEventType(){
        $data = DB::table('eventtype_master')
            ->select('eventtype_master.EventTypeId','eventtype_master.EventTypeName','eventtype_master.EventTypeIcon')
            ->where('ParentEventTypeId','=',0)
            ->where('IsActive','=',1)
            ->get()->toArray();
         $alldata = $data;
        $alldata = array();
        foreach ($data as $key => $value) {
            $EventTypeId = intval($value->EventTypeId);
            $res1 = DB::table('eventtype_master')
                ->select('eventtype_master.EventTypeId','eventtype_master.EventTypeName','eventtype_master.EventTypeIcon')
                ->where('ParentEventTypeId', '=', $EventTypeId)
                ->get()->toArray();
                $value->ChildEventType =$res1;
                $alldata[]= $value;
        }
        return $alldata;
    }

    function EventTypeImage($EventTypeId,$ChildEventTypeId,$UserId){
        if($ChildEventTypeId == 0){
            $data = DB::table('eventtypeimage_master')
                ->select('eventtypeimage_master.EventTypeId','eventtypeimage_master.ImageUrl')
                ->where('EventTypeId','=',$EventTypeId)
                //->whereIn('UserId','=',array(1, $UserId))
                ->where('IsActive','=',1)
                ->get()->toArray();
        } else {
            $data = DB::table('eventtypeimage_master')
                ->select('eventtypeimage_master.EventTypeId','eventtypeimage_master.ImageUrl')
                ->where('EventTypeId','=',$ChildEventTypeId)
                ->where('IsActive','=',1)
                //->whereIn('UserId',array(1, $UserId))
                ->get()->toArray();
        }
        return $data;
    }

    function UploadImage($Data,$UserId,$EventId){
        DB::table('event_master')
            ->where('UserId' , '=' , $UserId)
            ->where('EventId' , '=' , $EventId)
            ->update($Data);
        return DB::table('event_master')
                ->where('UserId',$UserId)
                ->where('EventId' , $EventId)
                ->first();
    }

    function UpdateAcceptStatus($EventId,$UserId,$Data){
        DB::table('invitation_master')
            ->where('ReceiverId' , '=' , $UserId)
            ->where('EventId' , '=' , $EventId)
            ->update($Data);
        return DB::table('invitation_master')
            ->select('invitation_master.AcceptStatus')
            ->where('ReceiverId' , '=' , $UserId)
            ->where('EventId' , '=' , $EventId)
            ->first();
    }
}