<?php

namespace App\model\api;

use Illuminate\Database\Eloquent\Model;
use DB;

class RegistrationModel extends Model
{
	public function GetAgent($Agent){
		return DB::table('user_master')
			->where('Role','LIKE','%'.$Agent.'%')
			->orderBy('Name','ASC')
			->get()->toArray();
	}
	public function RegisterData($UserEmail){
        return DB::table('user_master')
                ->where('UserEmail',$UserEmail)
                ->first();
    }
    public function Register($Data){
        $data = DB::table('user_master')
            ->insertGetId($Data);
        if(!empty($data)){
            return DB::table('user_master')
                ->where('UserId',$data)
                ->first();
        }
    }

}