<?php

namespace App\model\api;

use Illuminate\Database\Eloquent\Model;
use DB;

class GenerateOtpModel extends Model
{
	public function GenerateOtp($uid){
		$string = 'abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
	    $string_shuffled = str_shuffle($string);
	    $otp = substr($string_shuffled, 1, 7);
	    //echo $password;exit;
	    if(!empty($otp)){
	    	DB::table('user_master')
	    		->where('UserId',$uid)
	    		->update(['Otp'=>$otp,
	    			'IsOtpVerified'=>0]);
	    }
	}
	public function VerifyOtp($Otp,$UserId){
		$cdate = date('Y-m-d H:i:s');
		return DB::table('user_master')
			->where('UserId',$UserId)
			->where('Otp',$Otp)
			->update(['IsOtpVerified'=>1,
					'IsActive'=>1,
					'ModifiedDate'=>$cdate]);


	}
	public function ResendOtp($UserId){
		/*$string = 'abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
	    $string_shuffled = str_shuffle($string);
	    $otp = substr($string_shuffled, 1, 7);*/
	    $otp = "1111";
	    	$cdate = date('Y-m-d H:i:s');
			return DB::table('user_master')
				->where('UserId',$UserId)
				->update(['Otp'=>$otp,
						'ModifiedDate'=>$cdate]);
	}
	public function ChangePasswordReq($Password,$token,$UserId){
		//echo $token."==".$Password."==".$UserId;exit;
		$pwd = md5($Password);
		date_default_timezone_set('Asia/Kolkata');
		$cdate = date('Y-m-d H:i:s');
		$data = DB::table('user_master')
			->where('UserId',$UserId)
			//->where('Password',$pwd)
			->update(['TokenExpiryDate'=>$cdate,
					'PwdToken'=>$token,
					'IsTokenUsed'=>0,
					'ModifiedDate'=>$cdate]);
			//echo "<pre>";print_r($data); exit;
		return $data;
	}
	public function CheckEmail($UserEmail){
		
		/*$data = DB::table('user_master')
				->where('UserId',142)
				->get()->toArray();
				echo "<pre>";print_r($data); exit;
		$countryCode = str_replace(" ", "", $countryCode);*/
		return DB::table('user_master')
			->where('UserEmail',$UserEmail)
			->first();
	}
	public function CheckTokenExpired($id,$token){
        ////////0 = user not found//1 = true// 2 = token used // 3 = token expired
        date_default_timezone_set('Asia/Kolkata');
        $cdate = date('Y-m-d H:i:s');
        $stop_date = date('Y-m-d H:i:s', strtotime($cdate . ' +1 day'));
        $userdata = DB::table('user_master')
            ->where('UserID',$id)
            ->where('PwdToken',$token)
            ->first();
        if(!empty($userdata)){
            if($stop_date < strtotime($userdata->TokenExpiryDate)){
            	//echo "<pre>"; print_r($userdata); exit;
                if($userdata->IsTokenUsed == 0){
                    return 1;
                }else{
                    return 2;
                }
            }else{
                return 3;
            }
        }else{
            return 0;
        }
    }
    public function ChangePasswordapi($uid,$newpassword,$confpassword){
    	date_default_timezone_set('Asia/Kolkata');
		$cdate = date('Y-m-d H:i:s');
    	return DB::table('user_master')
    		->where('UserId',$uid)
    		->update(['Password'=>md5($newpassword),
    				'ModifiedDate'=>$cdate,
    				'IsTokenUsed'=>1]);
    }

    public function CheckOldPass($OldPassword,$UserId){
    	return DB::table('user_master')
                ->select('*')
                ->where('UserId' , '=' , $UserId)
                ->where('Password' , '=' , md5($OldPassword))
                ->first();
    }

    function ChangePassword($UserId,$NewPassword){
    	DB::table("user_master")
    		->where('UserId' , '=' , $UserId)
    		->update(['Password'=>md5($NewPassword)]);
    }
}