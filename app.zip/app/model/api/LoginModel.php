<?php

namespace App\model\api;

use Illuminate\Database\Eloquent\Model;
use DB;

class LoginModel extends Model
{
    public function Login($UserEmail,$Password){
        return DB::table('user_master')
    		->where('UserEmail','=',$UserEmail)
    		->where('Password','=',md5($Password))
            ->first();
    }
    public function CountryList(){
        return DB::table('apps_countries')
            ->select('CountryName','CountriesIsdCode')
            ->where('IsActive','=',1)
            ->get();
    }
    
}
