<?php

namespace App\model\api;

use Illuminate\Database\Eloquent\Model;
use DB;

class RegistrationModel extends Model
{
	public function GetAgent($Agent){
		return DB::table('user_master')
			->where('Role','LIKE','%'.$Agent.'%')
			->orderBy('Name','ASC')
			->get()->toArray();
	}
	public function RegisterData($UserEmail){
        return DB::table('user_master')
                ->where('UserEmail',$UserEmail)
                ->first();
    }
    public function ExistUser($UserEmail,$UserId){
        return DB::table('user_master')
                ->where('UserEmail', '=' ,$UserEmail)
                ->where('UserId' , '!=' , $UserId)
                ->first();
    }
    public function CheckFbRegister($FBToken){
        return DB::table('user_master')
            ->where('FBToken', '=' ,$FBToken)
            ->first();
    }
    public function Register($Data){
        $data = DB::table('user_master')
            ->insertGetId($Data);
        if(!empty($data)){
            return DB::table('user_master')
                ->where('UserId',$data)
                ->first();
        }
    }
    function UploadImage($Data,$UserId){
        DB::table('user_master')
            ->where('UserId' , '=' , $UserId)
            ->update($Data);
        return DB::table('user_master')
                ->where('UserId',$UserId)
                ->first();
    }
    function UpdateProfile($Data,$UserId){
        DB::table('user_master')
            ->where('UserId' , '=' , $UserId)
            ->update($Data);
        return DB::table('user_master')
                ->where('UserId',$UserId)
                ->first();
    }

    public function UpdateLanguageId($LanguageId,$UserId){
        $data = DB::table('user_master')
                ->where('UserId' , '=' , $UserId)
                ->update([
                    'LanguageId'=>$LanguageId,
                ]);
        return DB::table('user_master')
            ->where('UserId','=',$UserId)
            ->first();
    }
    public function UpdateTimeFormate($TimeFormate,$UserId){
        $data = DB::table('user_master')
                ->where('UserId' , '=' , $UserId)
                ->update([
                    'TimeFormate'=>$TimeFormate,
                ]);
        return DB::table('user_master')
            ->where('UserId','=',$UserId)
            ->first();
    }
}