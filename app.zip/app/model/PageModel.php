<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;
use DB;

class PageModel extends Model
{
	function ExistPage($request){
        if($request->input('PageId')){
            return DB::table('page_master')
                ->select('*')
                //->where('PageName' , '=' , $request->input('PageName'))
                ->where('PageId' , '!=' , $request->input('PageId'))
                ->first();
        }else{
            return DB::table('page_master')
                ->select('*')
                ->where('PageName' , '=' , $request->input('PageName'))
                ->first();
        }
    }
    function AddPageDetail($data){
		DB::table('page_master')
			->insert($data);
	}
	function GetPageData($PageId){
		return DB::table('page_master')
			->where('PageId','=',$PageId)
			->first();
	}
    function ViewPageData($PageId){
        return DB::table('page_master')
            ->where('PageId','=',$PageId)
            ->first();
    }

    function TotalRecord(){
        return DB::table('page_master')
            ->select('*')
            ->where('IsActive','=',1)
            ->count();
    }

    function GetPageDetails($pageno){
        //print_r($RecordPerPage);exit;
        return DB::table('page_master')
            ->select('*')
            ->where('IsActive','=',1)
            ->get()->toArray();
    }
	function EditPageDetail($data,$PageId){
		DB::table('page_master')
            ->where('PageId' , '=' , $PageId)
            ->update($data);
	}
	function PageStatus($PageId,$status){
        if($status == 'y'){
            DB::table('page_master')
                ->where('PageId', $PageId)
                ->update(['IsActive' => 1]);
        } else {
            DB::table('page_master')
                ->where('PageId', $PageId)
                ->update(['IsActive' => 0]);
        }
    }
    function DeletePage($PageId){
        DB::table('page_master')
            ->where('PageId',$PageId)
            ->delete();
    }
     /*function DeletePage($id){
        DB::table('page_master')
            ->where('PageId','=',$id)
            ->delete();
    }*/
    function GetAboutUs($PageId){
        return DB::table('page_master')
            ->where('PageId','=',$PageId)
            ->first();
    }
    function EditAbout($data,$PageId){
        DB::table('page_master')
            ->where('PageId' , '=' , $PageId)
            ->update($data);
    }
    function GetPrivacyPolicy($PageId){
        return DB::table('page_master')
            ->where('PageId','=',$PageId)
            ->first();
    }
    function EditPrivacyPolicy($data,$PageId){
        DB::table('page_master')
            ->where('PageId' , '=' , $PageId)
            ->update($data);
    }
}