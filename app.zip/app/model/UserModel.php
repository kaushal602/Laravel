<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;
use DB;

class UserModel extends Model
{
    function DeleteUser($id){
        DB::table('user_master')
            ->where('UserId', $id)
            ->update(['IsActive' => 0]);
    }
    function CountryStatus($UserId,$status){
        if($status == 'y'){
            DB::table('user_master')
                ->where('UserId', $UserId)
                ->update(['IsActive' => 1]);
        } else {
            DB::table('user_master')
                ->where('UserId', $UserId)
                ->update(['IsActive' => 0]);
        }
    }
}
