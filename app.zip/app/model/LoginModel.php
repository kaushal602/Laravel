<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;
use DB;

class LoginModel extends Model
{
    function Login($request){
    	return DB::table('user_master')
    		->select('*')
    		/*->where(function($query) use ($request){
    			$query->where('UserName','=',$request->input('username'));
    			$query->orWhere('Email','=',$username);
    		})*/
            ->where('UserEmail','=',$request->input('UserEmail'))
    		->where('Password','=',md5($request->input('Password')))
    		->first();
    }
}
