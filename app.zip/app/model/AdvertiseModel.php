<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;
use DB;

class AdvertiseModel extends Model
{
    function GetLanguage(){
         return DB::table('language_master')
                ->select('*')
                ->get()->toArray();
    }
	function ExistAdvertise($request){
        if($request->input('AdvertiseId')){
            return DB::table('advertise_master')
                ->select('*')
                ->where('AdvertiseTitle' , '=' , $request->input('AdvertiseTitle'))
                ->where('AdvertiseId' , '!=' , $request->input('AdvertiseId'))
                ->first();
        }else{
            return DB::table('advertise_master')
                ->select('*')
                ->where('AdvertiseTitle' , '=' , $request->input('AdvertiseTitle'))
                ->first();

        }
    }
    function AddAdvertise($Data){
        DB::table('advertise_master')
            ->insert($Data);
	}

	function GetAdvertiseData($TypeId){
		return DB::table('advertise_master')
			->where('AdvertiseId','=',$TypeId)
			->first();
	}
    function GetAdvertiseImage($TypeId){
        $Data = DB::table('advertise_master')
            ->where('AdvertiseId','=',$TypeId)
            ->first();
        return DB::table('eventtypeimage_master')
            ->where('AdvertiseId','=',$Data->AdvertiseId)
            ->get()->toArray();
    }
    function ViewAdvertiseData($TypeId){
        return DB::table('advertise_master')
            ->where('AdvertiseId','=',$TypeId)
            ->first();
    }



    function GetAdvertiseDetails($Advertiseno){
        //print_r($RecordPerAdvertise);exit;
        return DB::table('eventtypeimage_master')
            ->select('*')
            ->where('IsActive','=',1)
            ->get()->toArray();
    }
	function EditAdvertiseDetail($Data,$AdvertiseId){
		DB::table('advertise_master')
            ->where('AdvertiseId','=',$AdvertiseId)
            ->update($Data);
	}
	function AdvertiseStatus($TypeId,$status){
        if($status == 'y'){
            DB::table('advertise_master')
                ->where('AdvertiseId', $TypeId)
                ->update(['IsActive' => 1]);
        } else {
            DB::table('advertise_master')
                ->where('AdvertiseId', $TypeId)
                ->update(['IsActive' => 0]);
        }
    }
    function DeleteAdvertise($AdvertiseId){
        DB::table('advertise_master')
            ->where('AdvertiseId','=',$AdvertiseId)
            ->delete();
    }
}