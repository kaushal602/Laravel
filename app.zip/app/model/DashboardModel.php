<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;
use DB;

class DashboardModel extends Model
{
    function ChangePasswordDetail($where,$update){
    	DB::table("user_master")
    		->where($where)
    		->update($update);
    }
    public function UserList(){
    	return DB::table('user_master')
    			->where('IsActive','1')
                ->where('UserId', '!=', 1)
    			->get();
        //return count($res);
    }
    public function EventList(){
    	return DB::table('event_master')
                ->select('*')
                ->get();
    }
    public function GetExecutive(){
    	return DB::table('user_master')
    			->where('Role','Executive')
    			->get()->toArray();
    }
    public function GetCase(){
    	return DB::table('case_master')
    			->get()->toArray();
    }
    public function GetOperation(){
    	return DB::table('operation_master')
    			->get()->toArray();
    }
}
