<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;
use DB;

class CountryModel extends Model
{
	function ExistCountry($request){
        if($request->input('CountryId')){
            return DB::table('apps_countries')
                ->select('*')
                ->where('CountryName' , '=' , $request->input('CountryName'))
                ->where('CountryId' , '!=' , $request->input('CountryId'))
                ->first();
        }else{
            return DB::table('apps_countries')
                ->select('*')
                ->where('CountryName' , '=' , $request->input('CountryName'))
                ->first();

        }
    }
    function AddCountry($Data){
        DB::table('apps_countries')
            ->insert($Data);
	}

	function GetCountryData($TypeId){
		return DB::table('apps_countries')
			->where('CountryId','=',$TypeId)
			->first();
	}
    function GetCountryImage($TypeId){
        $Data = DB::table('apps_countries')
            ->where('CountryId','=',$TypeId)
            ->first();
        return DB::table('eventtypeimage_master')
            ->where('CountryId','=',$Data->CountryId)
            ->get()->toArray();
    }
    function ViewCountryData($TypeId){
        return DB::table('apps_countries')
            ->where('CountryId','=',$TypeId)
            ->first();
    }



    function GetCountryDetails($Countryno){
        //print_r($RecordPerCountry);exit;
        return DB::table('eventtypeimage_master')
            ->select('*')
            ->where('IsActive','=',1)
            ->get()->toArray();
    }
	function EditCountryDetail($Data,$CountryId){
		DB::table('apps_countries')
            ->where('CountryId','=',$CountryId)
            ->update($Data);
	}
	function CountryStatus($CountryId,$status){
        if($status == 'y'){
            DB::table('apps_countries')
                ->where('CountryId', $CountryId)
                ->update(['IsActive' => 1]);
        } else {
            DB::table('apps_countries')
                ->where('CountryId', $CountryId)
                ->update(['IsActive' => 0]);
        }
    }
    function DeleteCountry($TypeId){
        DB::table('apps_countries')
            ->where('CountryId','=',$TypeId)
            ->delete();
    }
}