<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;
use DB;

class EventModel extends Model
{
    function DeleteUser($id){
        DB::table('event_master')
            ->where('UserId', $id)
            ->update(['IsActive' => 0]);
    }
    function ViewEvent($id){
    	return DB::table('event_master')
    			->select('*')
    			->where('EventId', '=', $id)
    			->first();
    }
}
