<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;
use DB;

class ProfileModel extends Model
{
    public function EditProfile(){
    	return DB::table('admin_user')
    		->get()->toArray();
    }
    public function UpdateProfile($request,$imagnam){
        date_default_timezone_set('Asia/Kolkata');
        $cdate = date('Y-m-d H:i:s');
        $data = DB::table('admin_user')
            ->first();
            if(!empty($data->Photo) && ($imagnam=="")){
                $img = $data->Photo;
            }else if(empty($data->Photo) && ($imagnam!="")){
                $img = $imagnam;
            }else{
                $img = "";
            }
    	DB::table('admin_user')
    		->update(['Mobile'=>$request->input('telephone'),
    				'Email'=>$request->input('email'),
    				'DisplayName'=>$request->input('displayname'),
    				'Photo'=>$img,
                    'ModifiedDate'=>$cdate]);
    }
    public function CheckEmail($UserEmail){
		return DB::table('user_master')
			//->where('UserUserId',$uid)
			->where('UserEmail',$UserEmail)
			->first();
	}
	public function ChangePasswordReq($Password,$token){
		//echo $token."==".$Password."==".$UserUserId;exit;
		$pwd = md5($Password);
		date_default_timezone_set('Asia/Kolkata');
		$cdate = date('Y-m-d H:i:s');
		$data = DB::table('user_master')
			//->where('UserUserId',$UserUserId)
			//->where('Password',$pwd)
			->update(['TokenExpiryDate'=>$cdate,
					'PwdToken'=>$token,
					'IsTokenUsed'=>0,
					'ModifiedDate'=>$cdate]);
			//echo "<pre>";print_r($data); exit;
		return $data;
	}
	public function CheckTokenExpired($id,$token){
        ////////0 = user not found//1 = true// 2 = token used // 3 = token expired
        date_default_timezone_set('Asia/Kolkata');
        $cdate = date('Y-m-d H:i:s');
        $stop_date = date('Y-m-d H:i:s', strtotime($cdate . ' +1 day'));
        $userdata = DB::table('user_master')
            ->where('UserId',$id)
            ->where('PwdToken',$token)
            ->first();
        if(!empty($userdata)){
            if($stop_date < strtotime($userdata->TokenExpiryDate)){
            	//echo "<pre>"; print_r($userdata); exit;
                if($userdata->IsTokenUsed == 0){
                    return 1;
                }else{
                    return 2;
                }
            }else{
                return 3;
            }
        }else{
            return 0;
        }
    }
    public function ChangePasswordapi($uid,$newpassword,$confpassword){
    	// echo $newpassword;exit;
    	date_default_timezone_set('Asia/Kolkata');
		$cdate = date('Y-m-d H:i:s');
    	return DB::table('user_master')
    		->where('UserId',$uid)
    		->update(['Password'=>md5($newpassword),
    				'ModifiedDate'=>$cdate,
    				'IsTokenUsed'=>1]);
    }
}
