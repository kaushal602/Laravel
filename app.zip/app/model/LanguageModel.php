<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;
use DB;

class LanguageModel extends Model
{
	function ExistLanguage($request){
        if($request->input('LanguageId')){
            return DB::table('language_master')
                ->select('*')
                ->where('LanguageName' , '=' , $request->input('LanguageName'))
                ->where('LanguageId' , '!=' , $request->input('LanguageId'))
                ->first();
        }else{
            return DB::table('language_master')
                ->select('*')
                ->where('LanguageName' , '=' , $request->input('LanguageName'))
                ->first();

        }
    }
    function AddLanguage($LanguageName,$LanguageCode){
        DB::table('language_master')
            ->insert([
                'LanguageName' => $LanguageName,
                'LanguageCode' => $LanguageCode,
                'CreatedDate' => date('Y-m-d h:i:s'),
            ]);
	}

	function GetLanguageData($LanguageId){
		return DB::table('language_master')
			->where('LanguageId','=',$LanguageId)
			->first();
	}
    function GetLanguageImage($LanguageId){
        $Data = DB::table('language_master')
            ->where('LanguageId','=',$LanguageId)
            ->first();
        return DB::table('eventtypeimage_master')
            ->where('LanguageId','=',$Data->LanguageId)
            ->get()->toArray();
    }
    function ViewLanguageData($LanguageId){
        return DB::table('language_master')
            ->where('LanguageId','=',$LanguageId)
            ->first();
    }



    /*function GetLanguageDetails($Languageno){
        //print_r($RecordPerLanguage);exit;
        return DB::table('eventtypeimage_master')
            ->select('*')
            ->where('IsActive','=',1)
            ->get()->toArray();
    }*/
	function EditLanguageDetail($LanguageName,$LanguageId){
		DB::table('language_master')
            ->where('LanguageId','=',$LanguageId)
            ->update(['LanguageName' => $LanguageName,]);
	}
	function LanguageStatus($LanguageId,$status){
        if($status == 'y'){
            DB::table('language_master')
                ->where('LanguageId', $LanguageId)
                ->update(['IsActive' => 1]);
        } else {
            DB::table('language_master')
                ->where('LanguageId', $LanguageId)
                ->update(['IsActive' => 0]);
        }
    }
    function DeleteLanguage($LanguageId){
        DB::table('language_master')
            ->where('LanguageId','=',$LanguageId)
            ->delete();
    }
}