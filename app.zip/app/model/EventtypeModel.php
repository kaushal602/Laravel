<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;
use DB;

class EventtypeModel extends Model
{
	function ExistEventType($request){
        if($request->input('TypeId')){
            return DB::table('eventtype_master')
                ->select('*')
                ->where('EventTypeName' , '=' , $request->input('EventTypeName'))
                ->where('EventTypeId' , '!=' , $request->input('TypeId'))
                ->first();
        }else{
            return DB::table('eventtype_master')
                ->select('*')
                ->where('EventTypeName' , '=' , $request->input('EventTypeName'))
                ->first();

        }
    }
    function GetEventList(){
        return DB::table('eventtype_master')
            ->select('*')
            ->where('ParentEventTypeId' , '=' , 0)
            ->get()->toArray();
    }

    function AddEventType($EventTypeName,$ParentEventTypeId,$EventTypeIcon,$data){
        /*DB::table('eventtype_master')
            ->insert([
                'EventTypeName' => $EventTypeName,
            ]);*/
        $dataid = DB::table('eventtype_master')
            ->insertGetId([
                'EventTypeName' => $EventTypeName,
                'ParentEventTypeId' => $ParentEventTypeId,
                'EventTypeIcon' => $EventTypeIcon,
            ]);
            //print_r($data);exit;
        foreach($data as $image1){
            DB::table('eventtypeimage_master')
            ->insert([
                    'EventTypeId' => $dataid,
                    'ImageUrl' => $image1,
                ]);
        }
		/*DB::table('eventtype_master')
			->insert($data);*/
	}

	function GetEventTypeData($TypeId){
		return DB::table('eventtype_master')
			->where('EventTypeId','=',$TypeId)
			->first();
	}
    function GetEventTypeImage($TypeId){
        $Data = DB::table('eventtype_master')
            ->where('EventTypeId','=',$TypeId)
            ->first();
        return DB::table('eventtypeimage_master')
            ->where('EventTypeId','=',$Data->EventTypeId)
            ->get()->toArray();
    }
    function ViewEventTypeData($TypeId){
        return DB::table('eventtype_master')
            ->where('EventTypeId','=',$TypeId)
            ->first();
    }



    function GetEventTypeDetails($EventTypeno){
        //print_r($RecordPerEventType);exit;
        return DB::table('eventtypeimage_master')
            ->select('*')
            ->where('IsActive','=',1)
            ->get()->toArray();
    }
	function EditEventTypeDetail($EventTypeName,$ParentEventTypeId,$EventTypeIcon,$TypeId,$data){
        //echo $TypeId; exit;
        $Data = [
            'EventTypeName' => $EventTypeName,
            'ParentEventTypeId' => $ParentEventTypeId,
        ];
        if($EventTypeIcon!='') {
            $Data['EventTypeIcon'] = $EventTypeIcon;
        }
		DB::table('eventtype_master')
            ->where('EventTypeId','=',$TypeId)
            ->update($Data);
        //if($data){
            foreach($data as $image1){
                DB::table('eventtypeimage_master')
                ->insert([
                        'EventTypeId' => $TypeId,
                        'ImageUrl' => $image1,
                    ]);
            }
       // }
	}

    function DeleteOldImages($deloldtimg){
        DB::table('eventtypeimage_master')
            //->where('EventTypeImageId','=',$TypeId)
            ->whereIn('EventTypeImageId',$deloldtimg)
            ->delete();
    }

	function EventTypeStatus($TypeId,$status){
        if($status == 'y'){
            DB::table('eventtypeimage_master')
                ->where('EventTypeId', $TypeId)
                ->update(['IsActive' => 1]);
        } else {
            DB::table('eventtypeimage_master')
                ->where('EventTypeId', $TypeId)
                ->update(['IsActive' => 0]);
        }
    }
    function DeleteEventType($TypeId){
        DB::table('eventtype_master')
            ->where('EventTypeId','=',$TypeId)
            ->delete();
    }
    function DeleteEventImage($TypeId){
        DB::table('eventtypeimage_master')
            ->where('EventTypeImageId','=',$TypeId)
            ->delete();
    }

    function GetEventType(){
        $data = DB::table('eventtype_master')
            ->select('eventtype_master.EventTypeId','eventtype_master.EventTypeName','eventtype_master.EventTypeIcon')
            ->where('ParentEventTypeId','=',0)
            ->where('IsActive','=',1)
            ->get()->toArray();
         $alldata = $data;
        $alldata = array();
        foreach ($data as $key => $value) {
            $EventTypeId = intval($value->EventTypeId);
            $res1 = DB::table('eventtype_master')
                ->select('eventtype_master.EventTypeId','eventtype_master.EventTypeName','eventtype_master.EventTypeIcon')
                ->where('ParentEventTypeId', '=', $EventTypeId)
                ->get()->toArray();
                $value->ChildEventType =$res1;
                $alldata[]= $value;
        }
        return $alldata;
    }

    function EventTypeImage($EventTypeId,$ChildEventTypeId,$UserId){
        if($ChildEventTypeId == 0){
            $data = DB::table('eventtypeimage_master')
                ->select('eventtypeimage_master.EventTypeId','eventtypeimage_master.ImageUrl')
                ->where('EventTypeId','=',$EventTypeId)
                ->whereIn('UserId','=',array(1, $UserId))
                ->where('IsActive','=',1)
                ->get()->toArray();
        } else {
            $data = DB::table('eventtypeimage_master')
                ->select('eventtypeimage_master.EventTypeId','eventtypeimage_master.ImageUrl')
                ->where('EventTypeId','=',$ChildEventTypeId)
                ->where('IsActive','=',1)
                ->whereIn('UserId',array(1, $UserId))
                ->get()->toArray();
        }
        return $data;
    }
}